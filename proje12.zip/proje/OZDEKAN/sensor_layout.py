"""Additive migration and validation for machine-specific display preferences."""
from sqlalchemy import inspect, text


def migrate_sensor_layout(engine):
    """Old databases keep every existing row; a missing preference means default order."""
    with engine.begin() as connection:
        columns = {column['name'] for column in inspect(connection).get_columns('machines')}
        if 'sensor_layout' not in columns:
            connection.execute(text('ALTER TABLE machines ADD COLUMN sensor_layout JSON'))


def default_layout(sensor_ids):
    ids = list(dict.fromkeys(str(id_) for id_ in (sensor_ids or [])))
    half = (len(ids) + 1) // 2
    return {'top': ids[:half], 'bottom': ids[half:]}


def reconcile_layout(sensor_ids, saved):
    """Keep surviving positions, remove stale IDs and place newly configured sensors."""
    defaults = default_layout(sensor_ids)
    allowed = set(defaults['top'] + defaults['bottom'])
    result, seen = {'top': [], 'bottom': []}, set()
    for group in result:
        values = saved.get(group, []) if isinstance(saved, dict) else []
        for raw in values if isinstance(values, list) else []:
            id_ = str(raw)
            if id_ in allowed and id_ not in seen:
                seen.add(id_)
                result[group].append(id_)
    for group in result:
        result[group].extend(id_ for id_ in defaults[group] if id_ not in seen)
    return result


def validate_layout(sensor_ids, payload):
    if not isinstance(payload, dict) or set(payload) != {'top', 'bottom'}:
        raise ValueError('Yerleşim üst ve alt sensör listelerini içermeli')
    if any(not isinstance(payload[group], list) for group in ('top', 'bottom')):
        raise ValueError('Üst ve alt sensörler liste olmalı')
    values = payload['top'] + payload['bottom']
    if any(type(value) not in (int, str) for value in values):
        raise ValueError('Sensör adresleri sayı veya metin olmalı')
    ids = [str(value) for value in values]
    if len(ids) != len(set(ids)):
        raise ValueError('Bir sensör yalnızca bir kez yerleştirilebilir')
    allowed = {str(id_) for id_ in (sensor_ids or [])}
    if set(ids) != allowed:
        raise ValueError('Sensör listesi değişmiş veya geçersiz. Sayfayı yenileyip tekrar deneyin')
    return {group: [str(id_) for id_ in payload[group]] for group in ('top', 'bottom')}
