"""Kalite nedeni doğrulaması ve mevcut SQLite dosyaları için eklemeli geçiş."""
from fastapi import HTTPException
from sqlalchemy import inspect, text
from models import QualityReason


def migrate_quality_reasons(engine):
    QualityReason.__table__.create(engine, checkfirst=True)
    with engine.begin() as conn:
        columns = {column["name"] for column in inspect(conn).get_columns("task_logs")}
        if "quality_reason_id" not in columns:
            conn.execute(text("ALTER TABLE task_logs ADD COLUMN quality_reason_id INTEGER REFERENCES quality_reasons(id)"))
        if "quality_reason_name" not in columns:
            conn.execute(text("ALTER TABLE task_logs ADD COLUMN quality_reason_name TEXT"))
        if "quality_reasons" not in columns:
            conn.execute(text("ALTER TABLE task_logs ADD COLUMN quality_reasons JSON"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_task_logs_quality_reason_id ON task_logs (quality_reason_id)"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_task_logs_product_latest ON task_logs (product_id, timestamp, id)"))


def resolve_quality_reason(db, status, reason_id):
    if status not in {"SUCCESS", "FAILED", "CONDITIONAL"}:
        raise HTTPException(status_code=400, detail="Geçersiz ürün durumu")
    ids = reason_id if isinstance(reason_id, list) else ([] if reason_id in (None, "") else [reason_id])
    if not ids and status != "SUCCESS":
        raise HTTPException(status_code=400, detail="Başarısız veya şartlı ürün için en az bir neden seçin")
    reasons = []
    for selected in ids:
        if isinstance(selected, bool) or not str(selected).isdigit():
            raise HTTPException(status_code=400, detail="Listeden geçerli neden seçin")
        reason = db.query(QualityReason).filter(QualityReason.id == int(selected)).first()
        if not reason or not reason.is_active or reason.status != status:
            raise HTTPException(status_code=400, detail="Seçilen neden aktif değil veya ürün durumuna uygun değil")
        if reason.id not in {item.id for item in reasons}:
            reasons.append(reason)
    return reasons


def reason_fields(reasons):
    return {"quality_reason_id": reasons[0].id if reasons else None,
            "quality_reason_name": ", ".join(reason.name for reason in reasons) or None,
            "quality_reasons": [{"id": reason.id, "name": reason.name} for reason in reasons]}


def stored_reasons(task):
    if not task:
        return []
    return task.quality_reasons or ([{"id": task.quality_reason_id, "name": task.quality_reason_name}] if task.quality_reason_id else [])
