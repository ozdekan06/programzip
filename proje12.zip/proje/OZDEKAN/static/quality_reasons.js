/* Shared selection controls for product entry and quality changes. */
window.QualityReasons = {
  items: [],
  async load(includeInactive = false) {
    const response = await fetch('/quality-reasons' + (includeInactive ? '?include_inactive=true' : ''));
    if (!response.ok) throw new Error('Kalite nedenleri yüklenemedi. Sayfayı yenileyip tekrar deneyin.');
    this.items = await response.json();
    return this.items;
  },
  fill(select, status, {filter = false} = {}) {
    const previous = [...select.selectedOptions].map(option => option.value);
    const required = status === 'FAILED' || status === 'CONDITIONAL';
    select.multiple = !filter;
    select.size = filter ? 1 : 4;
    select.replaceChildren();
    if (filter) select.add(new Option('Tüm nedenler', ''));
    const reasons = this.items.filter(item => (!status || item.status === status) && (filter || item.is_active));
    const labels = {SUCCESS:'Çıtır hata', FAILED:'Başarısız', CONDITIONAL:'Şartlı'};
    reasons.forEach(item => {
      const option = new Option(`${filter ? labels[item.status] + ' — ' : ''}${item.name}${item.is_active ? '' : ' (Pasif)'}`, item.id);
      option.selected = previous.includes(String(item.id));
      select.add(option);
    });
    select.disabled = false;
    select.required = !filter && required;
    if (!filter) {
      let hint = select.nextElementSibling;
      if (!hint || !hint.classList.contains('quality-selection-hint')) {
        hint = document.createElement('small'); hint.className = 'quality-selection-hint';select.after(hint);
      }
      hint.textContent = (status === 'SUCCESS' ? 'Çıtır hatalar isteğe bağlıdır. ' : 'En az bir neden seçin. ') +
        (reasons.length ? 'Birden fazla seçim: Ctrl / ⌘ tuşuna basarak seçin.' : 'Tanım eklemek için Ana sayfa > Kalite Nedenleri.');
    }
  },
  selected(select) {
    return [...select.selectedOptions].map(option => Number(option.value)).filter(Boolean);
  },
  label(product) {
    return product.quality_reason_name || (['FAILED', 'CONDITIONAL'].includes(product.current_status || product.status) ? 'Neden belirtilmemiş (eski kayıt)' : '—');
  },
  escape(value) {
    return String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
  }
};
