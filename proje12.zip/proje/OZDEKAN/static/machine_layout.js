/* Per-machine display layout only. Does not change device addresses or polling. */
(() => {
    'use strict';
    let machineId, sensorIds = [], dragging = null, editing = false, bound = false;
    let pendingSave = null, saving = false;
    const groups = () => [document.getElementById('top-sensors'), document.getElementById('bottom-sensors')];
    const key = () => `ozdekan.machineLayout.${machineId}`;
    function defaultLayout() { const half = Math.ceil(sensorIds.length / 2); return {top: sensorIds.slice(0, half), bottom: sensorIds.slice(half)}; }
    function reconcile(saved) {
        const defaults = defaultLayout(), seen = new Set(), result = {top: [], bottom: []};
        for (const group of ['top', 'bottom']) {
            for (const raw of Array.isArray(saved?.[group]) ? saved[group] : []) {
                const id = String(raw);
                if (sensorIds.includes(id) && !seen.has(id)) { seen.add(id); result[group].push(id); }
            }
        }
        for (const group of ['top', 'bottom']) for (const id of defaults[group]) if (!seen.has(id)) { result[group].push(id); seen.add(id); }
        return result;
    }
    function snapshot() { return Object.fromEntries(groups().map((group, index) => [index ? 'bottom' : 'top', [...group.querySelectorAll('.sensor-box')].map(card => card.dataset.sensorId)])); }
    function announce(message) { document.getElementById('layout-status').textContent = message; }
    function refresh() {
        groups().forEach((group, index) => {
            const cards = [...group.querySelectorAll('.sensor-box')];
            document.getElementById(index ? 'bottom-sensor-count' : 'top-sensor-count').textContent = `${cards.length} sensör`;
            group.querySelectorAll('.machine-empty-sensors').forEach(node => node.remove());
            if (!cards.length) { const empty = document.createElement('p'); empty.className = 'machine-empty-sensors'; empty.textContent = editing ? 'Bir sensörü buraya sürükleyin.' : 'Bu grupta sensör yok.'; group.append(empty); }
            group.style.setProperty('--sensor-columns', Math.min(4, Math.max(1, cards.length)));
            cards.forEach((card, position) => {
                card.querySelector('[data-layout-before]').disabled = position === 0;
                card.querySelector('[data-layout-after]').disabled = position === cards.length - 1;
                const move = card.querySelector('[data-layout-group]');
                move.textContent = index ? 'Üste taşı ↑' : 'Alta taşı ↓';
                move.setAttribute('aria-label', `Sensör ${sensorIds.indexOf(card.dataset.sensorId) + 1} (adres ${card.dataset.sensorId}): ${index ? 'üst' : 'alt'} sensörlere taşı`);
            });
        });
    }
    async function flushSave() {
        if (saving || !pendingSave) return;
        saving = true;
        try {
            while (pendingSave) {
                const layout = pendingSave; pendingSave = null;
                announce('Yerleşim veritabanına kaydediliyor…');
                try {
                    const response = await fetch(`/machines/${machineId}/sensor-layout`, {
                        method: 'PUT', headers: {'Content-Type':'application/json'},
                        body: JSON.stringify(layout), keepalive: true
                    });
                    const result = await response.json();
                    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'Yerleşim kaydedilemedi');
                    // A migrated browser-only preference must never override this database later.
                    try { localStorage.removeItem(key()); } catch (_) {}
                    document.getElementById('retry-layout-save').hidden = true;
                    if (!pendingSave) announce('Yerleşim veritabanına kaydedildi. Tekrar girişte aynı düzen açılır.');
                } catch (error) {
                    // Retain the newest edit for an explicit retry; never report failed saves as durable.
                    if (!pendingSave) pendingSave = layout;
                    document.getElementById('retry-layout-save').hidden = false;
                    announce(`Kaydedilemedi: ${error.message}. Kaydı tekrar dene düğmesini kullanın.`);
                    break;
                }
            }
        } finally { saving = false; }
    }
    function save() {
        refresh(); pendingSave = snapshot(); flushSave();
    }
    function apply(layout) {
        const targets = groups();
        ['top','bottom'].forEach((group, i) => layout[group].forEach(id => {
            const card = document.getElementById(`sensor-card-${id}`); if (card) targets[i].append(card);
        }));
        refresh();
    }
    function stopDrag() { dragging?.classList.remove('sensor-dragging'); dragging = null; groups().forEach(group => group.classList.remove('sensor-drop-target')); }
    function setupCard(card) {
        const id = card.dataset.sensorId;
        const label = `Sensör ${sensorIds.indexOf(id) + 1} (adres ${id})`;
        const controls = document.createElement('div'); controls.className = 'sensor-layout-actions';
        controls.innerHTML = `<span class="sensor-drag-handle" role="button" tabindex="0" draggable="true" aria-label="${label} kartını sürükle" title="Tut ve sürükle">⠿ Taşı</span><button type="button" data-layout-before aria-label="${label} kartını önceye taşı">←</button><button type="button" data-layout-after aria-label="${label} kartını sonraya taşı">→</button><button type="button" data-layout-group></button>`;
        card.prepend(controls);
        controls.querySelector('[data-layout-before]').onclick = () => { const previous = card.previousElementSibling; if (previous?.classList.contains('sensor-box')) { previous.before(card); save(); } };
        controls.querySelector('[data-layout-after]').onclick = () => { const next = card.nextElementSibling; if (next?.classList.contains('sensor-box')) { next.after(card); save(); } };
        controls.querySelector('[data-layout-group]').onclick = () => { const [top,bottom] = groups(); (card.parentElement === top ? bottom : top).append(card); save(); };
        const handle = controls.querySelector('.sensor-drag-handle');
        handle.addEventListener('dragstart', event => {
            if (!editing) { event.preventDefault(); return; }
            dragging = card; event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('application/x-ozdekan-sensor', id);
            event.dataTransfer.setData('text/plain', id);
            card.classList.add('sensor-dragging');
        });
        handle.addEventListener('dragend', stopDrag);
    }
    window.MachineLayout = {
        init(machine) {
            machineId = machine.id; sensorIds = (machine.sensor_ids || []).map(String);
            for (const id of sensorIds) { const card = document.getElementById(`sensor-card-${id}`); if (card && !card.querySelector('.sensor-layout-actions')) setupCard(card); }
            let legacy;
            try { legacy = JSON.parse(localStorage.getItem(key())); } catch (_) {}
            const saved = machine.sensor_layout;
            apply(saved ? reconcile(saved) : legacy ? reconcile(legacy) : defaultLayout());
            if (saved === null && legacy) save();
            else if (saved === undefined) announce('Veritabanına yerleşim kaydı için uygulamayı yeniden başlatın.');
            if (bound) return; bound = true;
            document.getElementById('edit-layout').onclick = () => {
                editing = !editing; document.body.classList.toggle('layout-editing', editing);
                const button = document.getElementById('edit-layout'); button.setAttribute('aria-pressed', String(editing));
                button.textContent = editing ? 'Düzenlemeyi bitir' : 'Yerleşimi düzenle';
                document.getElementById('reset-layout').hidden = !editing;
                if (!pendingSave && !saving) announce(editing ? 'Kartı Taşı tutamacından sürükleyin veya ok düğmelerini kullanın. Değişiklikler veritabanına otomatik kaydedilir.' : 'Yerleşim düzenleme kapatıldı.');
                refresh();
            };
            document.getElementById('retry-layout-save').onclick = flushSave;
            document.getElementById('reset-layout').onclick = () => { apply(defaultLayout()); save(); };
            for (const group of groups()) {
                group.addEventListener('dragover', event => { if (!editing || !dragging) return; event.preventDefault(); event.dataTransfer.dropEffect = 'move'; group.classList.add('sensor-drop-target'); });
                group.addEventListener('dragleave', event => { if (!group.contains(event.relatedTarget)) group.classList.remove('sensor-drop-target'); });
                group.addEventListener('drop', event => {
                    if (!editing || !dragging) return;
                    event.preventDefault();
                    const target = event.target.closest('.sensor-box');
                    if (target && target !== dragging && target.parentElement === group) {
                        const rect = target.getBoundingClientRect();
                        if (event.clientX < rect.left + rect.width / 2) target.before(dragging); else target.after(dragging);
                    } else if (!target) group.append(dragging);
                    save(); stopDrag();
                });
            }
        }
    };
})();
