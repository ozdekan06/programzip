/* Shared display preference and pagination for product entry and reports. */
(() => {
    const key = 'ozdekan.pageSize';
    const valid = value => Number.isInteger(value) && value >= 10 && value <= 100 && value % 10 === 0;
    let size = 20;
    try { const saved = Number(localStorage.getItem(key)); if (valid(saved)) size = saved; } catch (_) {}
    const groups = new Map();
    function visible(group) { if (group.remote) return group.data; return group.data.slice(group.page * size, (group.page + 1) * size); }
    function paint(group) {
        const pages = Math.max(1, Math.ceil((group.total ?? group.data.length) / size));
        group.page = Math.min(group.page, pages - 1);
        for (const member of group.members) {
            member.render(visible(group));
            const target = document.querySelector(member.target);
            if (!target) continue;
            if (!member.controls) {
                const controls = document.createElement('nav');
                controls.setAttribute('aria-label', 'Liste sayfaları');
                controls.style.cssText = 'display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;margin:16px 0;grid-column:1/-1';
                const previous = document.createElement('button'); previous.type = 'button'; previous.textContent = '← Önceki';
                const next = document.createElement('button'); next.type = 'button'; next.textContent = 'Sonraki →';
                const label = document.createElement('span'); label.setAttribute('aria-live', 'polite');
                previous.onclick = () => navigate(group, Math.max(0, group.page - 1));
                next.onclick = () => navigate(group, Math.min(pagesFor(group) - 1, group.page + 1));
                controls.append(previous, label, next);
                target.before(controls);
                member.controls = {previous, next, label};
            }
            member.controls.previous.disabled = group.loading || group.page === 0;
            member.controls.next.disabled = group.loading || group.page >= pages - 1;
            member.controls.label.textContent = `${(group.total ?? group.data.length) ? group.page * size + 1 : 0}–${Math.min((group.page + 1) * size, group.total ?? group.data.length)} / ${group.total ?? group.data.length} kayıt · Sayfa ${group.page + 1}/${pages}`;
        }
    }
    function pagesFor(group) { return Math.max(1, Math.ceil((group.total ?? group.data.length) / size)); }
    function register(name, functions) {
        const group = {data: [], page: 0, members: []};
        groups.set(name, group);
        for (const [fn, target] of functions) {
            if (typeof window[fn] !== 'function') continue;
            const member = {render: window[fn], target};
            group.members.push(member);
            window[fn] = data => {
                if (data !== group.data) { group.data = Array.isArray(data) ? data : []; group.page = 0; }
                paint(group);
            };
        }
    }
    async function navigate(group, page) {
        if (group.remote) {
            try { await requestPage(group, page); }
            catch (error) { if (error.name !== 'AbortError') alert(error.message); }
        } else { group.page = page; paint(group); }
    }
    async function requestPage(group, page) {
        group.controller?.abort();
        const controller = new AbortController(); group.controller = controller;
        group.loading = true;
        group.members.forEach(m => { if (m.controls) { m.controls.previous.disabled = true; m.controls.next.disabled = true; } });
        try {
            const url = new URL(group.url, location.origin);
            url.searchParams.set('page', page + 1); url.searchParams.set('page_size', size);
            const response = await fetch(url, {signal: controller.signal});
            const payload = await response.json();
            if (!response.ok) throw new Error(typeof payload.detail === 'string' ? payload.detail : 'Liste alınamadı');
            if (controller.signal.aborted) return;
            if (!Array.isArray(payload.items)) throw new Error('Sayfalama yanıtı uyumsuz; uygulamayı yeniden başlatın.');
            group.page = payload.page - 1; group.total = payload.total; group.data = payload.items;
            group.loading = false;
            paint(group);
            group.onData?.(payload);
        } finally {
            if (group.controller === controller) {
                group.loading = false;
                group.members.forEach(m => { if (m.controls) { m.controls.previous.disabled = group.page === 0; m.controls.next.disabled = group.page >= pagesFor(group) - 1; } });
            }
        }
    }
    window.ListPagination = {
        visible: name => groups.has(name) ? visible(groups.get(name)) : [],
        async load(name, url, onData) {
            const group = groups.get(name); if (!group) throw new Error('Liste bulunamadı');
            group.remote = true; group.url = url; group.onData = onData;
            try { await requestPage(group, 0); } catch (error) { if (error.name !== 'AbortError') throw error; }
        },
        async all(name, idsOnly = false) {
            const group = groups.get(name); if (!group?.url) return [];
            const url = new URL(group.url, location.origin);
            url.searchParams.delete('page'); url.searchParams.delete('page_size');
            if (idsOnly) url.searchParams.set('ids_only', 'true');
            const response = await fetch(url); if (!response.ok) throw new Error('Dışa aktarılacak kayıtlar alınamadı');
            return response.json();
        },
        clear(name) {
            const group = groups.get(name); if (!group) return;
            group.controller?.abort(); group.remote = false; group.url = null; group.total = 0; group.data = []; group.page = 0;
            paint(group);
        }
    };
    if (document.getElementById('cycleContainer')) {
        register('entry', [['renderCycleCards', '#cycleContainer']]);
    } else {
        register('cycles', [['renderCycleCards', '#cyclesContainer'], ['renderTable', '#cycleTable']]);
        register('products', [['renderProductCards', '#productsContainer'], ['renderProductTable', '#productTable']]);
        register('sensors', [['renderSensorCards', '#sensorsContainer'], ['renderSensorTable', '#sensorTable']]);
        register('machineLogs', [['renderMachineLogChart', '#machineLogCards']]);
    }
    function settings() {
        const panel = document.createElement('details');
        panel.style.cssText = 'margin:16px;padding:14px;background:#fff;border:1px solid #cbd5e1;border-radius:10px;color:#1e293b';
        const summary = document.createElement('summary'); summary.textContent = 'Listeleme ayarları';
        const label = document.createElement('label'); label.textContent = 'Sayfa başına kayıt: ';
        const select = document.createElement('select'); select.setAttribute('aria-label', 'Sayfa başına kayıt');
        for (let n = 10; n <= 100; n += 10) { const option = new Option(String(n), String(n)); option.selected = n === size; select.add(option); }
        select.onchange = () => {
            const value = Number(select.value); if (!valid(value)) return;
            size = value;
            try { localStorage.setItem(key, String(size)); } catch (_) {}
            groups.forEach(group => { if (group.remote) navigate(group, 0); else { group.page = 0; if (group.members.length) paint(group); } });
        };
        label.append(select); panel.append(summary, label);
        (document.querySelector('main') || document.querySelector('.container') || document.body).prepend(panel);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', settings); else settings();
})();
