(() => {
  'use strict';
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const local = value => value ? value.slice(0, 19) : '';
  const display = value => value ? new Date(value).toLocaleString('tr-TR') : 'Bilinmiyor';
  const quality = value => ({GOOD:'Okuma başarılı',PARTIAL:'Okuma kısmen başarılı',OFFLINE:'Cihazdan yanıt yok',UNKNOWN:'Güncel cihaz okuması yok'}[value] || 'Okuma durumu bilinmiyor');
  const phase = value => value === 'cooking' || value === 'START' ? 'Pişirme' : value === 'renewal' || value === 'STOP' ? 'Yenileme' : 'Bilinmiyor';
  const alertPreferenceKey = 'ozdekan.cycleRecovery.autoAlerts';
  let automaticAlerts = false;
  try { automaticAlerts = localStorage.getItem(alertPreferenceKey) === 'true'; } catch (_) {}
  let pending = [], history = [], busy = false, dismissed = Number(new URLSearchParams(location.search).get('cycle_id')) > 0;
  let pollVersion = 0, shellReady = false;
  const recoveryForms = new Map(), historyForms = new Map();
  const style = document.createElement('style');
  style.textContent = `.cr-badge{position:fixed;bottom:18px;right:18px;z-index:9998;background:#9a3412;color:white;border:0;border-radius:10px;padding:12px 18px;cursor:pointer;box-shadow:0 4px 18px #0003;font:600 14px system-ui}.cr-dialog{border:0;border-radius:14px;padding:24px;max-width:760px;width:calc(100% - 48px);max-height:85vh;overflow:auto;color:#18212f;background:white;font:15px system-ui}.cr-dialog::backdrop{background:#0007}.cr-dialog h2{margin-top:0}.cr-card{border:1px solid #d3d9e2;padding:18px;border-radius:10px;margin:16px 0}.cr-card label{display:block;margin:12px 0}.cr-card input,.cr-card select,.cr-card textarea{display:block;box-sizing:border-box;width:100%;padding:9px;border:1px solid #aab5c5;border-radius:6px;font:inherit;margin-top:5px}.cr-card button,.cr-dialog>button{padding:10px 14px;cursor:pointer;border-radius:6px;border:1px solid #aab5c5}.cr-card button[type=submit]{background:#1d4ed8;color:white}.cr-meta{background:#f1f5f9;padding:12px;line-height:1.7;border-radius:8px}.cr-error{color:#b91c1c;white-space:pre-wrap}.cr-note{color:#64748b;font-size:13px}.cr-card [hidden]{display:none !important}.cr-setting{display:flex;align-items:center;justify-content:space-between;gap:20px;margin:18px 0;padding:16px;background:#f3f6fa;border:1px solid #dce4ed;border-radius:10px;cursor:pointer}.cr-setting span{font-weight:600}.cr-setting small{display:block;margin-top:5px;font-size:12px;line-height:1.5;font-weight:400;color:#66778b}.cr-setting input{appearance:none;-webkit-appearance:none;width:44px;height:25px;flex-shrink:0;margin:0;border:0;border-radius:20px;background:#9aa8ba;position:relative;cursor:pointer}.cr-setting input::after{content:"";position:absolute;top:3px;left:3px;width:19px;height:19px;border-radius:50%;background:white;transition:transform .15s}.cr-setting input:checked{background:#132b49}.cr-setting input:checked::after{transform:translateX(19px)}.cr-setting input:focus-visible{outline:3px solid #3f85de;outline-offset:3px}`;
  document.head.append(style);
  const badge = document.createElement('button'); badge.className = 'cr-badge'; badge.hidden = true;
  badge.type = 'button'; badge.addEventListener('click', () => { dismissed = false; render(true); poll(); });
  document.body.append(badge);
  const dialog = document.createElement('dialog'); dialog.className = 'cr-dialog'; document.body.append(dialog);
  dialog.addEventListener('cancel', () => { dismissed = true; });
  function renderProductError(container, detail) {
    container.replaceChildren();
    const message = document.createElement('p');
    message.textContent = typeof detail === 'object' && detail ? detail.message || 'İşlem başarısız' : detail || 'İşlem başarısız';
    container.append(message);
    if (detail?.code === 'ACTIVE_CYCLE_PRODUCTS') {
      const link = document.createElement('a');
      link.href = detail.products_url; link.textContent = 'Bağlı ürünleri göster ve geri al';
      container.append(link);
      const list = document.createElement('ul');
      for (const product of detail.products || []) {
        const item = document.createElement('li'); item.textContent = `Ürün #${product.id} · Seri: ${product.serial_number}`; list.append(item);
      }
      container.append(list);
    }
  }
  window.CycleProductGuidance = {
    render: renderProductError,
    show(detail) {
      const guidance = document.createElement('dialog'); guidance.className = 'cr-dialog';
      const title = document.createElement('h2'); title.textContent = 'Cycle işlemi tamamlanamadı';
      const body = document.createElement('div'); renderProductError(body, detail);
      const close = document.createElement('button'); close.type = 'button'; close.textContent = 'Kapat';
      close.onclick = () => guidance.close();
      guidance.addEventListener('close', () => guidance.remove());
      guidance.append(title, body, close); document.body.append(guidance); guidance.showModal();
    }
  };
  const field = (name, title, value = '') => `<label>${title}<input type="datetime-local" step="1" name="${name}" value="${esc(local(value))}"></label>`;
  function stopTime(c) {
    if (!c?.cooking_start_time || c.cooking_duration == null) return '';
    // Format in browser local time, preserving the application's local-time contract.
    const date = new Date(new Date(c.cooking_start_time).getTime() + c.cooking_duration * 60000);
    const pad = n => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  }
  function recoveryForm(item) {
    const c = item.cycle;
    const form = document.createElement('form'); form.className = 'cr-card'; form.dataset.machineId = item.machine_id;
    form.innerHTML = `<h3>${esc(item.machine_name)} · ${c ? 'Cycle #' + c.id : 'Başlangıcı bilinmeyen üretim'}</h3>
        <div class="cr-meta">Gerçek başlangıç: <b>${esc(display(c?.cycle_start_time))}</b><br>Son kaydedilen aşama: ${esc(phase(item.last_known_phase))} · ${esc(display(item.last_known_at))}<br>${item.reason_label ? 'Doğrulama nedeni: ' + esc(item.reason_label) + '<br>' : ''}Referans anı: <b>${esc(display(item.reference_at))}</b> · ${esc(phase(item.reference_phase))}<br><span data-live>Son cihaz okuması: ${esc(phase(item.live_phase))} · ${esc(display(item.live_at))} · ${esc(quality(item.quality))}<br>Bekleyen geçiş: ${item.buffered_events}</span></div>
        <p class="cr-note">Pişirme / yenileme seçimi referans anını anlatır; onay butonuna bastığınız anı değil. Tarih ve saatleri cihazın yerel saatine göre girin.</p>
        <label>İşlem<select name="action">${c ? '<option value="continue">Aynı cycle devam ediyor</option>' + (item.reference_phase === 'renewal' ? '<option value="finished">Bu cycle bitti</option>' : '') : ''}<option value="new">Önceki cycle geçersiz; yeni cycle oluştur</option></select></label>
        <label data-phase>Referans anındaki aşama<select name="phase"><option value="cooking">Pişirme</option><option value="renewal">Yenileme</option></select></label>
        <div data-start>${field('cycle_start_time', 'Yeni cycle başlangıç tarih ve saati')}</div>
        <div data-stop>${field('cooking_end_time', 'Pişirme bitiş tarih ve saati', stopTime(c))}</div>
        <div data-end>${field('cycle_end_time', 'Cycle bitiş tarih ve saati')}</div>
        <label>Açıklama (zorunlu)<textarea name="note" required placeholder="Örn. Program yeniden açıldı; aynı üretim devam ediyor."></textarea></label>
        <p class="cr-note" data-replace>Yeni cycle seçilirse önceki kayıt silinmez; geçersiz olarak korunur. Ürün bağlantıları denetim için korunur.</p>
        <p class="cr-error" role="alert"></p><button type="submit" ${item.reference_at ? '' : 'disabled'}>${item.reference_at ? 'Doğrula ve devam et' : 'Timer okuması bekleniyor'}</button>`;
    const phaseSelect = form.elements.phase;
    phaseSelect.value = item.reference_phase || 'cooking';
    for (const option of phaseSelect.options) option.disabled = Boolean(item.reference_phase && option.value !== item.reference_phase);
    function update() {
      const action = form.elements.action.value, renewal = phaseSelect.value === 'renewal';
      form.querySelector('[data-phase]').hidden = action === 'finished';
      form.querySelector('[data-start]').hidden = action !== 'new';
      form.querySelector('[data-stop]').hidden = action !== 'finished' && !renewal;
      form.querySelector('[data-end]').hidden = action !== 'finished';
      form.querySelector('[data-replace]').hidden = action !== 'new';
      form.elements.cycle_start_time.required = action === 'new';
      form.elements.cooking_end_time.required = (action !== 'finished' && renewal) || (action === 'finished' && c?.cooking_duration == null);
      form.elements.cycle_end_time.required = action === 'finished';
      for (const [name, visible] of [['cycle_start_time', action === 'new'], ['cooking_end_time', action === 'finished' || renewal], ['cycle_end_time', action === 'finished']]) {
        form.elements[name].disabled = !visible;
        form.elements[name].max = local(item.reference_at);
      }
      phaseSelect.disabled = action === 'finished';
    }
    form.elements.action.onchange = update; phaseSelect.onchange = update; update();
    form.onsubmit = event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(form));
      if (form.dataset.stale || busy) return;
      if (data.action !== 'finished' && data.phase === 'cooking') delete data.cooking_end_time;
      submit(form, `/cycle-recovery/${item.machine_id}`, {...data, revision: item.revision});
    };
    return form;
  }
  function historyForm(c) {
    const form = document.createElement('form'); form.className = 'cr-card'; form.id = `cycle-review-${c.id}`;
    const candidates = history.filter(other => other.machine_id === c.machine_id && other.id !== c.id);
    form.innerHTML = `<h4>${esc(c.machine_name)} · Cycle #${c.id}</h4><div class="cr-meta">Başlangıç: ${esc(display(c.cycle_start_time))}<br>Bitiş: ${esc(display(c.cycle_end_time))}<br>Geçmiş görev kaydı: ${c.linked_tasks}<br>Aktif ürün bağlantısı: ${c.active_products ?? 0}<br>${esc(c.recovery_note)}</div>${c.active_products ? `<p>Cycle’ı geçersizleştirmek için önce bağlı ürünleri geri alın. <a href="${esc(c.products_url)}">Bağlı ürünleri göster ve geri al</a></p>` : ''}
        <label>İşlem<select name="action"><option value="correct">Zamanları doğrula / aynı üretim kayıtlarını birleştir</option><option value="invalidate">Bu kayıt geçersiz</option></select></label>
        <div data-correct>${field('cycle_start_time', 'Gerçek başlangıç', c.cycle_start_time)}${field('cooking_end_time', 'Gerçek pişirme bitişi', stopTime(c))}${field('cycle_end_time', 'Gerçek cycle bitişi', c.cycle_end_time)}
        <label>Aynı üretimse birleştirilecek diğer cycle kimlikleri (virgülle ayırın)<input name="merge_ids" placeholder="Örn. 8, 9"></label><p class="cr-note" data-candidates>İnceleme bekleyen diğer kayıtlar: ${esc(candidates.map(other => `#${other.id} (${display(other.cycle_start_time)})`).join('; ') || 'Yok')}</p></div>
        <label>Açıklama (zorunlu)<textarea name="note" required></textarea></label><p class="cr-error" role="alert"></p><button type="submit">Geçmiş kaydı düzelt</button>`;
    function update() {
      const correcting = form.elements.action.value === 'correct';
      form.querySelector('[data-correct]').hidden = !correcting;
      for (const name of ['cycle_start_time','cooking_end_time','cycle_end_time']) { form.elements[name].required = correcting; form.elements[name].disabled = !correcting; }
      form.elements.merge_ids.disabled = !correcting;
    }
    form.elements.action.onchange = update; update();
    form.onsubmit = event => {
      event.preventDefault(); if (form.dataset.stale || busy) return; const data = Object.fromEntries(new FormData(form));
      const mergeText = String(data.merge_ids || '').trim();
      const ids = mergeText ? mergeText.split(',').map(s => Number(s.trim())) : [];
      if (ids.some(id => !Number.isInteger(id) || id <= 0)) { form.querySelector('.cr-error').textContent = 'Cycle kimlikleri pozitif tam sayı olmalı.'; return; }
      submit(form, `/cycle-history-review/${c.id}`, {...data, merge_ids: data.action === 'correct' ? ids : []});
    };
    return form;
  }
  const recoveryKey = item => JSON.stringify([item.revision, item.reference_at, item.reference_phase, item.cycle]);
  const historyKey = item => JSON.stringify(item);
  function setStatus(message) {
    ensureShell();
    dialog.querySelector('[data-status]').textContent = message;
  }
  function ensureShell() {
    if (shellReady) return;
    shellReady = true;
    dialog.innerHTML = `<h2>Cycle doğrulaması</h2><p>Program kapalıyken gerçekleşen geçişler kesin bilinemez. Aşağıdaki karar, belirtilen referans anı içindir. Onay beklenirken sonraki sinyaller kaydedilir ve onaydan sonra sırayla uygulanır.</p><label class="cr-setting"><span>Cycle doğrulaması gerektiğinde otomatik uyar<small>Açıksa doğrulama gerektiğinde bu pencere otomatik açılır. Tercihiniz bu tarayıcıda saklanır.</small></span><input type="checkbox" role="switch" data-auto-alert aria-label="Cycle doğrulaması gerektiğinde otomatik uyar" ${automaticAlerts ? 'checked' : ''}></label><button type="button" data-close>Kapat / Sonra incele</button><p class="cr-note" data-status role="status"></p><p class="cr-note" data-empty hidden>Şu anda doğrulama veya geçmiş incelemesi bekleyen cycle yok.</p><div data-pending></div><div data-history></div>`;
    dialog.querySelector('[data-auto-alert]').onchange = event => {
      automaticAlerts = event.target.checked;
      dismissed = false;
      try { localStorage.setItem(alertPreferenceKey, String(automaticAlerts)); } catch (_) {}
    };
    dialog.querySelector('[data-close]').onclick = () => { dismissed = true; dialog.close(); };

  }
  function markStale(form, refresh) {
    if (form.dataset.stale) return;
    form.dataset.stale = 'true';
    form.querySelector('button[type=submit]').disabled = true;
    const warning = document.createElement('div'); warning.className = 'cr-error'; warning.dataset.staleWarning = 'true';
    const message = document.createElement('p');
    message.textContent = 'Bu doğrulama değişti. Yazdığınız bilgiler korunuyor, ancak eski referansla gönderilemez. Güncel kaydı açarken bu karta yazdıklarınız sıfırlanır; yeni referans saatini kontrol edin.';
    const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Güncel doğrulama listesini aç';
    button.onclick = refresh;
    warning.append(message, button); form.prepend(warning);
  }
  async function refreshForm(form) {
    if (busy || !await poll()) return;
    const isRecovery = form.dataset.machineId !== undefined;
    const forms = isRecovery ? recoveryForms : historyForms;
    const id = isRecovery ? Number(form.dataset.machineId) : Number(form.id.replace('cycle-review-', ''));
    const current = (isRecovery ? pending : history).find(row => (isRecovery ? row.machine_id : row.id) === id);
    const entry = forms.get(id);
    if (!current || !entry) return;
    const replacement = {key: (isRecovery ? recoveryKey : historyKey)(current), form: (isRecovery ? recoveryForm : historyForm)(current)};
    entry.form.replaceWith(replacement.form); forms.set(id, replacement);
  }
  function reconcile(items, forms, idOf, keyOf, build, container) {
    const present = new Set(items.map(idOf));
    for (const [id, entry] of forms) {
      if (!present.has(id)) { entry.form.remove(); forms.delete(id); }
    }
    for (const item of items) {
      const id = idOf(item), key = keyOf(item);
      let entry = forms.get(id);
      if (!entry) {
        entry = {key, form: build(item)}; forms.set(id, entry); container.append(entry.form);
      } else if (entry.key !== key) {
        markStale(entry.form, () => refreshForm(entry.form));
      }
      const candidates = entry.form.querySelector('[data-candidates]');
      if (candidates) candidates.textContent = 'İnceleme bekleyen diğer kayıtlar: ' + (items.filter(other => other.machine_id === item.machine_id && other.id !== item.id).map(other => `#${other.id} (${display(other.cycle_start_time)})`).join('; ') || 'Yok');
      const live = entry.form.querySelector('[data-live]');
      if (live) live.textContent = `Son cihaz okuması: ${phase(item.live_phase)} · ${display(item.live_at)} · ${quality(item.quality)}. Bekleyen geçiş: ${item.buffered_events}`;
    }
  }
  function render(show = false) {
    ensureShell();
    reconcile(pending, recoveryForms, item => item.machine_id, recoveryKey, recoveryForm, dialog.querySelector('[data-pending]'));
    reconcile(history, historyForms, item => item.id, historyKey, historyForm, dialog.querySelector('[data-history]'));
    dialog.querySelector('[data-empty]').hidden = Boolean(pending.length + history.length);
    if (show && !dialog.open) dialog.showModal();
    const reviewId = Number(new URLSearchParams(location.search).get('review_cycle_id'));
    if (show && Number.isInteger(reviewId) && reviewId > 0) dialog.querySelector(`#cycle-review-${reviewId}`)?.scrollIntoView({block:'center'});
  }
  async function submit(form, url, payload) {
    if (busy || form.dataset.stale || form.dataset.submitted) return;
    busy = true;
    ++pollVersion; // Ignore every GET started before this write.
    const button = form.querySelector('button[type=submit]'); button.disabled = true;
    let succeeded = false;
    try {
      const fingerprint = JSON.stringify(payload);
      if (!form.recoveryAttempt || form.recoveryAttempt.fingerprint !== fingerprint) {
        const requestId = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        form.recoveryAttempt = {fingerprint, body: JSON.stringify({...payload, request_id: requestId})};
      }
      const response = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:form.recoveryAttempt.body});
      const data = await response.json();
      if (!response.ok) { const error = new Error(typeof data.detail === 'object' ? data.detail.message : data.detail || 'Kayıt başarısız'); error.detail = data.detail; throw error; }
      succeeded = true; form.dataset.submitted = 'true';
      if (url.startsWith('/cycle-recovery/')) {
        const id = Number(url.split('/').pop());
        pending = pending.filter(item => item.machine_id !== id);
      } else {
        const ids = new Set([Number(url.split('/').pop()), ...(payload.merge_ids || [])]);
        history = history.filter(item => !ids.has(item.id));
      }
      render();
      setStatus(data.message || 'Doğrulama başarıyla kaydedildi.');
      busy = false;
      const refreshed = await poll(false, true);
      if (refreshed && pending.length) setStatus((data.message || 'Doğrulama kaydedildi.') + ' Listede ayrı bir doğrulama bekleyen kayıt var; referans saatini kontrol edin.');
      if (typeof window.fetchCycles === 'function') window.fetchCycles();
    } catch (error) {
      renderProductError(form.querySelector('.cr-error'), error.detail || error.message);
      if (!error.detail) setStatus('Sunucudan kesin sonuç alınamadı. Aynı bilgileri tekrar gönderirseniz aynı istek kimliği kullanılır.');
      if (String(error.detail || error.message).includes('Bu doğrulama değişti veya zaten tamamlandı')) {
        markStale(form, () => refreshForm(form));
        // Reconcile now, but leave this draft bound to its original revision.
        busy = false; await poll();
      }
    } finally {
      busy = false;
      if (!succeeded && !form.dataset.stale) button.disabled = false;
    }
  }
  async function poll(show = false, afterSuccess = false) {
    if (busy) return false;
    const version = ++pollVersion;
    try {
      const responses = await Promise.all([fetch('/cycle-recovery'), fetch('/cycle-history-review')]);
      if (responses.some(r => !r.ok)) throw new Error('Cycle doğrulama listesi alınamadı');
      const rows = await Promise.all(responses.map(r => r.json()));
      if (version !== pollVersion || busy) return false;
      [pending, history] = rows;
      const count = pending.length + history.length;
      badge.hidden = false; badge.textContent = count ? `Cycle doğrulaması (${pending.length}) · Geçmiş inceleme (${history.length})` : 'Cycle doğrulaması';
      render(show || Boolean(count && automaticAlerts && !dismissed));
      return true;
    } catch (error) {
      if (version !== pollVersion || busy) return false;
      badge.hidden = false; badge.textContent = 'Cycle doğrulaması alınamadı · Tekrar dene';
      if (afterSuccess) setStatus('Doğrulama başarıyla kaydedildi. Güncel liste alınamadı; tekrar doğrulama göndermeyin. Listeyi yeniden açın.');
      else if (dialog.open) setStatus('Güncel liste alınamadı. Yazdığınız bilgiler korunuyor; bağlantıyı kontrol edip listeyi yeniden açın.');
      console.error(error); return false;
    }
  }
  const requestedReview = Number(new URLSearchParams(location.search).get('review_cycle_id')) > 0;
  poll(requestedReview); setInterval(() => { if (!busy) poll(); }, 5000);
})();
