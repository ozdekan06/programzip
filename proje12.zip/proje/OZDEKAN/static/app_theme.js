/* Theme-only enhancements; no device, database or polling operations. */
(() => {
    document.querySelector('[data-app-logout]')?.addEventListener('click', () => {
        localStorage.removeItem('isLoggedIn');
        location.href = '/static/login.html';
    });
    document.querySelectorAll('table').forEach(table => {
        if (table.closest('.app-table-scroll')) return;
        const wrapper = document.createElement('div');
        wrapper.className = 'app-table-scroll';
        wrapper.tabIndex = 0;
        wrapper.setAttribute('role', 'region');
        wrapper.setAttribute('aria-label', 'Yatay kaydırılabilir tablo');
        table.before(wrapper);
        wrapper.append(table);
    });
})();
