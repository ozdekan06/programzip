# Ürün giriş performans düzeltmesi

19 Ekim 2026, gerçek Safari ve geçici SQLite ile doğrulandı. Veri seti önceki
testle aynı: 500 cycle, 7.500 timer kaydı, 1 sipariş, her cycle için 1 kalıp.

| Ölçüm | Önce | Sonra |
|---|---:|---:|
| 500 bekleyen cycle, tüm kart bilgileri | 1,216 sn | 0,552 sn |
| 250 kayıtlı ürün / 250 kalan kart, tüm bilgiler | 15,578–18,452 sn | 1,161 sn |
| Ekrandan 251. ürün kaydı sonrası güncelleme | 16,350 sn (yalnız yenileme) | 0,519 sn (kayıt ve güncelleme) |
| Orta aşamada sipariş durumu sorguları, sayfa yükleme | 250 | 1 |

Sürelerde 300 ms sessizlik kontrolü var. Başarı uyarısında beklenen süre hariçtir.
Önceki kayıt ölçümü yalnız yenilemeydi; yeni ölçüm kayıt isteğini de kapsar.
Sonraki süre toplam 3 istek içerir: güncel sipariş kontrolü, ürün POST isteği,
güncel sipariş durumunun kalan kartlarla paylaşılması. Cycle/task listesi yeniden
alınmaz. Tarayıcı otomasyon aracının erişilebilirlik ağacını okuma süresi bu
ölçümlere dahil değildir. Bunlar bu test ortamındaki tekil ölçümlerdir.

UI doğrulaması: BENCH/251 için ürün kartı oluşturuldu, kaydet düğmesine basıldı,
başarı uyarısı görüldü. Sonrasında #500 kartı kaldırıldı; #499 kartında 251 ürün
ve sıradaki seri BENCH/252 göründü. Ardından 500 bekleyen cycle senaryosunun
tek sipariş durumu isteğiyle yüklenmesi tekrar ölçüldü.

Ek JavaScript VM kontrolleri: 500 kartın eşzamanlı okumalarında tek sorgu;
sonraki işlemde yeniden okuma; hata sonrası tekrar deneme; başarılı kayıtta tam
yenileme yapılmaması; çift tıklamada tek kayıt; kalan kartın güncel seri bilgisi;
eski seri ile kaydın engellenmesi; ağ hatasında kayıt kilidinin kaldırılması.

Değişen uygulama dosyası: static/urun.html. Veritabanı yapısı değiştirilmedi.
Ham ölçümler: browser_cycle_500_after.jsonl.
