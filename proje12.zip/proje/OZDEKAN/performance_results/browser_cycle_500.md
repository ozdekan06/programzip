# Safari ile 500 cycle testi

19 Ekim 2026. Gerçek Safari arayüzünde, localhost üzerindeki uygulama ile test edildi.
Üretim veritabanı yerine geçici disk SQLite kullanıldı; cihaz bağlantıları ve arka
plan okuyucuları başlatılmadı. Uygulamanın ürün ekranı ve API iş mantığı değiştirilmedi.
Test sayfasına yalnızca istek sürelerini ve kart sayısını kaydeden ölçüm eklendi.

Veri: 1 makine, 1 sipariş, 1 personel, 500 tamamlanmış cycle, 7.500 timer kaydı.
Her cycle siparişe atanmış ve 1 kalıp içeriyor. Orta aşama için ilk 250 cycle'ın
ürünleri test veritabanında önceden oluşturuldu; 500 kayıt tarayıcıdan tek tek
girilmedi. Orta aşamada bir ürün gerçek ekran düğmeleriyle oluşturulup kaydedildi.

| Aşama | Kalan kart | Sipariş durumu isteği | Hazır olma süresi |
|---|---:|---:|---:|
| 500 bekleyen cycle | 500 | 500 | 1,216 sn |
| 250 ürün önceden kaydedilmiş | 250 | 250 | 15,578 sn |
| 250 ürün önceden kaydedilmiş, ikinci yükleme | 250 | 250 | 18,452 sn |
| Ekrandan BENCH/251 kaydedildikten sonra | 249 | 249 | 16,350 sn |

Süreler fetchCycles başlangıcından ilgili isteklerin bitmesi ve 300 ms sessizlik
kontrolüne kadardır. Tüm kartların sipariş bilgilerinin tamamlanmasını ifade eder;
ilk görünür kartın çizim süresi veya tarayıcı donma süresi değildir. Kayıt başarı
uyarısında kullanıcının beklediği süre yenileme ölçümüne dahil değildir.
Toplam istek süreleri eşzamanlı istekleri toplar; gerçek bekleme olarak yorumlanmamalıdır.

UI doğrulaması: “1 ürün başarıyla kaydedildi” uyarısı görüldü. Uyarı kapatılınca
cycle #500 listeden çıktı, ilk kart #499 oldu. Sipariş toplamı 250'den 251'e,
sıradaki seri BENCH/251'den BENCH/252'ye ilerledi. Yenilemede 249 kart ölçüldü.

Sonuç: Bu senaryoda kayıt sonrası tüm kart bilgilerinin yeniden yüklenmesi belirgin
yavaşlıyor. Her kart ayrı sipariş durumu istiyor; sipariş sayımları ürün başına ek
sorgu yapıyor. Bütün cycle ve task geçmişinin her kayıtta tekrar alınması da ek yük.
Bu ölçümler aynı bilgisayardaki Safari içindir; başka donanım, ağ, sipariş/kalıp
sayısı ve canlı cihaz yükünde süreler değişebilir. Performans düzeltmesi yapılmadı.

Ham tarayıcı ölçümleri: browser_cycle_500.jsonl.
