import asyncio
from database import SessionLocal, data_dir
from models import AlarmLog, Machine, SensorLog, TimerLog, CycleLog, CycleEvent, Product, Order
import connection_api 
import time
import math
import os
import hashlib
import json
import tempfile
from pathlib import Path


# BCD'den int'e çeviren fonksiyon
def bcd_to_int(bcd):
    result = 0
    multiplier = 1
    while bcd > 0:
        digit = bcd & 0xF
        result += digit * multiplier
        bcd >>= 4
        multiplier *= 10
    return result


# BCD'den float'a çeviren fonksiyon (son n hane ondalık)
def bcd_to_float(bcd, decimal_digits=2):
    s = str(bcd_to_int(bcd)).zfill(decimal_digits+2)
    if len(s) > decimal_digits:
        return float(s[:-decimal_digits] + '.' + s[-decimal_digits:])
    else:
        return float('0.' + s[-decimal_digits:])

# Timer value + time base -> dakika
def timer_value_to_minutes(bcd_value, time_base):
    """Convert timer raw BCD value to minutes based on time_base.

    Mappings (examples with raw 0x1234 → decimal 1234 via BCD):
    - 0: 99.99s  → 12.34 s  → 0.2057 min
    - 1: 999.9s  → 123.4 s  → 2.0566 min
    - 2: 9999s   → 1234 s   → 20.5666 min
    - 3: 99m59s  → 12m34s   → 12 + 34/60 min
    - 4: 999.9m  → 123.4 m  → 123.4 min
    - 5: 9999m   → 1234 m   → 1234 min
    - 6: 99h59m  → 12h34m   → 12*60 + 34 min
    - 7: 999.9h  → 123.4 h  → 7404 min
    - 8: 9999h   → 1234 h   → 74040 min
    """
    if time_base == 0:  # 99.99s (0.01s resolution)
        seconds = bcd_to_float(bcd_value, 2)
        return seconds / 60.0
    elif time_base == 1:  # 999.9s (0.1s resolution)
        seconds = bcd_to_float(bcd_value, 1)
        return seconds / 60.0
    elif time_base == 2:  # 9999s (1s resolution)
        seconds = bcd_to_int(bcd_value)
        return seconds / 60.0
    elif time_base == 3:  # 99m59s (MM:SS in BCD)
        mmss = bcd_to_int(bcd_value)
        mm = mmss // 100
        ss = mmss % 100
        # Clamp seconds to 0..59 just in case
        ss = max(0, min(59, ss))
        return mm + (ss / 60.0)
    elif time_base == 4:  # 999.9m (0.1 minute)
        minutes = bcd_to_float(bcd_value, 1)
        return minutes
    elif time_base == 5:  # 9999m (1 minute)
        minutes = bcd_to_int(bcd_value)
        return float(minutes)
    elif time_base == 6:  # 99h59m (HH:MM in BCD)
        hhmm = bcd_to_int(bcd_value)
        hh = hhmm // 100
        mm = hhmm % 100
        # Clamp minutes to 0..59 just in case
        mm = max(0, min(59, mm))
        return hh * 60.0 + mm
    elif time_base == 7:  # 999.9h (0.1 hour)
        hours = bcd_to_float(bcd_value, 1)
        return hours * 60.0
    elif time_base == 8:  # 9999h (1 hour)
        hours = bcd_to_int(bcd_value)
        return hours * 60.0
    else:
        # Fallback: treat as minutes already
        return float(bcd_to_int(bcd_value))
import datetime


def temperature_alarm_limits(holding_registers):
    """Sensör set değeri ve Alarm1Set'ten alt/üst alarm sınırını üret."""
    if not holding_registers or len(holding_registers) <= 12:
        return None
    try:
        set_value = float(holding_registers[0])
        alarm1set = abs(float(holding_registers[12]))
    except (KeyError, TypeError, ValueError):
        return None
    return set_value - alarm1set, set_value + alarm1set


db = SessionLocal()
machines = []  # Arka plan görevlerinin kullanacağı aktif makine listesi
device_profiles = {}  # slave_id -> "sensor", "timer" veya "combined"
sensor_missing_since = {}  # (machine_id, sensor_id) -> ilk eksik okuma zamanı
suspended_device_ids = set()  # Merkezi Modbus okuma engeli
sensor_retry_states = {}  # (machine_id, sensor_id) -> bekleme/deneme durumu
sensor_retry_configs = {}  # (machine_id, sensor_id) -> makineye özel süreler
cycle_sample_progress = {}  # (machine_id, timer_id) -> last durable sample and gap generation
cycle_sample_enqueued = {}
cycle_collection_interrupted = set()
cycle_spool_dir = data_dir / "cycle-spool"
cycle_unwritten_samples = {}
cycle_spool_errors = {}
SENSOR_RECOVERY_SUCCESS_COUNT = 3
SENSOR_RECOVERY_SAMPLE_INTERVAL = 2.0
STARTUP_GRACE_SECONDS = max(0.0, float(os.getenv("MODBUS_STARTUP_GRACE_SECONDS", "15")))
startup_grace_until = time.monotonic() + STARTUP_GRACE_SECONDS


def begin_startup_grace():
    """Yeni baslangicta cihazlara ilk cevaplarini vermeleri icin sure tani."""
    global startup_grace_until
    startup_grace_until = time.monotonic() + STARTUP_GRACE_SECONDS
    sensor_missing_since.clear()


def startup_grace_active() -> bool:
    return time.monotonic() < startup_grace_until

def load_machines():
    """Arka plan görevleri için yalnızca aktif makineleri yeniden yükle."""
    global machines, device_profiles, suspended_device_ids
    session = SessionLocal()
    try:
        # Yeni bir session kullanmak, API'nin başka bir session ile yaptığı
        # is_active değişikliğinin eski ORM nesneleri yüzünden gizlenmesini önler.
        active_machines = session.query(Machine).filter(Machine.is_active.is_(True)).all()
        now = datetime.datetime.now(datetime.timezone.utc)
        in_startup_grace = startup_grace_active()
        changed = False
        for machine in active_machines:
            suspended = dict(getattr(machine, 'sensor_suspended', {}) or {})
            timeout_seconds = max(1, int(getattr(machine, 'sensor_timeout_minutes', 5) or 5)) * 60
            for sensor_id in machine.sensor_ids or []:
                if suspended.get(str(sensor_id)):
                    continue
                data = cache.get(int(sensor_id)) or {}
                read_at = data.get("input_read_at")
                if not read_at:
                    missing_key = (machine.id, int(sensor_id))
                    first_missing = sensor_missing_since.setdefault(missing_key, now)
                    if (now - first_missing).total_seconds() > timeout_seconds:
                        suspended[str(sensor_id)] = True
                        changed = True
                    continue
                sensor_missing_since.pop((machine.id, int(sensor_id)), None)
                try:
                    stale = (now - datetime.datetime.fromisoformat(read_at)).total_seconds() > timeout_seconds
                except (TypeError, ValueError):
                    stale = False
                if stale and not in_startup_grace:
                    suspended[str(sensor_id)] = True
                    changed = True
            if suspended != (getattr(machine, 'sensor_suspended', {}) or {}):
                machine.sensor_suspended = suspended
        if changed:
            session.commit()
            # SQLAlchemy commit sonrasında ORM alanlarını expire eder. Global
            # listede oturumdan ayrılmış ve expire olmuş nesneler bırakmamak
            # için makineleri aynı oturum içinde yeniden yükle.
            active_machines = session.query(Machine).filter(Machine.is_active.is_(True)).all()
        previous_timers = {(machine.id, int(machine.timer_id)) for machine in machines
                           if machine.timer_id is not None}
        current_timers = {(machine.id, int(machine.timer_id)) for machine in active_machines
                          if machine.timer_id is not None}
        cycle_collection_interrupted.update(previous_timers ^ current_timers)
        profiles = {}
        for machine in active_machines:
            for sensor_id in machine.sensor_ids or []:
                sensor_id = int(sensor_id)
                profiles[sensor_id] = "combined" if profiles.get(sensor_id) in {"timer", "combined"} else "sensor"
            if machine.timer_id is not None:
                timer_id = int(machine.timer_id)
                profiles[timer_id] = "combined" if profiles.get(timer_id) in {"sensor", "combined"} else "timer"
        device_profiles = profiles
        timer_ids = {int(machine.timer_id) for machine in active_machines if machine.timer_id is not None}
        suspended_keys = {
            (machine.id, int(sensor_id))
            for machine in active_machines
            for sensor_id in (machine.sensor_ids or [])
            if (getattr(machine, 'sensor_suspended', {}) or {}).get(str(sensor_id))
        }
        for key in list(sensor_retry_states):
            if key not in suspended_keys:
                sensor_retry_states.pop(key, None)
        sensor_retry_configs.clear()
        monotonic_now = time.monotonic()
        for machine in active_machines:
            wait_seconds = max(1, int(getattr(machine, 'sensor_retry_wait_minutes', 5) or 5)) * 60
            window_seconds = max(1, int(getattr(machine, 'sensor_retry_window_minutes', 1) or 1)) * 60
            for sensor_id in machine.sensor_ids or []:
                key = (machine.id, int(sensor_id))
                sensor_retry_configs[key] = {"wait_seconds": wait_seconds, "window_seconds": window_seconds}
                if key not in suspended_keys:
                    continue
                state = sensor_retry_states.setdefault(key, {
                    "phase": "waiting", "until": monotonic_now + wait_seconds,
                    "successes": 0, "last_sample_at": 0.0
                })
                if state["phase"] == "waiting" and monotonic_now >= state["until"]:
                    state.update(phase="probing", until=monotonic_now + window_seconds,
                                 successes=0, last_sample_at=0.0, last_signature=None)
                elif state["phase"] == "probing" and monotonic_now >= state["until"]:
                    state.update(phase="waiting", until=monotonic_now + wait_seconds,
                                 successes=0, last_sample_at=0.0, last_signature=None)

        # Aynı adres timer olarak da kullanılıyorsa timer sorgusunu kesemeyiz.
        # Saf sensör adresleri bekleme evresinde Modbus hattından tamamen çıkarılır.
        suspended_device_ids = {
            sensor_id for machine_id, sensor_id in suspended_keys
            if sensor_id not in timer_ids
            and sensor_retry_states.get((machine_id, sensor_id), {}).get("phase") == "waiting"
        }
        # Yukarıdaki erişimler bütün gerekli scalar alanları yükledi. Artık
        # nesneler arka plan görevlerinde session kapandıktan sonra kullanılabilir.
        session.expunge_all()
        machines = active_machines
        print(f"Aktif makine sayısı: {len(machines)}, Modbus cihazı: {len(device_profiles)}")
    finally:
        session.close()


def _valid_recovery_read(data) -> bool:
    """Bağlantı cevabının sensörü açmak için yeterince güvenilir olduğunu doğrula."""
    if not data or data.get("quality") not in {"GOOD", "PARTIAL"}:
        return False
    inputs = data.get("input_registers") or []
    holdings = data.get("holding_registers") or []
    if not inputs or not holdings:
        return False
    try:
        temperature = float(inputs[0])
        input_at = datetime.datetime.fromisoformat(data["input_read_at"])
        holding_at = datetime.datetime.fromisoformat(data["holding_read_at"])
        now = datetime.datetime.now(datetime.timezone.utc)
        if input_at.tzinfo is None:
            input_at = input_at.replace(tzinfo=datetime.timezone.utc)
        if holding_at.tzinfo is None:
            holding_at = holding_at.replace(tzinfo=datetime.timezone.utc)
    except (KeyError, TypeError, ValueError):
        return False
    fresh = max((now - input_at).total_seconds(), (now - holding_at).total_seconds()) <= 10
    synchronized = abs((input_at - holding_at).total_seconds()) <= 5
    return fresh and synchronized and math.isfinite(temperature) and -200 <= temperature <= 2000


def process_sensor_recovery_read(slave_id: int, data) -> None:
    """Deneme penceresindeki sensörü art arda geçerli okumalarla yeniden aç."""
    now = time.monotonic()
    recovered_keys = []
    for key, state in list(sensor_retry_states.items()):
        if key[1] != int(slave_id) or state.get("phase") != "probing":
            continue
        config = sensor_retry_configs.get(key, {"wait_seconds": 300})
        if now >= state["until"]:
            state.update(phase="waiting", until=now + config["wait_seconds"],
                         successes=0, last_sample_at=0.0, last_signature=None)
            continue
        if now - state.get("last_sample_at", 0.0) < SENSOR_RECOVERY_SAMPLE_INTERVAL:
            continue
        state["last_sample_at"] = now
        signature = (data or {}).get("input_read_at"), (data or {}).get("holding_read_at")
        if signature == state.get("last_signature"):
            continue
        state["last_signature"] = signature
        state["successes"] = state.get("successes", 0) + 1 if _valid_recovery_read(data) else 0
        if state["successes"] >= SENSOR_RECOVERY_SUCCESS_COUNT:
            recovered_keys.append(key)

    if not recovered_keys:
        return
    session = SessionLocal()
    try:
        for machine_id, sensor_id in recovered_keys:
            machine = session.query(Machine).filter(Machine.id == machine_id).first()
            if not machine:
                continue
            suspended = dict(getattr(machine, 'sensor_suspended', {}) or {})
            suspended.pop(str(sensor_id), None)
            machine.sensor_suspended = suspended
            sensor_missing_since.pop((machine_id, sensor_id), None)
            sensor_retry_states.pop((machine_id, sensor_id), None)
        session.commit()
    finally:
        session.close()
    load_machines()


cache = {}  # slave_id -> son okunan veri
active_alarms = {}  # (machine_id, sensor_id, alarm_type) -> AlarmLog nesnesi
last_timer_values = {}  # (machine_id, sensor_id) -> {T1, T1A, out, state}
out_of_range_states = {}  # (machine_id, sensor_id) -> {count, direction}
last_processed_sensor_reads = {}  # (machine_id, sensor_id) -> (input_read_at, holding_read_at)

# Eski importları bozmamak için alias; hattın gerçek kilidi connection_api'dedir.
client_lock = connection_api.bus_lock
INTER_DEVICE_DELAY = float(connection_api._setting("MODBUS_INTER_DEVICE_DELAY", "inter_device_delay", 0.05))
INTER_REQUEST_DELAY = float(connection_api._setting("MODBUS_INTER_REQUEST_DELAY", "inter_request_delay", 0.03))


def _mark_discrete_error(device_cache, error):
    device_cache["discrete_gap_sequence"] = device_cache.get("discrete_gap_sequence", 0) + 1
    device_cache["discrete_gap_pending"] = True
    device_cache["discrete_error_count"] = device_cache.get("discrete_error_count", 0) + 1
    device_cache["discrete_consecutive_errors"] = device_cache.get("discrete_consecutive_errors", 0) + 1
    device_cache["discrete_last_error"] = str(error)
    device_cache["discrete_last_error_at"] = datetime.datetime.now().astimezone().isoformat()


def _sync_cycle_spool_directory():
    # Windows does not permit opening directories with os.open; the journal
    # file itself is fsynced on both platforms before the atomic replacement.
    if os.name == "nt":
        return
    directory_fd = os.open(cycle_spool_dir, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _persist_cycle_sample(name, sample):
    """Journal an acquisition before touching the application database."""
    cycle_spool_dir.mkdir(parents=True, exist_ok=True)
    target = cycle_spool_dir / name
    if target.exists():
        _sync_cycle_spool_directory()
        return
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix=".sample-",
                                         suffix=".tmp", dir=cycle_spool_dir, delete=False) as output:
            temp_path = Path(output.name)
            json.dump(sample, output, ensure_ascii=False, allow_nan=False)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_path, target)
        _sync_cycle_spool_directory()
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def drain_cycle_spool():
    """Replay journaled samples, including acquisitions from a preceding run.

    Call before restart initialization. A failing machine's later samples stay
    queued; another machine can continue. Replaying a commit whose file could
    not be deleted is harmless because observe_timer rejects old timestamps.
    """
    from cycle_service import observe_timer
    failures = {}
    blocked = set()
    blocked_all = False
    for name, sample in list(cycle_unwritten_samples.items()):
        try:
            _persist_cycle_sample(name, sample)
            cycle_unwritten_samples.pop(name, None)
        except (OSError, TypeError, ValueError) as exc:
            blocked.add(sample["machine_id"])
            failures[(sample["machine_id"], sample["timer_id"])] = f"Cycle günlüğü yazılamadı: {exc}"
    queued = []
    try:
        # A crash after fsync but before the atomic rename leaves a complete
        # acquisition in its temporary file. Replay those files too; malformed
        # partial writes are retained and reported instead of being discarded.
        paths = list(cycle_spool_dir.glob("*.json")) + list(cycle_spool_dir.glob(".sample-*.tmp"))
        for path in paths:
            try:
                sample = json.loads(path.read_text(encoding="utf-8"))
                at = datetime.datetime.fromisoformat(sample["at"])
                if sample.get("version") != 1 or type(sample["machine_id"]) is not int or type(sample["timer_id"]) is not int:
                    raise ValueError("Geçersiz cycle günlüğü")
                if at.tzinfo is not None or sample["value"] not in (0, 1) or not isinstance(sample["details"], dict):
                    raise ValueError("Geçersiz cycle örneği")
                datetime.datetime.fromisoformat(sample["raw_at"])
                int(sample["gap_sequence"])
                if type(sample["communication_gap"]) is not bool:
                    raise ValueError("Geçersiz iletişim boşluğu bilgisi")
                queued.append((at, path.name, path, sample))
            except (OSError, ValueError, KeyError, TypeError) as exc:
                # The filename starts with the machine id; malformed samples
                # block that machine instead of silently losing an observation.
                try:
                    blocked.add(int(path.name.split("-", 1)[0]))
                except ValueError:
                    blocked_all = True
                failures[(None, None)] = (f"Cycle günlüğü okunamadı ({path}): {exc}. "
                                          "Dosya korundu; kayıt sırası için inceleme gerekiyor.")
    except OSError as exc:
        failures[(None, None)] = f"Cycle günlüğü açılamadı: {exc}"
    for at, _, path, sample in sorted(queued, key=lambda item: (item[0], item[1])):
        key = (sample["machine_id"], sample["timer_id"])
        if blocked_all or key[0] in blocked:
            continue
        try:
            with SessionLocal() as session:
                observe_timer(session, key[0], sample["value"], at, sample["details"],
                              communication_gap=sample["communication_gap"])
            cycle_sample_progress[key] = {"read_at": sample["raw_at"],
                                          "gap_sequence": sample["gap_sequence"]}
            path.unlink()
        except Exception as exc:
            blocked.add(key[0])
            failures[key] = f"Cycle timer kaydı başarısız: machine={key[0]}: {exc}"
    cycle_spool_errors.clear()
    cycle_spool_errors.update(failures)
    for timer_id, data in list(cache.items()):
        errors = [message for (_, failed_timer), message in failures.items()
                  if failed_timer is None or failed_timer == timer_id]
        data["cycle_collection_error"] = "; ".join(errors) if errors else None
    return list(failures.values())


def record_cycle_sample(slave_id, data, *, fresh=False):
    """Journal every timer read immediately, then collect edges durably.

    Scheduled slow scans are healthy. Failed discrete reads, interrupted
    collection or reactivation are explicit gaps. Missing holdings affect only
    ideal durations; they never prevent acquisition of the real timer edge.
    """
    discrete = data.get("discrete_inputs") or []
    raw_at = data.get("discrete_read_at")
    if len(discrete) <= 6 or not raw_at:
        return
    try:
        at = datetime.datetime.fromisoformat(raw_at)
        if at.tzinfo:
            at = at.astimezone().replace(tzinfo=None)
        age = (datetime.datetime.now() - at).total_seconds()
        if not fresh and (age < 0 or age > 15):
            return
    except (TypeError, ValueError):
        return
    generation = data.get("discrete_sample_gap_sequence", 0)
    failures = []
    consumers = []
    for machine in list(machines):
        key = None
        try:
            if not getattr(machine, "is_active", True) or machine.timer_id is None or int(machine.timer_id) != int(slave_id):
                continue
            key = (machine.id, int(slave_id))
            consumers.append(key)
            previous = cycle_sample_enqueued.get(key, cycle_sample_progress.get(key, {}))
            if previous.get("read_at") == raw_at:
                continue
            details = {"t1_min": None, "t2_min": None}
            holding = data.get("holding_registers") or []
            # A failed holding request does not invalidate the discrete edge.
            # Unknown timer settings remain unknown rather than fabricated zero.
            if len(holding) > 10 and not data.get("holding_last_error"):
                for name, value_index, unit_index in (("t1_min", 0, 2), ("t2_min", 8, 10)):
                    try:
                        if holding[value_index] is not None and holding[unit_index] is not None:
                            details[name] = timer_value_to_minutes(holding[value_index], holding[unit_index])
                    except (TypeError, ValueError, OverflowError):
                        pass
            communication_gap = generation > previous.get("gap_sequence", 0) or key in cycle_collection_interrupted
            sample = {"version": 1, "machine_id": machine.id, "timer_id": int(slave_id),
                      "at": at.isoformat(), "raw_at": raw_at, "value": int(bool(discrete[6])),
                      "details": details, "communication_gap": communication_gap,
                      "gap_sequence": generation}
            digest = hashlib.sha256(f"{machine.id}:{slave_id}:{raw_at}".encode()).hexdigest()
            name = f"{machine.id}-{digest}.json"
            cycle_unwritten_samples[name] = sample
            cycle_sample_enqueued[key] = {"read_at": raw_at, "gap_sequence": generation}
            cycle_collection_interrupted.discard(key)
        except Exception as exc:
            if key is not None:
                cycle_collection_interrupted.add(key)
            failures.append(f"machine={key[0] if key else '?'}: {exc}")
    failures.extend(drain_cycle_spool())
    data["cycle_collection_error"] = "; ".join(failures) if failures else None
    data["discrete_gap_pending"] = bool(failures) or any(
        key in cycle_collection_interrupted or
        cycle_sample_progress.get(key, {}).get("gap_sequence", 0) < data.get("discrete_gap_sequence", 0)
        for key in consumers
    )
    for failure in failures:
        print(failure)


async def read_device_data(slave_id: int):
    """
    Modbus cihazından veri okur.

    İstek timeout'u connection_api içindeki pymodbus istemcisi tarafından
    yönetilir. Burada ayrıca asyncio.wait_for kullanılmaz; aksi halde devam
    eden pymodbus isteği dışarıdan iptal edilerek "Request cancelled outside
    pymodbus" hatasına neden olur.
    
    Args:
        slave_id: Cihaz ID
    Returns:
        dict veya None
    """
    if int(slave_id) in suspended_device_ids:
        return None
    if any(sample["timer_id"] == int(slave_id) for sample in cycle_unwritten_samples.values()):
        drain_cycle_spool()
        if any(sample["timer_id"] == int(slave_id) for sample in cycle_unwritten_samples.values()):
            # Keep the acquired observations in memory if even their journal
            # cannot be written; pause this timer rather than overwrite them.
            _mark_discrete_error(cache.setdefault(slave_id, {}), "Cycle günlüğü yazılamadığı için timer sorgusu bekletildi")
            return None
    start_time = time.time()

    role = device_profiles.get(int(slave_id), "sensor")
    # Alarm ve log kodunun gerçekten tükettiği fonksiyon kodları. Aynı slave
    # Sensörde en yüksek kullanılan adres offset=35; timerda süre birimi=10.
    # Kullanılmayan registerları sorgulamak seri hattın tur süresini uzatır.
    holding_count = 36 if role in ("sensor", "combined") else 11
    requests = [
        ("holding_registers", "holding_read_at", "Holding register", "read_holding_registers", holding_count, "registers")
    ]
    if role in ("sensor", "combined"):
        requests.append(
            ("input_registers", "input_read_at", "Input register", "read_input_registers", 7, "registers")
        )
    elif role == "timer":
        # Timer ekranındaki kalan pişirme/yenileme süreleri input[0] ve
        # input[1]'den gelir. Dört register cihazın timer haritasını kapsar.
        requests.append(
            ("input_registers", "input_read_at", "Input register", "read_input_registers", 4, "registers")
        )
    if role in ("timer", "combined"):
        requests.append(
            ("discrete_inputs", "discrete_read_at", "Discrete input", "read_discrete_inputs", 7, "bits")
        )

    updated = {}
    discrete_error = None
    holding_error = None
    latencies = []
    errors = []
    for request_index, (data_key, time_key, label, method_name, count, value_attr) in enumerate(requests):
        try:
            result, latency_ms = await connection_api.execute(
                method_name, slave_id=slave_id, address=0, count=count
            )
            latencies.append(latency_ms)
            if result.isError():
                errors.append(f"{label}: {result}")
                if data_key == "discrete_inputs":
                    discrete_error = str(result)
                elif data_key == "holding_registers":
                    holding_error = str(result)
                continue

            # Tek timestamp hem değer hem kalite bilgisinin aynı örneğe ait
            # olduğunu garanti eder.
            values = list(getattr(result, value_attr))
            if len(values) < count:
                raise ValueError(f"Eksik {label} cevabı: {len(values)}/{count}")
            updated[data_key] = values
            updated[time_key] = datetime.datetime.now().astimezone().isoformat()
        except asyncio.CancelledError:
            if role in ("timer", "combined"):
                _mark_discrete_error(cache.setdefault(slave_id, {}), "Timer okuma görevi kesildi")
            raise
        except Exception as exc:
            errors.append(f"{label}: {exc}")
            if data_key == "discrete_inputs":
                discrete_error = str(exc)
            elif data_key == "holding_registers":
                holding_error = str(exc)
        finally:
            # Özellikle 9600 baud cihazlarda cevap işlendikten hemen sonra gelen
            # ikinci fonksiyon kodu kaçabiliyor. Son sorgudan sonra cihazlar-arası
            # bekleme zaten periodic_sensor_read içinde uygulanıyor.
            if request_index < len(requests) - 1:
                try:
                    await asyncio.sleep(INTER_REQUEST_DELAY)
                except asyncio.CancelledError:
                    if role in ("timer", "combined"):
                        _mark_discrete_error(cache.setdefault(slave_id, {}), "Timer okuma görevi kesildi")
                    raise

    device_cache = cache.setdefault(slave_id, {})
    previous_discrete_at = device_cache.get("discrete_read_at")
    device_cache["holding_last_error"] = holding_error
    if discrete_error is not None:
        _mark_discrete_error(device_cache, discrete_error)
    if "discrete_read_at" in updated:
        if device_cache.get("discrete_last_error"):
            device_cache["discrete_previous_error"] = device_cache["discrete_last_error"]
        device_cache["discrete_last_error"] = None
        device_cache["discrete_consecutive_errors"] = 0
        device_cache["discrete_sample_gap_sequence"] = device_cache.get("discrete_gap_sequence", 0)
        if previous_discrete_at:
            try:
                device_cache["discrete_poll_interval_seconds"] = round((
                    datetime.datetime.fromisoformat(updated["discrete_read_at"]) -
                    datetime.datetime.fromisoformat(previous_discrete_at)).total_seconds(), 3)
            except (TypeError, ValueError):
                pass
    if updated:
        # Başarısız grupların önceki değerlerini ve tarihlerini koru.
        device_cache.update(updated)
        successful_times = [value for key, value in updated.items() if key.endswith("_read_at")]
        device_cache["read_at"] = max(successful_times)
        device_cache["quality"] = "GOOD" if not errors else "PARTIAL"
        device_cache["last_error"] = "; ".join(errors) if errors else None
        device_cache["latency_ms"] = round(sum(latencies), 2)
        device_cache["sequence"] = device_cache.get("sequence", 0) + 1
        device_cache["consecutive_errors"] = (
            device_cache.get("consecutive_errors", 0) + 1 if errors else 0
        )
    else:
        device_cache["quality"] = "OFFLINE"
        device_cache["last_error"] = "; ".join(errors) or "Cihazdan veri alınamadı"
        device_cache["consecutive_errors"] = device_cache.get("consecutive_errors", 0) + 1

    if "discrete_read_at" in updated:
        record_cycle_sample(slave_id, device_cache, fresh=True)

    for error in errors:
        print(f"❌ Modbus okuma hatası: slave {slave_id}: {error}")

    elapsed = time.time() - start_time
    if elapsed > 1.0:
        print(f"⚠️  Yavaş okuma: slave {slave_id} → {elapsed:.2f}s")

    return cache.get(slave_id) if updated else None




async def write_device_data(slave_id: int, address: int, value: int) -> bool:
    if not 0 <= address <= 0xFFFF or not 0 <= value <= 0xFFFF:
        return False
    try:
        result, _ = await connection_api.execute(
            "write_register", slave_id=slave_id, address=address, value=value
        )
        return not result.isError()
    except Exception as e:
        print(f"Slave {slave_id} yazma hatası: {e}")
        return False






async def periodic_sensor_read():
    next_machine_refresh = 0.0
    while True:
        # DB sorgusunu her hızlı polling turunda değil, seyrek yap.
        now = time.monotonic()
        if now >= next_machine_refresh:
            try:
                load_machines()
            except Exception as e:
                # Geçici bir DB/ORM hatası bütün periyodik okuma görevini
                # sonlandırmamalı; mevcut makine listesiyle çalışmaya devam et.
                print(f"❌ Makine listesi yenilenemedi: {e}")
            next_machine_refresh = now + 5.0

        if not machines:
            print("Aktif makine bulunamadı!")
            await asyncio.sleep(5)
            continue
        
        # machine.sensor_ids’nin tipi ve yapısına göre aşağıdaki kısmı uylaman gerek
        # Örnek: sensor_ids JSON ya da string listesi olabilir. Diyelim JSON listesi:

        # Profil sözlüğü zaten bütün aktif makinelerdeki ID'leri tekilleştirir.
        # Aynı cihaz birden fazla makineye atanmış olsa bile turda yalnızca bir kez okunur.
        for slave_id in device_profiles:
            try:
                data = await read_device_data(slave_id)
                process_sensor_recovery_read(slave_id, data)
                if data is None:
                    print(f"⚠️  Slave {slave_id} veri döndürmedi")
            except Exception as e:
                print(f"❌ Slave {slave_id} okuma hatası: {e}")
                continue
            finally:
                # Bazı RTU cihazları bir sonraki slave isteği hemen geldiğinde
                # ilk frame'i kaçırıyor. Kısa bus-idle süresi 1 sn retry'dan hızlıdır.
                await asyncio.sleep(INTER_DEVICE_DELAY)

        # Tur biter bitmez yeniden başla; küçük yield diğer coroutine'leri aç bırakmaz.
        await asyncio.sleep(0.01)

async def periodic_sensor_log():
    while True:
        try:
            for machine in machines:
                # Skip inactive machines
                if not getattr(machine, 'is_active', True):
                    continue
                for sensor_id in (machine.sensor_ids or []):
                    if (getattr(machine, 'sensor_suspended', {}) or {}).get(str(sensor_id)):
                        continue
                    print(sensor_id)
                    #print(machine.name, machine.sensor_ids)
                    slave_id = int(sensor_id)
                    data = cache.get(slave_id)
                    if not data:
                        continue
                    
                    # Sıcaklık değerleri
                    input_registers = data.get("input_registers", [])
                    holding_registers = data.get("holding_registers", [])
                    value_temp = input_registers[0] if input_registers else None
                    value_temp_set = holding_registers[0] if holding_registers else None
                    value_temp_histerezis = holding_registers[5] if len(holding_registers) > 5 else None
                    alarm_limits = temperature_alarm_limits(holding_registers)

                    # Haberleşme yenilenmediyse aynı eski örneği yeni bir periyot sayma.
                    sensor_key = (machine.id, slave_id)
                    read_signature = (data.get("input_read_at"), data.get("holding_read_at"))
                    if not all(read_signature) or last_processed_sensor_reads.get(sensor_key) == read_signature:
                        continue
                    last_processed_sensor_reads[sensor_key] = read_signature

                    now = datetime.datetime.now()

                    # --- SensorLog (yalnızca set ± histerezis dışında) ---
                    if (
                        value_temp is not None
                        and value_temp_set is not None
                        and value_temp_histerezis is not None
                        and slave_id != machine.timer_id
                    ):
                        lower_limit = value_temp_set - value_temp_histerezis
                        upper_limit = value_temp_set + value_temp_histerezis
                        is_out_of_range = value_temp < lower_limit or value_temp > upper_limit

                        # İlk uygunsuz değeri hemen, uygunsuzluk devam ediyorsa
                        # sonraki her 5 kontrol periyodunda bir kaydet.
                        should_log = False
                        if not is_out_of_range:
                            out_of_range_states.pop(sensor_key, None)
                        else:
                            direction = "YÜKSEK" if value_temp > upper_limit else "DÜŞÜK"
                            state = out_of_range_states.get(sensor_key)

                            # Yön değişirse bunu yeni bir uygunsuzluk olarak ele al.
                            if state is None or state["direction"] != direction:
                                state = {"count": 1, "direction": direction}
                            else:
                                state["count"] += 1

                            out_of_range_states[sensor_key] = state
                            should_log = state["count"] == 1 or (state["count"] - 1) % 5 == 0

                        if should_log:
                            log = SensorLog(
                                machine_id=machine.id,
                                sensor_id=slave_id,
                                value=value_temp,
                                value_set=value_temp_set,
                                value_histerezis=value_temp_histerezis,
                                timestamp=now
                            )
                            db.add(log)
                            print(
                                f"SensorLog kaydedildi: {sensor_key} → "
                                f"temp={value_temp}, set={value_temp_set}, histerezis={value_temp_histerezis} "
                                f"({direction}, uygunsuz periyot={state['count']}, "
                                f"normal aralık: {lower_limit}-{upper_limit})"
                            )

                        # --- AlarmLog (tek satır mantığı) ---
                        high_key = (machine.id, slave_id, "HIGH_TEMP")
                        low_key  = (machine.id, slave_id, "LOW_TEMP")

                        alarm_lower, alarm_upper = alarm_limits if alarm_limits else (None, None)

                        if alarm_upper is not None and value_temp > alarm_upper:
                            if high_key not in active_alarms:
                                log_alarm = AlarmLog(
                                    machine_id=machine.id,
                                    sensor_id=slave_id,
                                    alarm_type="HIGH_TEMP",
                                    start_time=now,
                                    end_time=None
                                )
                                db.add(log_alarm)
                                active_alarms[high_key] = log_alarm
                                print(f"ALARM BAŞLADI: HIGH_TEMP {high_key}")
                        else:
                            if high_key in active_alarms:
                                active_alarms[high_key].end_time = now
                                db.add(active_alarms[high_key])
                                print(f"ALARM BİTTİ: HIGH_TEMP {high_key}")
                                del active_alarms[high_key]

                        if alarm_lower is not None and value_temp < alarm_lower:
                            if low_key not in active_alarms:
                                log_alarm = AlarmLog(
                                    machine_id=machine.id,
                                    sensor_id=slave_id,
                                    alarm_type="LOW_TEMP",
                                    start_time=now,
                                    end_time=None
                                )
                                db.add(log_alarm)
                                active_alarms[low_key] = log_alarm
                                print(f"ALARM BAŞLADI: LOW_TEMP {low_key}")
                        else:
                            if low_key in active_alarms:
                                active_alarms[low_key].end_time = now
                                db.add(active_alarms[low_key])
                                print(f"ALARM BİTTİ: LOW_TEMP {low_key}")
                                del active_alarms[low_key]
    
                # --- TimerLog (sensör listesinden bağımsız) ---
                timer_id = int(machine.timer_id) if machine.timer_id is not None else None
                data_timer = cache.get(timer_id) if timer_id is not None else None
                if data_timer:
                    holding = data_timer.get("holding_registers", [])
                    discrete = data_timer.get("discrete_inputs", [])

                    if len(holding) > 10 and len(discrete) > 6:
                        value_timer_T1_min = timer_value_to_minutes(holding[0], holding[2])
                        value_timer_T2_min = timer_value_to_minutes(holding[8], holding[10])
                        value_timer_out = discrete[0]
                        value_start = discrete[6]
                        value_reset = discrete[4]
                        value_gate = discrete[5]
                        value_state = "start" if value_start and not value_reset and not value_gate else "stop"
                        timer_key = (machine.id, timer_id)
                        new_timer_values = {
                            "T1": value_timer_T1_min,
                            "T2": value_timer_T2_min,
                            "out": value_timer_out,
                            "state": value_state,
                        }

                        if last_timer_values.get(timer_key) != new_timer_values:
                            log_timer = TimerLog(
                                machine_id=machine.id,
                                sensor_id=timer_id,
                                value_T1=value_timer_T1_min,
                                value_T2=value_timer_T2_min,
                                value_out=value_timer_out,
                                value_state=value_state,
                                timestamp=datetime.datetime.now(),
                            )
                            db.add(log_timer)
                            last_timer_values[timer_key] = new_timer_values
                            print(f"TimerLog kaydedildi: {timer_key} → {new_timer_values}")

            db.commit()

        except Exception as e:
            print(f"periodic_sensor_log hata: {e}")

        await asyncio.sleep(10)

async def periodic_cycle_log():
    """Retry cached observations if immediate durable collection failed."""
    while True:
        for error in drain_cycle_spool():
            print(error)
        timer_ids = set()
        for machine in list(machines):
            try:
                if getattr(machine, "is_active", True) and machine.timer_id is not None:
                    timer_ids.add(int(machine.timer_id))
            except Exception as exc:
                print(f"Cycle makine bilgisi okunamadı: {exc}")
        for timer_id in timer_ids:
            try:
                record_cycle_sample(timer_id, cache.get(timer_id) or {})
            except Exception as exc:
                print(f"Cycle timer kaydı başarısız: timer={timer_id}: {exc}")
        await asyncio.sleep(0.5)


def run_cycle_log():
    asyncio.run(periodic_cycle_log())


async def process_cycle_events():
    """Aggregate each batch atomically, using a dedicated database session."""
    from cycle_service import process_events
    while True:
        try:
            with SessionLocal() as session:
                process_events(session)
        except Exception as exc:
            print(f"process_cycle_events hata: {exc}")
        await asyncio.sleep(0.5)
