"""Use OZDEKAN_DATA_DIR=<temporary directory> when running these API tests."""
import unittest
from sqlalchemy import create_engine, inspect, text
import test_quality_reasons as fixture
from models import Machine
from sensor_layout import migrate_sensor_layout, reconcile_layout


class SensorLayoutTests(unittest.TestCase):
    setUp = fixture.QualityReasonTests.setUp
    tearDown = fixture.QualityReasonTests.tearDown
    request = fixture.QualityReasonTests.request

    def machine(self):
        m = self.db.get(Machine, 1)
        m.sensor_ids = [11, 12, 13]
        m.sensor_count = 3
        self.db.commit()
        return m

    def test_layout_persists_across_sessions_and_other_settings(self):
        self.machine()
        layout = {'top': ['13'], 'bottom': ['12', '11']}
        status, result = self.request('PUT', '/machines/1/sensor-layout', layout)
        self.assertEqual(status, 200, result)
        # Fresh sessions model closing/reopening the application, without a browser cache.
        from sqlalchemy.orm import Session
        with Session(self.engine) as reopened:
            self.assertEqual(reopened.get(Machine, 1).sensor_layout, layout)
        self.assertEqual(self.request('PUT', '/machines/1', {'name': 'Renamed'})[0], 200)
        data = self.request('GET', '/machines')[1][0]
        self.assertEqual(data['sensor_layout'], layout)
        self.assertEqual(data['sensor_ids'], [11, 12, 13])

    def test_old_machine_defaults_and_sensor_changes(self):
        m = self.machine()
        self.assertIsNone(self.request('GET', '/machines')[1][0]['sensor_layout'])
        m.sensor_layout = {'top': ['13', '11'], 'bottom': ['12']}
        m.sensor_ids = [12, 13, 14]
        self.db.commit()
        data = self.request('GET', '/machines')[1][0]
        self.assertEqual(data['sensor_layout'], {'top': ['13'], 'bottom': ['12', '14']})
        self.assertEqual(reconcile_layout([1, 2], {'top': ['1', '1', '999'], 'bottom': []}), {'top': ['1'], 'bottom': ['2']})

    def test_invalid_layout_does_not_overwrite_saved_values(self):
        self.machine()
        good = {'top': ['11', '12'], 'bottom': ['13']}
        self.assertEqual(self.request('PUT', '/machines/1/sensor-layout', good)[0], 200)
        bad = [ {'top': ['11', '11'], 'bottom': ['13']}, {'top': ['11'], 'bottom': ['13']},
            {'top': ['11','12'], 'bottom': ['999']}, {'top':'11','bottom':[]},
            {'top':[True,12],'bottom':[13]}, {'upper':[11,12],'bottom':[13]} ]
        for payload in bad:
            self.assertEqual(self.request('PUT', '/machines/1/sensor-layout', payload)[0], 400)
            self.assertEqual(self.db.get(Machine, 1).sensor_layout, good)
        self.assertEqual(self.request('PUT', '/machines/999/sensor-layout', good)[0], 404)

    def test_config_export_contains_layout_and_import_still_optional(self):
        import json
        self.machine()
        layout = {'top': ['12'], 'bottom': ['13', '11']}
        self.request('PUT', '/machines/1/sensor-layout', layout)
        status, data = self.request('GET', '/system/config-export')
        self.assertEqual(status, 200)
        if isinstance(data, bytes): data = json.loads(data)
        self.assertEqual(data['machines'][0]['sensor_layout'], layout)


class LegacyLayoutMigrationTests(unittest.TestCase):
    def test_migration_is_additive_and_repeatable(self):
        engine = create_engine('sqlite://')
        try:
            with engine.begin() as conn:
                conn.execute(text('CREATE TABLE machines (id INTEGER PRIMARY KEY, name TEXT, sensor_ids JSON)'))
                conn.execute(text('INSERT INTO machines VALUES (1, :name, :ids)'), {'name': 'Existing', 'ids': '[11,12,13]'})
                before = conn.execute(text('SELECT * FROM machines')).all()
            migrate_sensor_layout(engine)
            migrate_sensor_layout(engine)
            with engine.connect() as conn:
                self.assertEqual(conn.execute(text('SELECT id, name, sensor_ids FROM machines')).all(), before)
                self.assertIsNone(conn.execute(text('SELECT sensor_layout FROM machines')).scalar())
                self.assertEqual(conn.execute(text('PRAGMA integrity_check')).scalar(), 'ok')
            self.assertIn('sensor_layout', {c['name'] for c in inspect(engine).get_columns('machines')})
        finally:
            engine.dispose()
