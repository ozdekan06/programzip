"""API regression scenarios; run with OZDEKAN_DATA_DIR set to a temporary folder."""
import unittest
import asyncio
from datetime import timedelta
from unittest.mock import AsyncMock, patch
from sqlalchemy.orm import sessionmaker

from cycle_service import observe_timer
from models import CycleEvent, CycleLog, CycleRecovery
import test_cycle_recovery as recovery_fixture


class RecoveryFlowTests(unittest.TestCase):
    setUp = recovery_fixture.CycleRecoveryApiTests.setUp
    tearDown = recovery_fixture.CycleRecoveryApiTests.tearDown
    request = recovery_fixture.CycleRecoveryApiTests.request

    def confirm(self, **extra):
        state = self.db.get(CycleRecovery, 1)
        payload = dict(revision=state.revision, action='continue', phase='renewal',
                       cooking_end_time=(self.at + timedelta(minutes=4)).isoformat(),
                       note='API regression', **extra)
        return self.request('POST', '/cycle-recovery/1', payload)

    def test_healthy_slow_reads_do_not_remove_entry_cycle(self):
        self.assertEqual(self.confirm()[0], 200)
        for seconds in (40, 80, 120):
            observe_timer(self.db, 1, 0, self.at + timedelta(minutes=5, seconds=seconds),
                          communication_gap=False)
        self.assertEqual(self.request('GET', '/cycle-recovery')[1], [])
        self.assertEqual([c['id'] for c in self.request('GET', '/cycle-logs?entry_only=true')[1]],
                         [self.cycle.id])

    def test_separate_interruption_preserves_edges_and_reports_next_recovery(self):
        reference = self.at + timedelta(minutes=5)
        state = self.db.get(CycleRecovery, 1)
        revision = state.revision
        observe_timer(self.db, 1, 1, reference + timedelta(seconds=10), communication_gap=False)
        observe_timer(self.db, 1, 1, reference + timedelta(seconds=50), communication_gap=True)
        observe_timer(self.db, 1, 0, reference + timedelta(seconds=60), communication_gap=False)
        self.assertEqual(state.revision, revision)
        self.assertEqual(state.reference_at, reference)
        code, result = self.confirm()
        self.assertEqual(code, 200, result)
        self.assertTrue(result['pending'])
        self.assertIn('ayrı bir kesinti', result['message'])
        self.assertEqual(self.db.query(CycleLog).count(), 2)
        rows = self.request('GET', '/cycle-recovery')[1]
        self.assertEqual(rows[0]['reason'], 'communication_gap')
        self.assertEqual(rows[0]['reference_phase'], 'cooking')
        code, result = self.request('POST', '/cycle-recovery/1', dict(
            revision=rows[0]['revision'], action='continue', phase='cooking', note='Second interruption'))
        self.assertEqual(code, 200, result)
        self.assertFalse(result['pending'])
        self.assertEqual(self.request('GET', '/cycle-recovery')[1], [])
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(), 0)
        current = self.db.query(CycleLog).order_by(CycleLog.id.desc()).first()
        self.assertAlmostEqual(current.cooking_duration, 50 / 60)

    def test_idempotent_post_does_not_repeat_cycle_mutations(self):
        state = self.db.get(CycleRecovery, 1)
        payload = dict(revision=state.revision, action='continue', phase='renewal',
                       cooking_end_time=(self.at + timedelta(minutes=4)).isoformat(),
                       note='Network retry', request_id='api-retry-1')
        first_code, first = self.request('POST', '/cycle-recovery/1', payload)
        second_code, second = self.request('POST', '/cycle-recovery/1', payload)
        self.assertEqual(first_code, 200, first)
        self.assertEqual(second_code, 200, second)
        self.assertEqual(self.db.query(CycleLog).count(), 1)
        self.assertEqual(self.cycle.cooking_duration, 4)
        changed = {**payload, 'phase': 'cooking'}
        self.assertEqual(self.request('POST', '/cycle-recovery/1', changed)[0], 409)

    def test_conflicting_phase_rejected_without_touching_buffered_start(self):
        observe_timer(self.db, 1, 1, self.at + timedelta(minutes=5, seconds=10),
                      communication_gap=False)
        state = self.db.get(CycleRecovery, 1)
        code, result = self.request('POST', '/cycle-recovery/1', dict(
            revision=state.revision, action='continue', phase='cooking', note='Wrong phase'))
        self.assertEqual(code, 409, result)
        self.assertTrue(state.pending)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(), 1)
        self.assertEqual(self.db.query(CycleLog).count(), 1)

    def test_shutdown_stops_collectors_before_marking_session_clean(self):
        import main

        async def run():
            task = asyncio.create_task(asyncio.Event().wait())
            previous = getattr(main.app.state, 'background_tasks', [])
            main.app.state.background_tasks = [task]
            try:
                with patch.object(main, 'SessionLocal', sessionmaker(bind=self.engine)), \
                     patch.object(main.connection_api, 'close', new_callable=AsyncMock) as close:
                    await main.shutdown_event()
                    close.assert_awaited_once()
                self.assertTrue(task.cancelled())
                self.assertEqual(main.app.state.background_tasks, [])
            finally:
                main.app.state.background_tasks = previous

        asyncio.run(run())
        self.db.expire_all()
        self.assertTrue(self.db.get(CycleRecovery, 1).clean_shutdown)


if __name__ == '__main__':
    unittest.main()
