import asyncio
from types import SimpleNamespace

from connection_api import _read_holding_blocks


def response(values, error=False):
    return SimpleNamespace(registers=values, isError=lambda: error)


def test_holding_blocks_preserve_addresses_and_register_order():
    for count in (30, 52):
        calls = []

        async def read(**kwargs):
            calls.append(kwargs)
            return response(range(kwargs["address"], kwargs["address"] + kwargs["count"]))

        result = asyncio.run(_read_holding_blocks(read, 120, {"address": 5, "count": count}))
        assert result.registers == list(range(5, 5 + count))
        assert all(call["device_id"] == 120 and call["count"] <= 13 for call in calls)
        assert sum(call["count"] for call in calls) == count


def test_holding_block_error_does_not_publish_partial_values():
    calls = []
    error = response([], error=True)

    async def read(**kwargs):
        calls.append(kwargs)
        return error if len(calls) == 2 else response(range(13))

    result = asyncio.run(_read_holding_blocks(read, 120, {"address": 0, "count": 52}))
    assert result is error
    assert result.registers == []
    assert len(calls) == 2


def test_short_holding_block_is_rejected():
    async def read(**kwargs):
        return response([150])

    try:
        asyncio.run(_read_holding_blocks(read, 120, {"address": 0, "count": 30}))
    except ValueError as error:
        assert "Incomplete holding response" in str(error)
    else:
        raise AssertionError("Short response must not be published")
