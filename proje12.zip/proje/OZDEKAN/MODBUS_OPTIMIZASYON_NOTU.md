# Sonraki görüşme için Modbus okuma önerisi

Tarih: 25 Kasım 2026.

Kullanıcı bu öneriyi sonraki sefer değerlendirmek üzere saklamamızı istedi.
**Aşağıdaki seyrek okuma optimizasyonu henüz uygulanmadı. Otomatik uygulamayın;
kullanıcının devam talebinde bu notu esas alın.**

## Önerilen sorgular

| Cihaz | Veri türü | Başlangıç | Adet | Kullanım |
|---|---|---:|---:|---|
| Sensör | Holding | 0 | 13 | Hedef 0, histerezis 5, alarm farkı 12 |
| Sensör | Holding | 35 | 1 | Offset |
| Sensör | Input | 0 | 1 | Ölçülen sıcaklık |
| Timer | Holding | 0 | 11 | Hedefler 0 ve 8, süre birimleri 2 ve 10 |
| Timer | Input | 0 | 2 | Kalan pişirme ve yenileme süreleri |
| Timer | Discrete input | 0 | 7 | OUT 0, reset 4, gate 5, start 6 |

Adresler sıfır tabanlıdır. Sensör holding okuması 36 register/3 blok yerine
14 register/2 istek olur. Timer holding adreslerini tek tek okumayın;
0–10 aralığının tek istekte okunması gereksiz istek ve beklemeyi önler.

## Uygularken korunacaklar

- Offset cevabını holding dizisinde **35. konuma** yerleştirin; 13. konuma
  eklemeyin. Okunmayan konumları gerçek sıfır ölçümü gibi göstermeyin.
- Eksik/başarısız cevapları tam ve güncel veri olarak yayımlamayın;
  kalite, son başarılı okuma ve askıdan kurtarma davranışını koruyun.
- Aynı Modbus adresi hem sensör hem timer rolündeyse iki rolün ihtiyaçlarını
  birlikte karşılayın.
- Önce gerçek bir sorunlu cihazda hedef, histerezis, alarm, offset ve timer
  değerlerini doğrulayın; ardından geneline uygulayın.
- Bu değişiklik için cihazlara ayar yazılması gerekmez.

## Mevcut durumdan farkı

Yerel güncel okuyucu sensörde holding 0–35 ve input 0–6; timerda holding
0–10, input 0–3 ve discrete 0–6 okuyor. Holding istekleri en fazla 13
registerlık bloklara ayrılıyor. Blok aralıkları ve arka plan istek aralıkları
ortam değişkenlerini/config.json ayarlarını kullanıyor.

Uzak Windows bilgisayarda uzun holding cevaplarının eksik geldiği gerçek
testle görüldü: cihaz 120'de 52 register isteğinde 109 yerine 44 bayt;
13 registerlık bloklarda doğru uzunluk ve CRC. Küçük blok düzeltmesi ve
zamanlama ayarları uygulandı; hedef değerlerin makine ekranına geldiği
doğrulandı. Uzak config.json için inter_request_delay ve inter_device_delay
0.3 saniye seçildi. Buradaki platforma özel config.json aynı varsayılmamalı.

Bu nottaki ek optimizasyonu uygulamadan önce dosyaların ve çalışan ortamın
güncel durumunu yeniden kontrol edin.
