# OZDEKAN cihaz simülatörü

Simülatör, gerçek RS485 cihazlarının register yapılarını ayrı bir Modbus TCP
süreci olarak taklit eder. Sıcaklık, set değeri, alarm/histerezis değerleri ile
timer süreleri arayüzden değiştirilebilir; timer başlatılabilir, durdurulabilir
ve sıfırlanabilir.

## Çalıştırma

1. Simülatörü başlatın:

   ```bash
   python3 modbus_simulator.py
   ```

2. Tarayıcıda `http://127.0.0.1:8765` adresini açın.

3. `connection_api.py` içindeki tek mod seçimini değiştirin:

   ```python
   MODBUS_MODE = "simulator"
   ```

4. Ana uygulamayı yeniden başlatın. Makine ayarlarındaki sensör ve timer
   ID'leri, simülatör arayüzündeki slave ID'leriyle aynı olmalıdır.

Diğer bağlantılara geçmek için aynı satırda `"serial"` (RTU/RS485) veya
`"tcp"` (gerçek TCP/IP cihazı) seçip uygulamayı yeniden başlatın.
`config.json` içindeki eski `modbus_mode` veya `MODBUS_MODE` ortam değişkeni
bu kod seçimini değiştirmez.

Bağlantı ayarları `config.json` veya karşılık gelen ortam değişkenleriyle ayarlanır:

| Mod | Ayarlar | Varsayılan |
| --- | --- | --- |
| TCP | `modbus_tcp_host`, `modbus_tcp_port` | `192.168.0.240:502` |
| Simülatör | `modbus_local_simulator_host`, `modbus_local_simulator_port` | `127.0.0.1:1502` |
| RTU | `modbus_port`, `modbus_baudrate`, `modbus_parity`, `modbus_stopbits` | `COM3`, `9600`, `N`, `1` |

Web sunucusunun `host/port` alanları Modbus adresinden ayrıdır.
Simülasyon aynı uygulama veritabanını kullanır; denemeleri ayrı bir veri kopyasıyla yapın.

Simülatör başlangıçta `logs.db` içindeki aktif makineleri okuyarak gereken
sensör ve timer slave'lerini otomatik oluşturur. Veritabanında makine yoksa
slave 1 sıcaklık kontrolcüsü ve slave 2 timer olarak açılır. Arayüzden 1–247
arasında yeni slave cihazları da eklenebilir veya silinebilir.

Farklı portlarla çalıştırmak için:

```bash
python3 modbus_simulator.py --modbus-port 15020 --ui-port 18765
```
