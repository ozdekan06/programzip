# Cycle yeniden açılış doğrulaması

Program açıldığında geçerli açık cycle varsa, otomatik yeni START üretmek yerine
kullanıcı doğrulaması beklenir. İlk güncel timer okuması sabit bir referans anı
oluşturur. Açık cycle olmadan ilk okuma pişirme gösteriyorsa gerçek başlangıç
bilinmediği için yine kullanıcıdan başlangıç zamanı istenir.

Ana uygulama sayfalarında “Cycle doğrulaması” penceresi varsayılan olarak otomatik
açılmaz. Sağ alttaki düğmeden elle açılır. Pencerenin içindeki “Cycle doğrulaması
gerektiğinde otomatik uyar” anahtarı açılırsa önceki otomatik açılış davranışı
etkinleşir. Tercih bu tarayıcıda saklanır; varsayılan kapalıdır. “Kapat / Sonra
incele” ile o sayfa oturumu için ertelenebilir. Erteleme sinyal kaydını durdurmaz.
Onaylanmamış cycle yeni ürüne bağlanamaz ve eski kapatma düğmelerinden kapatılamaz.

- **Aynı cycle devam ediyor:** Eski başlangıç korunur. Referans anında yenilemedeyse
  pişirme bitiş zamanı girilir. Pişirmedeyse eski başlangıçtan devam edilir.
- **Bu cycle bitti:** Gerçek pişirme bitişi ve cycle bitişiyle kapatılır. Referans
  anında timer pişirme gösteriyorsa aynı cycle veya yeni cycle seçilmelidir.
- **Yeni cycle oluştur:** Eski cycle gerekçesiyle geçersiz olarak korunur. Yeni
  başlangıç tarih/saatini kullanıcı girer; yenilemedeyse pişirme bitişini de girer.

Karar referans anını anlatır. Bu andan sonraki START/STOP olayları kalıcı kuyrukta
bekler; onayda zaman sırasıyla işlenir. Bekleyen doğrulamanın referansı ve sürümü
sonraki okumalar veya yeniden açılış nedeniyle değiştirilmez. Daha sonraki gerçek
kesintiler `GAP` olaylarıyla ayrıca saklanır. Onay, bilinen geçişleri bir sonraki
kesintiye kadar işler. Sonraki kesinti de belirsizse kendi referansıyla ayrı bir
doğrulama açılır; ekranda bunun önceki onayın tekrarı olmadığı belirtilir.

Cycle güncellemeleri ve olayın işlendi işareti aynı transaction içindedir.
Tekrarlanan START pişirmesi devam eden cycle'ı değiştirmez. Tekrarlanan STOP da
önceden ölçülen pişirme süresini değiştirmez. Geçersiz ve inceleme bekleyen eski
cycle'lar canlı olayların hedefi olmaz.

Canlı okuyucu, normal ve başarılı bir Modbus turunun yavaş olmasını iletişim
kesintisinden ayırır. Gerçek discrete okuma hatası, uygulamanın yeniden açılması
veya timer takibinin kesilmesi yeni belirsizlik sınırıdır. Bu nedenle başarılı
ama 30 saniyeden uzun bir tur tek başına yeniden doğrulama açmaz. `observe_timer`
doğrudan çağrılıp iletişim durumu verilmediğinde eski 30 saniye denetimi korunur.
Yeni okuma yokken eski cache değerleri olay üretmez.
Program kapalıyken cihazda gerçekleşen geçişler cihazın olay geçmişi olmadan
kesin olarak hesaplanamaz. Kullanıcının verdiği zamanlar `operator`, olaylardan
çıkarılan geçmiş düzeltmeler `inferred_repair`, normal ölçümler `observed` olarak
saklanır; rapor ekranı ve dışa aktarma bu ayrımı gösterir.

## 25 Kasım 2026 güvenilirlik düzeltmesi

- Gerçek START/STOP olayları sonradan taşınan bir referans nedeniyle sessizce
  işlenmiş sayılmaz. Önceki sürümden kalan böyle bir kuyruk varsa, güvenle
  ilişkilendirilebilen geçişler cycle'lara aktarılır ve güncel kartın doğrulanması
  istenir. Belirsiz kayıtlar ham olayları ve denetim kaydı korunarak Geçmiş
  incelemeye ayrılır; sonraki üretime otomatik bağlanmaz.
- Referansın timer aşamasıyla çelişen onay işlem yapılmadan reddedilir. Pişirme
  referansında “Bu cycle bitti” seçeneği sunulmaz.
- Timer ayarları okunamasa bile başlama/bitiş sinyalleri toplanır; bilinmeyen
  ideal süreler sıfır olarak doldurulmaz. Doğrulama, referans anında yakalanan
  ayarları kullanır; onay anındaki farklı set değerleri geçmişe uygulanmaz.
- Açık kartların taslakları normal liste yenilemesinde korunur. Başka bir
  işlemle değişen kart gönderilemez; yalnız o kart açık bir uyarıyla yenilenir.
  Otomatik uyarı ayarı, açık formun güncelliğini denetlemeyi kapatmaz.
- Eski HTTP cevapları yeni listeyi geri alamaz. Onay başarılıysa sonraki liste
  isteğinin hatası onayı başarısız gibi göstermez. Aynı içerikle ağ hatası sonrası
  tekrar gönderilen `request_id` aynı işlemi ikinci kez uygulamaz.
- İletişim nedeni, bekleyen ayrı kesintiler ve discrete okuma zamanları API'de
  görülebilir. Paylaşılan sensör/timer adreslerinin rolleri makine sırasından
  bağımsız birleştirilir.

Timer örnekleri uygulamanın veri dizinindeki `cycle-spool` klasörüne önce kalıcı
olarak yazılır, sonra veritabanına aktarılır. Geçici veritabanı hatasında kuyruk
korunur ve sıra bozulmadan yeniden denenir. Açılışta bu kuyruk, yeni oturumun
referansı oluşturulmadan önce işlenir. Bu klasör uygulama verisinin parçasıdır;
bekleyen dosyaları silmeyin ve veri dizini taşınırken klasörü de taşıyın.

Bu koruma, cihazdan alınmış örnekler içindir. Cihazla bağlantı yokken gerçekleşen
fiziksel geçişler cihazın olay geçmişi olmadan yeniden üretilemez; gerçek
kesintilerde operatör doğrulaması bu yüzden korunur.

## Geçmiş veri düzeltmesi

Değişiklik öncesi SQLite yedeği:
`logs.db.before-cycle-recovery-20261008-210230-045672.bak`

- Cycle **30** eski başlangıcıyla korundu; cycle **31**'in STOP ve kapanış bilgileri
  kullanılarak tamamlandı. 31 silinmeden tekrar kayıt olarak geçersiz işaretlendi.
  Bu çıkarım 30 üzerinde inceleme onayı bekliyor.
- **7, 8, 9** ürün bağlantıları bulunduğu için otomatik birleştirilmedi.
- **22, 23, 24, 25, 26** uzun kesinti içerdiği için otomatik birleştirilmedi.
- Bu dokuz geçerli kayıt “Geçmiş inceleme” ekranında gerçek zamanlarla düzeltilebilir.
  Aynı fiziksel üretime ait oldukları biliniyorsa ilgili kimlikler birlikte
  birleştirilebilir. Ürün/görev bağlantıları seçilen cycle'a taşınır; kaynak kayıtlar
  geçersiz olarak saklanır. Ürüne bağlı bir kayıt tek başına geçersizleştirilecekse
  önce mevcut ürün geri alma akışı kullanılmalıdır.

`cycle_repair_report.json` düzeltme özetini içerir. `cycle_audits` tablosu bütün
önceki değerleri ve kullanıcı kararlarını saklar; `/cycle-audit` bunları listeler.
Mevcut 29 ürün, 29 görev ve 75 olay kaydı yedekle karşılaştırıldı; değişmedi.
41 cycle kaydının tamamı korundu. SQLite bütünlük kontrolü başarılı.

## Doğrulama

Yeni çekirdek ve API testleri `test_cycle_recovery.py` içindedir. Geçici veri dizini
ile çalıştırın; mevcut `test_cycle_events.py` gerçek veritabanına test olayları
eklediği için bu kontrolün parçası değildir.

```sh
OZDEKAN_DATA_DIR=/tmp/ozdekan-cycle-tests python3 -m unittest test_cycle_recovery test_quality_reasons -v
```

Tarayıcı testi gerçek veritabanından ayrı, geçici test verileriyle yapıldı.
Canlı seri cihaz üzerinde kesinti testi yapılmadı.

Güncel regresyon kapsamı: `test_cycle_recovery.py`, `test_cycle_recovery_flow.py`
ve `test_cycle_collection.py`; tekrar eden kesintiler, yeniden başlatma,
doğrulama/ürün girişi API akışı, idempotent onay, eski kayıt kurtarma ve kalıcı
örnek kuyruğunun veritabanı/disk hatalarındaki davranışını kapsar.
`test_cycle_recovery_ui.mjs` bağımlılıksız Node testleriyle geciken HTTP cevapları,
taslakların korunması, eskimiş kartlar ve gizli form alanlarını denetler.

## Ürün geri alma ve cycle bağlantısı

Cycle geçersizleştirme kontrolü, geçmişteki `SUCCESS` görevlerinin varlığına değil,
cycle'a bağlı ürünlerin `is_reverted` durumuna bakar. Bütün bağlı aktif ürünler
geri alındıktan sonra eski görevler korunur ve geçersizleştirmeye engel olmaz.
Aynı kontrol normal geçersizleştirme, geçmiş inceleme ve açılışta eski cycle'ı
yeni cycle ile değiştirme işlemlerinde uygulanır.

Aktif ürün varsa uyarı seri numaralarını ve **Bağlı ürünleri göster ve geri al**
bağlantısını sunar. Bağlantı Rapor Sayfası / Ürün Logları ekranını cycle kimliğiyle
filtrelenmiş olarak açar. Ürün kartında **Ürünü cycle’a geri al** düğmesi vardır.
Neden ve onay alındıktan sonra yalnız seçilen ürün geri alınır. İşlem sonrası
kalan aktif ürün sayısı ve **Cycle ekranına dön** bağlantısı gösterilir.

Toplu işlem **Gösterilen ürünleri geri al** olarak adlandırıldı; `/products/revert`
üzerinden nedenle çalışır. Önceki `/product-logs/delete` yolu eski istemciler için
korunur; kayıt silmez. Tekli ve toplu geri alma ürün/görev geçmişini korur ve
manuel tamamlanmış siparişi yeniden açar.

Yalnızca cycle zamanı hatalıysa ürünleri geri almaya gerek yoktur; geçmiş inceleme
üzerinden zamanlar düzeltilir. Aynı fiziksel üretime ait tekrar cycle kayıtları,
ürünleri geri almadan kullanıcı onayıyla birleştirilebilir.

`test_product_recovery.py` aktif bağlantı uyarısı, tekli/toplu geri alma,
geçmiş kayıt korunması, kalan bağlantılar, açılışta değiştirme ve geçersizleştirme
senaryolarını kapsar. 33 çekirdek/API/kalite testi ile 4 mevcut otomasyon testi
başarılıdır; yönlendirme ve tek ürün geri alma akışı geçici verilerle Safari'de
test edildi. Bu değişiklikte mevcut üretim verileri geri alınmadı.
