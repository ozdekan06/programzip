import unittest
from datetime import timedelta
import test_cycle_recovery
from models import Product, TaskLog, Order, CycleLog, CycleRecovery


class ProductRecoveryTests(unittest.TestCase):
    setUp = test_cycle_recovery.CycleRecoveryApiTests.setUp
    tearDown = test_cycle_recovery.CycleRecoveryApiTests.tearDown
    request = test_cycle_recovery.CycleRecoveryApiTests.request

    def link(self, product_id=1):
        self.db.add(TaskLog(machine_id=1,person_id=1,product_id=product_id,cycle_id=self.cycle.id,task_name='Production',status='SUCCESS'))
        self.db.commit()

    def unlock(self):
        self.db.get(CycleRecovery,1).pending=False
        self.db.commit()

    def test_active_products_block_with_explicit_navigation(self):
        self.unlock(); self.link(); self.link()
        code,body=self.request('POST',f'/cycle-logs/{self.cycle.id}/invalidate',{'reason':'bad trigger'})
        self.assertEqual(code,409)
        detail=body['detail']
        self.assertEqual(detail['code'],'ACTIVE_CYCLE_PRODUCTS')
        self.assertEqual(len(detail['products']),1)
        self.assertIn(f'cycle_id={self.cycle.id}',detail['products_url'])
        self.assertIn('Ürünü cycle’a geri al',detail['message'])

    def test_single_reversal_allows_invalidation_without_deleting_history(self):
        self.unlock(); self.link()
        code,body=self.request('POST','/products/1/revert-to-cycle',{'reason':'wrong product'})
        self.assertEqual(code,200,body)
        self.assertEqual(body['remaining_active_products'],0)
        self.assertEqual(self.db.query(Product).count(),1)
        self.assertEqual(self.db.query(TaskLog).count(),2)
        self.assertEqual(self.db.query(TaskLog).filter_by(status='SUCCESS').count(),1)
        code,body=self.request('POST',f'/cycle-logs/{self.cycle.id}/invalidate',{'reason':'bad trigger'})
        self.assertEqual(code,200,body)
        self.assertFalse(self.cycle.is_valid)

    def test_historical_invalidation_ignores_reversed_product_history(self):
        self.unlock(); self.link()
        self.cycle.review_required=True;self.db.commit()
        url=f'/cycle-history-review/{self.cycle.id}'
        self.assertEqual(self.request('POST',url,{'action':'invalidate','note':'bad'})[0],409)
        self.assertEqual(self.request('POST','/products/1/revert-to-cycle',{'reason':'wrong'})[0],200)
        code,body=self.request('POST',url,{'action':'invalidate','note':'bad'})
        self.assertEqual(code,200,body)
        self.assertFalse(self.cycle.is_valid)

    def test_all_active_products_must_be_reversed(self):
        self.unlock();self.link()
        self.db.add(Product(id=2,name='P2',serialnumber='2',productsize='x',producttype='x',moldnumber='1'))
        self.db.commit();self.link(2)
        code,body=self.request('POST','/products/1/revert-to-cycle',{'reason':'wrong'})
        self.assertEqual(code,200);self.assertEqual(body['remaining_active_products'],1)
        code,body=self.request('POST',f'/cycle-logs/{self.cycle.id}/invalidate',{'reason':'bad'})
        self.assertEqual(code,409);self.assertEqual(body['detail']['products'][0]['id'],2)
        self.request('POST','/products/2/revert-to-cycle',{'reason':'wrong'})
        self.assertEqual(self.request('POST',f'/cycle-logs/{self.cycle.id}/invalidate',{'reason':'bad'})[0],200)

    def test_batch_reversal_reopens_order_and_is_repeatable(self):
        self.unlock();self.link()
        order=Order(name='O',productsize='x',producttype='x',moldnumber='1',ordernumber='1',quantity=1,is_manually_completed=True)
        self.db.add(order);self.db.get(Product,1).ordernumber='1';self.db.commit()
        code,body=self.request('POST','/products/revert',{'product_ids':[1,1],'reason':'wrong'})
        self.assertEqual(code,200,body);self.assertEqual(body['reverted'],1)
        self.assertEqual(body['cycles'][0]['remaining_active_products'],0)
        self.assertFalse(order.is_manually_completed)
        count=self.db.query(TaskLog).count()
        code,body=self.request('POST','/products/revert',{'product_ids':[1],'reason':'wrong'})
        self.assertEqual(body['reverted'],0);self.assertEqual(self.db.query(TaskLog).count(),count)

    def test_batch_bad_input_does_not_change_products(self):
        self.unlock();self.link()
        for payload,expected in [({'product_ids':[1],'reason':' '},400),({'product_ids':[1,999],'reason':'x'},404),({'product_ids':['1'],'reason':'x'},400)]:
            self.assertEqual(self.request('POST','/products/revert',payload)[0],expected)
            self.assertFalse(self.db.get(Product,1).is_reverted)
        self.assertEqual(self.db.query(TaskLog).count(),1)

    def test_restart_replacement_directs_user_to_reverse_active_products(self):
        self.link()
        state=self.db.get(CycleRecovery,1)
        payload=dict(revision=state.revision,action='new',phase='renewal',cycle_start_time=self.at.isoformat(),
                     cooking_end_time=(self.at+timedelta(minutes=4)).isoformat(),note='false cycle')
        code,body=self.request('POST','/cycle-recovery/1',payload)
        self.assertEqual(code,409,body);self.assertEqual(body['detail']['code'],'ACTIVE_CYCLE_PRODUCTS')
        self.assertTrue(self.cycle.is_valid);self.assertTrue(state.pending)
        self.request('POST','/products/1/revert-to-cycle',{'reason':'wrong'})
        code,body=self.request('POST','/cycle-recovery/1',payload)
        self.assertEqual(code,200,body)
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_reversed_products_are_hidden_but_history_available(self):
        self.unlock();self.link()
        self.request('POST','/products/1/revert-to-cycle',{'reason':'wrong'})
        self.assertEqual(self.request('GET',f'/product-logs?cycle_id={self.cycle.id}')[1],[])
        code,rows=self.request('GET',f'/product-logs?cycle_id={self.cycle.id}&include_reverted=true')
        self.assertEqual(code,200);self.assertEqual(len(rows),1)
        self.assertTrue(rows[0]['is_reverted'])
        self.assertEqual(len(rows[0]['tasks']),2)


if __name__=='__main__':unittest.main()
