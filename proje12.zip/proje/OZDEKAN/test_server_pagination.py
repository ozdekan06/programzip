"""Run with OZDEKAN_DATA_DIR pointing to a disposable directory."""
import unittest
from datetime import datetime, timedelta
import test_quality_reasons as fixture
from models import Product, TaskLog, CycleLog, CycleRecovery, SensorLog


class ServerPaginationTests(unittest.TestCase):
    setUp = fixture.QualityReasonTests.setUp
    tearDown = fixture.QualityReasonTests.tearDown
    request = fixture.QualityReasonTests.request

    def seed_products(self, count=45):
        at = datetime(2026, 1, 1)
        for i in range(count):
            product = Product(name='Sample', serialnumber=f'TEST/{i:03}', productsize='1',
                producttype='T', moldnumber='M', ordernumber='TEST', timestamp=at)
            self.db.add(product); self.db.flush()
            self.db.add(TaskLog(product_id=product.id, machine_id=1, person_id=1,
                cycle_id=1, timestamp=at, task_name='Test', status='FAILED' if i % 2 else 'SUCCESS'))
        self.db.commit()

    def test_pages_preserve_order_and_full_summary(self):
        self.seed_products()
        first = self.request('GET', '/product-logs?page=1')[1]
        second = self.request('GET', '/product-logs?page=2')[1]
        last = self.request('GET', '/product-logs?page=3')[1]
        self.assertEqual([len(p['items']) for p in [first, second, last]], [20, 20, 5])
        self.assertEqual(first['summary']['statuses'], {'SUCCESS': 23, 'FAILED': 22, 'CONDITIONAL': 0})
        ids = [r['product_id'] for p in [first, second, last] for r in p['items']]
        self.assertEqual(ids, sorted(ids, reverse=True))
        self.assertEqual(len(set(ids)), 45)
        self.assertEqual(self.request('GET', '/product-logs?ids_only=true')[1], ids)
        self.assertEqual(self.request('GET', '/product-logs?page=999')[1]['page'], 3)

    def test_filter_latest_state_and_export_all_filtered_ids(self):
        self.seed_products()
        product = self.db.query(Product).first()
        self.db.add(TaskLog(product_id=product.id, machine_id=1, person_id=1, cycle_id=1,
            timestamp=datetime(2026, 2, 1), task_name='Changed', status='FAILED'))
        self.db.commit()
        page = self.request('GET', '/product-logs?page=1&status=FAILED')[1]
        self.assertEqual(page['total'], 23)
        ids = self.request('GET', '/product-logs?status=FAILED&ids_only=true')[1]
        self.assertEqual(len(ids), 23)
        status, content = self.request('POST', '/product-logs/export', {'filtered': True, 'product_ids': ids})
        self.assertEqual(status, 200)
        self.assertTrue(content.startswith(b'PK'))

    def test_entry_excludes_active_products_review_and_recovery(self):
        at = datetime(2026, 1, 1)
        for i in range(2, 26):
            self.db.add(CycleLog(id=i, machine_id=1, timestamp=at, cycle_start_time=at,
                cycle_end_time=at + timedelta(minutes=1), review_required=i == 2))
        self.db.commit()
        self.seed_products(1)  # cycle 1 is already used.
        result = self.request('GET', '/cycle-logs?page=1&entry_only=true')[1]
        self.assertEqual(result['total'], 23)
        self.assertEqual(len(result['items']), 20)
        self.assertTrue(all(r['id'] not in {1, 2} for r in result['items']))
        self.db.add(CycleRecovery(machine_id=1, cycle_id=3, pending=True, opened_at=at))
        self.db.commit()
        result = self.request('GET', '/cycle-logs?page=1&entry_only=true')[1]
        self.assertEqual(result['total'], 22)
        self.assertNotIn(3, [r['id'] for r in result['items']])

    def test_sensor_aggregates_cover_all_pages(self):
        for i in range(45):
            self.db.add(SensorLog(machine_id=1, sensor_id=2, timestamp=datetime(2026, 1, 1),
                value=i, value_set=20, value_histerezis=1))
        self.db.commit()
        result = self.request('GET', '/sensor-logs?page=1')[1]
        self.assertEqual(len(result['items']), 20)
        self.assertEqual(result['summary']['total'], 45)
        self.assertEqual(result['summary']['avg_value'], 22)
        self.assertEqual(result['summary']['min_value'], 0)
        self.assertEqual(result['summary']['max_value'], 44)
        self.assertEqual(len(self.request('GET', '/sensor-logs?ids_only=true')[1]), 45)

    def test_validation_and_empty_results(self):
        for endpoint in ('product-logs', 'cycle-logs', 'sensor-logs'):
            for params in ('page=0', 'page=1&page_size=35', 'page=1&page_size=110'):
                self.assertEqual(self.request('GET', f'/{endpoint}?{params}')[0], 422)
        empty = self.request('GET', '/product-logs?page=1&product_name=missing')[1]
        self.assertEqual(empty['items'], [])
        self.assertEqual(empty['total'], 0)
