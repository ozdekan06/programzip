"""Timer collection integration regressions; all writes use an in-memory DB."""
import asyncio
import itertools
import unittest
import tempfile
from datetime import datetime, timedelta
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import Mock, patch

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backgraound as bg
from models import Base, CycleEvent, CycleLog, CycleRecovery, Machine


class CycleCollectionTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine, autoflush=False)
        self.spool = tempfile.TemporaryDirectory(prefix="ozdekan-cycle-spool-")
        self.patches = [
            patch.object(bg, "SessionLocal", self.Session),
            patch.object(bg, "machines", []),
            patch.object(bg, "device_profiles", {}),
            patch.object(bg, "cache", {}),
            patch.object(bg, "suspended_device_ids", set()),
            patch.object(bg, "cycle_sample_progress", {}),
            patch.object(bg, "cycle_sample_enqueued", {}),
            patch.object(bg, "cycle_collection_interrupted", set()),
            patch.object(bg, "cycle_spool_dir", Path(self.spool.name)),
            patch.object(bg, "cycle_unwritten_samples", {}),
            patch.object(bg, "cycle_spool_errors", {}),
            patch.object(bg, "sensor_retry_states", {}),
            patch.object(bg, "sensor_retry_configs", {}),
            patch.object(bg, "sensor_missing_since", {}),
            patch.object(bg, "INTER_REQUEST_DELAY", 0),
        ]
        for item in self.patches:
            item.start()
        self.at = datetime.now().astimezone()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.engine.dispose()
        self.spool.cleanup()

    def machine(self, id=1, timer=7, sensors=None):
        with self.Session() as db:
            db.add(Machine(id=id, name=f"M{id}", slave_id=timer, timer_id=timer,
                           sensor_ids=sensors or [], sensor_count=len(sensors or [])))
            db.commit()
        bg.machines.append(SimpleNamespace(id=id, timer_id=timer, is_active=True))
        return bg.machines[-1]

    def sample(self, seconds=0, value=0, generation=0, holding=None):
        return {"discrete_inputs": [False] * 6 + [bool(value)],
                "discrete_read_at": (self.at + timedelta(seconds=seconds)).isoformat(),
                "holding_registers": [] if holding is None else holding,
                "discrete_gap_sequence": generation,
                "discrete_sample_gap_sequence": generation}

    def test_shared_roles_are_independent_of_machine_order(self):
        definitions = [(7, []), (8, [7]), (9, [7, 10])]
        for ordering in itertools.permutations(definitions):
            with self.Session() as db:
                db.query(Machine).delete()
                for id, (timer, sensors) in enumerate(ordering, 1):
                    db.add(Machine(id=id, name=str(id), slave_id=timer, timer_id=timer,
                                   sensor_ids=sensors, sensor_count=len(sensors)))
                db.commit()
            bg.load_machines()
            self.assertEqual(bg.device_profiles[7], "combined")

    def test_healthy_slow_scan_is_not_a_communication_gap(self):
        from cycle_service import process_events
        self.machine()
        bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
        bg.record_cycle_sample(7, self.sample(seconds=45, value=1), fresh=True)
        with self.Session() as db:
            process_events(db)
            self.assertFalse(db.get(CycleRecovery, 1).pending)
            self.assertEqual(db.query(CycleLog).count(), 1)

    def test_missing_holding_does_not_drop_cycle_and_keeps_unknown_ideals(self):
        from cycle_service import process_events
        self.machine()
        bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
        bg.record_cycle_sample(7, self.sample(seconds=5, value=1), fresh=True)
        with self.Session() as db:
            process_events(db)
            cycle = db.query(CycleLog).one()
            self.assertIsNone(cycle.ideal_cooking_time)
            self.assertIsNone(cycle.ideal_renewal_time)

    def test_each_shared_timer_consumer_acknowledges_gap_separately(self):
        self.machine(1)
        # Defensive coverage for legacy/imported shared-timer configurations.
        bg.machines.append(SimpleNamespace(id=2, timer_id=7, is_active=True))
        first = self.sample(value=0)
        with patch("cycle_service.observe_timer") as observe:
            bg.record_cycle_sample(7, first, fresh=True)
        data = self.sample(seconds=5, value=1, generation=1)
        calls = []
        def fail_second(db, machine_id, *args, **kwargs):
            calls.append((machine_id, kwargs["communication_gap"]))
            if machine_id == 2:
                raise RuntimeError("temporary database failure")
        with patch("cycle_service.observe_timer", side_effect=fail_second):
            bg.record_cycle_sample(7, data, fresh=True)
        self.assertEqual(calls, [(1, True), (2, True)])
        self.assertTrue(data["discrete_gap_pending"])
        with patch("cycle_service.observe_timer") as observe:
            bg.record_cycle_sample(7, data, fresh=True)
            self.assertEqual(observe.call_count, 1)
            self.assertEqual(observe.call_args.args[1], 2)
            self.assertTrue(observe.call_args.kwargs["communication_gap"])
        self.assertFalse(data["discrete_gap_pending"])
        self.assertIsNone(data["cycle_collection_error"])

    def test_failed_discrete_read_marks_next_fresh_sample_not_old_cache(self):
        self.machine()
        bg.device_profiles[7] = "timer"
        data = self.sample(value=0)
        bg.cache[7] = data
        with patch("cycle_service.observe_timer"):
            bg.record_cycle_sample(7, data, fresh=True)
        async def failed(method, **kwargs):
            if method == "read_discrete_inputs":
                raise TimeoutError("missing discrete reply")
            return SimpleNamespace(registers=[0] * kwargs["count"], isError=lambda: False), 1
        with patch.object(bg.connection_api, "execute", failed), patch("cycle_service.observe_timer") as observe:
            asyncio.run(bg.read_device_data(7))
            bg.record_cycle_sample(7, data, fresh=True)
            self.assertEqual(observe.call_count, 0)
        self.assertTrue(data["discrete_gap_pending"])
        async def success(method, **kwargs):
            if method == "read_discrete_inputs":
                response = SimpleNamespace(bits=[False] * 6 + [True], isError=lambda: False)
            else:
                response = SimpleNamespace(registers=[0] * kwargs["count"], isError=lambda: False)
            return response, 1
        with patch.object(bg.connection_api, "execute", success), patch("cycle_service.observe_timer") as observe:
            asyncio.run(bg.read_device_data(7))
            self.assertEqual(observe.call_count, 1)
            self.assertTrue(observe.call_args.kwargs["communication_gap"])
        self.assertIsNone(data["discrete_last_error"])
        self.assertIn("missing discrete reply", data["discrete_previous_error"])
        self.assertIn("discrete_poll_interval_seconds", data)
        self.assertFalse(data["discrete_gap_pending"])

    def test_fresh_discrete_is_persisted_before_periodic_task_runs(self):
        self.machine()
        bg.device_profiles[7] = "timer"
        async def success(method, **kwargs):
            if method == "read_holding_registers":
                raise TimeoutError("holding unavailable")
            if method == "read_discrete_inputs":
                response = SimpleNamespace(bits=[False] * 7, isError=lambda: False)
            else:
                response = SimpleNamespace(registers=[0] * kwargs["count"], isError=lambda: False)
            return response, 1
        with patch.object(bg.connection_api, "execute", success), patch("cycle_service.observe_timer") as observe:
            asyncio.run(bg.read_device_data(7))
            self.assertEqual(observe.call_count, 1)
            self.assertEqual(observe.call_args.args[4], {"t1_min": None, "t2_min": None})
            bg.record_cycle_sample(7, bg.cache[7])
            self.assertEqual(observe.call_count, 1)

    def test_short_discrete_response_is_a_real_gap(self):
        self.machine()
        bg.device_profiles[7] = "timer"
        async def short(method, **kwargs):
            if method == "read_discrete_inputs":
                response = SimpleNamespace(bits=[False], isError=lambda: False)
            else:
                response = SimpleNamespace(registers=[0] * kwargs["count"], isError=lambda: False)
            return response, 1
        with patch.object(bg.connection_api, "execute", short), patch("cycle_service.observe_timer") as observe:
            asyncio.run(bg.read_device_data(7))
            self.assertEqual(observe.call_count, 0)
        self.assertTrue(bg.cache[7]["discrete_gap_pending"])
        self.assertNotIn("discrete_read_at", bg.cache[7])

    def test_database_failure_replays_every_acquired_transition_in_order(self):
        from cycle_service import process_events
        self.machine()
        bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
        with patch("cycle_service.observe_timer", side_effect=RuntimeError("DB unavailable")):
            bg.record_cycle_sample(7, self.sample(seconds=5, value=1), fresh=True)
            bg.record_cycle_sample(7, self.sample(seconds=10, value=0), fresh=True)
            bg.record_cycle_sample(7, self.sample(seconds=15, value=1), fresh=True)
        self.assertEqual(len(list(bg.cycle_spool_dir.glob("*.json"))), 3)
        self.assertEqual(bg.drain_cycle_spool(), [])
        with self.Session() as db:
            process_events(db)
            cycles = db.query(CycleLog).order_by(CycleLog.id).all()
            self.assertEqual(len(cycles), 2)
            self.assertAlmostEqual(cycles[0].cooking_duration, 5 / 60)
            self.assertEqual(cycles[0].cycle_end_time,
                             (self.at + timedelta(seconds=15)).replace(tzinfo=None))
        self.assertEqual(list(bg.cycle_spool_dir.glob("*.json")), [])

    def test_restart_replays_spool_and_duplicate_commits_are_idempotent(self):
        from cycle_service import process_events
        self.machine()
        bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
        with patch("cycle_service.observe_timer", side_effect=RuntimeError("DB unavailable")):
            bg.record_cycle_sample(7, self.sample(seconds=5, value=1), fresh=True)
        journal = next(bg.cycle_spool_dir.glob("*.json"))
        original = journal.read_text()
        # A new process has only the disk journal and durable database.
        bg.cycle_sample_progress.clear()
        bg.cycle_sample_enqueued.clear()
        bg.cycle_unwritten_samples.clear()
        bg.machines.clear()
        self.assertEqual(bg.drain_cycle_spool(), [])
        journal.write_text(original)  # Crash after DB commit, before file deletion.
        self.assertEqual(bg.drain_cycle_spool(), [])
        with self.Session() as db:
            process_events(db)
            self.assertEqual(db.query(CycleLog).count(), 1)
            self.assertEqual(db.query(CycleEvent).filter_by(event_type="START").count(), 1)

    def test_journal_failure_preserves_sample_and_backpressures_timer(self):
        self.machine()
        bg.device_profiles[7] = "timer"
        with patch.object(bg, "_persist_cycle_sample", side_effect=OSError("disk unavailable")), \
                patch("cycle_service.observe_timer") as observe:
            data = self.sample(value=0)
            bg.cache[7] = data
            bg.record_cycle_sample(7, data, fresh=True)
            self.assertTrue(bg.cycle_unwritten_samples)
            self.assertIn("disk unavailable", data["cycle_collection_error"])
            self.assertEqual(observe.call_count, 0)
            with patch.object(bg.connection_api, "execute") as execute:
                self.assertIsNone(asyncio.run(bg.read_device_data(7)))
                execute.assert_not_called()
        self.assertEqual(bg.drain_cycle_spool(), [])
        self.assertFalse(bg.cycle_unwritten_samples)

    def test_corrupt_journal_blocks_later_samples_of_that_machine(self):
        self.machine()
        (bg.cycle_spool_dir / "1-broken.json").write_text("{broken")
        with patch("cycle_service.observe_timer") as observe:
            bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
            self.assertEqual(observe.call_count, 0)
        self.assertTrue(bg.cycle_spool_errors)
        self.assertEqual(len(list(bg.cycle_spool_dir.glob("*.json"))), 2)

    def test_windows_journal_does_not_open_directory_for_fsync(self):
        with patch.object(bg.os, "name", "nt"), patch.object(bg.os, "open") as open_directory:
            bg._sync_cycle_spool_directory()
            open_directory.assert_not_called()

    def test_crash_before_journal_rename_recovers_complete_temporary_sample(self):
        from cycle_service import process_events
        self.machine()
        bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
        with patch("cycle_service.observe_timer", side_effect=RuntimeError("DB unavailable")):
            bg.record_cycle_sample(7, self.sample(seconds=5, value=1), fresh=True)
        journal = next(bg.cycle_spool_dir.glob("*.json"))
        temporary = bg.cycle_spool_dir / ".sample-crash-before-rename.tmp"
        journal.replace(temporary)
        bg.cycle_sample_progress.clear()
        bg.cycle_sample_enqueued.clear()
        bg.cycle_unwritten_samples.clear()
        bg.machines.clear()
        self.assertEqual(bg.drain_cycle_spool(), [])
        self.assertFalse(temporary.exists())
        with self.Session() as db:
            process_events(db)
            self.assertEqual(db.query(CycleLog).count(), 1)
            self.assertEqual(db.query(CycleEvent).filter_by(event_type="START").count(), 1)

    def test_incomplete_temporary_sample_is_preserved_and_reported(self):
        self.machine()
        temporary = bg.cycle_spool_dir / ".sample-incomplete.tmp"
        temporary.write_text('{"version": 1, "machine_id":')
        with patch("cycle_service.observe_timer") as observe:
            bg.record_cycle_sample(7, self.sample(value=0), fresh=True)
            self.assertEqual(observe.call_count, 0)
        self.assertTrue(temporary.exists())
        self.assertIn(str(temporary), " ".join(bg.cycle_spool_errors.values()))
        self.assertIn("Dosya korundu", " ".join(bg.cycle_spool_errors.values()))

    def test_cancelled_timer_poll_marks_next_observation_as_gap(self):
        self.machine()
        bg.device_profiles[7] = "timer"
        async def cancelled(*args, **kwargs):
            raise asyncio.CancelledError()
        with patch.object(bg.connection_api, "execute", cancelled):
            with self.assertRaises(asyncio.CancelledError):
                asyncio.run(bg.read_device_data(7))
        self.assertTrue(bg.cache[7]["discrete_gap_pending"])
        self.assertIn("kesildi", bg.cache[7]["discrete_last_error"])

    def test_regular_machine_reload_does_not_mark_collection_interrupted(self):
        self.machine()
        bg.load_machines()
        bg.cycle_collection_interrupted.clear()
        bg.load_machines()
        self.assertEqual(bg.cycle_collection_interrupted, set())
        with self.Session() as db:
            db.get(Machine, 1).is_active = False
            db.commit()
        bg.load_machines()
        with self.Session() as db:
            db.get(Machine, 1).is_active = True
            db.commit()
        bg.load_machines()
        self.assertIn((1, 7), bg.cycle_collection_interrupted)


if __name__ == "__main__":
    unittest.main()
