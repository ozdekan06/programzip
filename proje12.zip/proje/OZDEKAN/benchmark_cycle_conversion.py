"""Isolated ASGI benchmark; never opens the production database or hardware.

Run: python3 benchmark_cycle_conversion.py
"""
import os
import tempfile

_temporary = tempfile.TemporaryDirectory(prefix='ozdekan-cycle-benchmark-')
os.environ['OZDEKAN_DATA_DIR'] = _temporary.name

import json
import statistics
from datetime import datetime, timedelta
from pathlib import Path
from time import perf_counter
from sqlalchemy import event
from database import engine, SessionLocal, get_db
from main import app
from models import Machine, Person, Order, CycleLog, TimerLog, Product, TaskLog
from test_quality_reasons import QualityReasonTests


def run():
    db = SessionLocal()
    db.add_all([Machine(id=1, name='Benchmark', sensor_ids=[], sensor_count=0),
                Person(id=1, name='Test', surname='Operator'),
                Order(name='Test', productsize='1', producttype='T', moldnumber='M',
                      ordernumber='BENCH', quantity=10000, serial_start=1)])
    at = datetime(2026, 1, 1)
    for i in range(500):
        start = at + timedelta(minutes=15*i)
        db.add(CycleLog(id=i+1, machine_id=1, cycle_start_time=start,
                       cycle_end_time=start+timedelta(minutes=15), order_number='BENCH',
                       mold_count=1, total_duration=15, ideal_total_time=15))
        # One sample/minute: 7500 timer rows, rather than an empty history.
        for minute in range(15):
            db.add(TimerLog(machine_id=1, sensor_id=1,
                           timestamp=start+timedelta(minutes=minute), value_T1=10, value_T2=5))
    db.commit()
    db.close()

    def override():
        session = SessionLocal()
        try:
            yield session
        finally:
            session.close()
    app.dependency_overrides[get_db] = override
    helper = QualityReasonTests()
    queries = [0]
    def count(*args):
        queries[0] += 1
    event.listen(engine, 'before_cursor_execute', count)

    def request(method, path, payload=None):
        queries[0] = 0
        started = perf_counter()
        status, body = helper.request(method, path, payload)
        elapsed = (perf_counter()-started)*1000
        assert status == 200, (path, status, body)
        return body, elapsed, queries[0]

    snapshots = []
    def snapshot(converted):
        measurements = {}
        cycles = tasks = None
        for path in ['/orders', '/persons', '/quality-reasons', '/cycle-logs', '/task-logs']:
            samples = [request('GET', path) for _ in range(3)]
            body = samples[-1][0]
            measurements[path] = {'median_ms': round(statistics.median(s[1] for s in samples), 2),
                                  'sql_queries': samples[-1][2],
                                  'json_bytes': len(json.dumps(body).encode())}
            if path == '/cycle-logs': cycles = body
            if path == '/task-logs': tasks = body
        saved = {t['cycle_id'] for t in tasks if not t['product_reverted']}
        available = [c for c in cycles if c['id'] not in saved]
        # renderCycleCards invokes this once for every contextual order card.
        started = perf_counter()
        for cycle in available:
            request('GET', '/order-status/BENCH')
        fanout_ms = (perf_counter()-started)*1000
        snapshots.append({'converted': converted, 'remaining_cards': len(available),
                          'endpoints': measurements,
                          'automatic_order_status_requests': len(available),
                          'order_status_serial_total_ms': round(fanout_ms, 2)})
        print(json.dumps(snapshots[-1]), flush=True)

    writes = []
    snapshot(0)
    for index in range(1, 501):
        body, ms, sql = request('POST', '/products', {
            'name':'Test', 'serialnumber':f'BENCH/{index}', 'productsize':'1',
            'producttype':'T', 'moldnumber':'M', 'ordernumber':'BENCH',
            'machine_id':1, 'person_id':1, 'cycle_id':index, 'status':'SUCCESS'})
        writes.append(ms)
        if index in (1, 100, 250, 499, 500): snapshot(index)
    db = SessionLocal()
    assert db.query(Product).count() == 500
    assert db.query(TaskLog).count() == 500
    assert db.query(TaskLog.cycle_id).distinct().count() == 500
    assert db.query(Product.serialnumber).distinct().count() == 500
    db.close()
    result = {'fixture': {'cycles':500, 'products_per_cycle':1, 'timer_rows':7500,
                          'database':'temporary disk SQLite', 'transport':'in-process ASGI',
                          'browser_rendering_measured':False, 'hardware_polling':False},
              'snapshots':snapshots,
              'writes_ms': {'first_50_median':round(statistics.median(writes[:50]),2),
                            'last_50_median':round(statistics.median(writes[-50:]),2),
                            'max':round(max(writes),2), 'total':round(sum(writes),2)},
              'integrity':'500 products, unique serials and distinct linked cycles verified'}
    Path('performance_results/cycle_500.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result['writes_ms']), flush=True)
    app.dependency_overrides.clear()
    engine.dispose()


if __name__ == '__main__':
    run()
