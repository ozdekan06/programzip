"""OZDEKAN için arayüzlü Modbus cihaz simülatörü.

Ana uygulama bu süreci gerçek cihazlar gibi Modbus üzerinden okur. Arayüz:
http://127.0.0.1:8765
"""

import argparse
import asyncio
import json
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from pymodbus.datastore import ModbusDeviceContext, ModbusSequentialDataBlock, ModbusServerContext
from pymodbus.server import StartAsyncTcpServer


def int_to_bcd(value: int) -> int:
    value = max(0, min(9999, int(value)))
    result = 0
    shift = 0
    while value or shift == 0:
        result |= (value % 10) << shift
        value //= 10
        shift += 4
    return result


class Simulator:
    def __init__(self, device_layout=None):
        self.lock = threading.RLock()
        self.devices = {}
        self.context = ModbusServerContext(devices={}, single=False)
        layout = device_layout or {1: "sensor", 2: "timer"}
        for slave_id, role in sorted(layout.items()):
            self.add_device(slave_id, role)
        self.running = True
        threading.Thread(target=self._timer_loop, daemon=True).start()

    def add_device(self, slave_id, role="combined"):
        slave_id = int(slave_id)
        with self.lock:
            if slave_id in self.devices:
                return self.snapshot(slave_id)
            device = ModbusDeviceContext(
                di=ModbusSequentialDataBlock(0, [0] * 100),
                co=ModbusSequentialDataBlock(0, [0] * 100),
                ir=ModbusSequentialDataBlock(0, [0] * 100),
                hr=ModbusSequentialDataBlock(0, [0] * 100),
            )
            # Sıcaklık: set=180, anlık=25, histerezis=5, alarm farkı=20.
            device.setValues(3, 0, [180, 0, 4, 0, 0, 5] + [0] * 6 + [20])
            device.setValues(4, 0, [25] + [0] * 6)
            # Timer: T1/T2=10 dakika, time base=5 (dakika), kalan süreler.
            device.setValues(3, 0, [int_to_bcd(10), 0, 5, 0, 0, 5, 0, 0, int_to_bcd(10), 0, 5])
            device.setValues(4, 0, [int_to_bcd(10), int_to_bcd(10), 0, 0])
            device.setValues(2, 0, [0] * 7)
            self.context[slave_id] = device
            self.devices[slave_id] = {
                "id": slave_id, "role": role, "temperature": 25, "setpoint": 180,
                "hysteresis": 5, "alarm_delta": 20, "timer1": 10, "timer2": 10,
                "remaining1": 10, "remaining2": 10, "running": False,
                "phase": "renewal", "updated_at": time.time(),
            }
            self._sync(slave_id)
            return self.snapshot(slave_id)

    def remove_device(self, slave_id):
        with self.lock:
            slave_id = int(slave_id)
            self.devices.pop(slave_id, None)
            if slave_id in self.context:
                del self.context[slave_id]

    def update(self, slave_id, values):
        slave_id = int(slave_id)
        with self.lock:
            if slave_id not in self.devices:
                self.add_device(slave_id, values.get("role", "combined"))
            state = self.devices[slave_id]
            for key in ("role", "temperature", "setpoint", "hysteresis", "alarm_delta", "timer1", "timer2", "remaining1", "remaining2", "running", "phase"):
                if key in values:
                    state[key] = values[key]
            if values.get("action") == "start":
                state["running"], state["phase"] = True, "cooking"
                if float(state["remaining1"]) <= 0:
                    state["remaining1"] = state["timer1"]
            elif values.get("action") == "stop":
                state["running"], state["phase"] = False, "renewal"
            elif values.get("action") == "reset":
                state["running"], state["phase"] = False, "renewal"
                state["remaining1"], state["remaining2"] = state["timer1"], state["timer2"]
            state["updated_at"] = time.time()
            self._sync(slave_id)
            return self.snapshot(slave_id)

    def _sync(self, slave_id):
        state, device = self.devices[slave_id], self.context[slave_id]
        holding = [0] * 52
        holding[0] = int_to_bcd(state["timer1"]) if state["role"] == "timer" else int(float(state["setpoint"]))
        holding[2], holding[5], holding[8], holding[10], holding[12] = 5, int(float(state["hysteresis"])), int_to_bcd(state["timer2"]), 5, int(float(state["alarm_delta"]))
        if state["role"] in ("combined",):
            # Aynı slave hem sensör hem timer olduğunda register 0 timer olarak kullanılıyor.
            holding[0] = int_to_bcd(state["timer1"])
        inputs = [int(float(state["temperature"])), int_to_bcd(state["remaining2"]), 0, 0, 0, 0, 0]
        if state["role"] == "timer":
            inputs[0] = int_to_bcd(state["remaining1"])
        bits = [bool(state["running"]), False, False, False, state["phase"] == "cooking", state["phase"] == "renewal", bool(state["running"])]
        device.setValues(3, 0, holding)
        device.setValues(4, 0, inputs)
        device.setValues(2, 0, bits)

    def snapshot(self, slave_id=None):
        with self.lock:
            if slave_id is not None:
                return dict(self.devices[int(slave_id)])
            return [dict(self.devices[key]) for key in sorted(self.devices)]

    def _timer_loop(self):
        last = time.monotonic()
        while self.running:
            time.sleep(0.2)
            now = time.monotonic()
            elapsed_minutes = (now - last) / 60
            last = now
            with self.lock:
                for slave_id, state in self.devices.items():
                    if not state["running"]:
                        continue
                    state["remaining1"] = max(0, float(state["remaining1"]) - elapsed_minutes)
                    if state["remaining1"] <= 0:
                        state["running"], state["phase"] = False, "renewal"
                    self._sync(slave_id)


HTML = r'''<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OZDEKAN Cihaz Simülatörü</title><style>
:root{font-family:Inter,system-ui,sans-serif;color:#e8edf5;background:#0b1018}body{margin:0;background:radial-gradient(circle at 15% 0,#17243a 0,#0b1018 38%);min-height:100vh}.wrap{max-width:1180px;margin:auto;padding:28px}.top{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:24px}h1{font-size:25px;margin:0 0 6px}.muted{color:#8fa0b7;font-size:14px}.badge{background:#143b2b;color:#65e6a0;padding:9px 13px;border-radius:99px}.toolbar,.card{background:#121a27;border:1px solid #243044;border-radius:16px}.toolbar{padding:14px;display:flex;gap:10px;margin-bottom:18px}.toolbar input{max-width:110px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:16px}.card{padding:20px;box-shadow:0 16px 40px #0003}.title{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.title h2{font-size:18px;margin:0}.status{font-size:12px;padding:5px 9px;border-radius:8px;background:#263247}.status.on{background:#123f31;color:#62e6a0}.fields{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field label{display:block;color:#91a1b7;font-size:12px;margin-bottom:6px}.field input,.field select,.toolbar input,.toolbar select{box-sizing:border-box;width:100%;background:#0b121d;color:#eef3fa;border:1px solid #2c3b51;border-radius:9px;padding:10px}button{border:0;border-radius:9px;padding:10px 14px;color:white;background:#3478f6;cursor:pointer;font-weight:650}button.stop{background:#cf4253}button.reset{background:#34435a}button.delete{background:transparent;color:#ef7180;border:1px solid #67313b}.actions{display:flex;gap:9px;margin-top:17px}.foot{margin-top:20px;color:#7f91aa;font-size:12px}@media(max-width:520px){.wrap{padding:16px}.grid{grid-template-columns:1fr}.fields{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}}
</style></head><body><div class="wrap"><div class="top"><div><h1>OZDEKAN Cihaz Simülatörü</h1><div class="muted">Sanal sıcaklık kontrolcüleri ve timer cihazları</div></div><div class="badge">● Modbus aktif · :1502</div></div><div class="toolbar"><input id="newId" type="number" min="1" max="247" value="3"><select id="newRole"><option value="sensor">Sıcaklık</option><option value="timer">Timer</option><option value="combined">Birleşik</option></select><button onclick="addDevice()">Cihaz ekle</button></div><div id="grid" class="grid"></div><div class="foot">Ana uygulamada connection_api.py içindeki MODBUS_MODE değerini simulator yapıp uygulamayı yeniden başlatın.</div></div><script>
const fields=[['temperature','Anlık sıcaklık','°C'],['setpoint','Set sıcaklığı','°C'],['hysteresis','Histerezis','°C'],['alarm_delta','Alarm farkı','°C'],['timer1','Timer T1','dk'],['timer2','Timer T2','dk'],['remaining1','Kalan T1','dk'],['remaining2','Kalan T2','dk']];
async function api(path,opt){let r=await fetch('/api'+path,opt);if(!r.ok)throw Error(await r.text());return r.json()}
function card(d){let fs=fields.map(f=>`<div class="field"><label>${f[1]} (${f[2]})</label><input data-k="${f[0]}" type="number" step="0.1" value="${Number(d[f[0]]).toFixed(1)}"></div>`).join('');return `<div class="card" data-id="${d.id}"><div class="title"><h2>Slave ${d.id} · ${d.role}</h2><span class="status ${d.running?'on':''}">${d.running?'ÇALIŞIYOR':'DURDU'}</span></div><div class="fields">${fs}</div><div class="actions"><button onclick="act(${d.id},'start')">Başlat</button><button class="stop" onclick="act(${d.id},'stop')">Durdur</button><button class="reset" onclick="act(${d.id},'reset')">Sıfırla</button><button class="delete" onclick="del(${d.id})">Sil</button></div></div>`}
async function load(){let ds=await api('/devices');document.querySelector('#grid').innerHTML=ds.map(card).join('')}
async function act(id,action){let c=document.querySelector(`[data-id="${id}"]`),body={action};c.querySelectorAll('input[data-k]').forEach(x=>body[x.dataset.k]=Number(x.value));await api('/devices/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});load()}
async function addDevice(){await api('/devices',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:Number(newId.value),role:newRole.value})});load()}
async function del(id){await api('/devices/'+id,{method:'DELETE'});load()}load();setInterval(load,3000);
</script></body></html>'''


def make_handler(simulator):
    class Handler(BaseHTTPRequestHandler):
        def send(self, status, body, content_type="application/json"):
            raw = body.encode() if isinstance(body, str) else json.dumps(body).encode()
            self.send_response(status); self.send_header("Content-Type", f"{content_type}; charset=utf-8")
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def body(self):
            return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/": return self.send(200, HTML, "text/html")
            if path == "/api/devices": return self.send(200, simulator.snapshot())
            self.send(404, {"error": "Bulunamadı"})
        def do_POST(self):
            if urlparse(self.path).path == "/api/devices":
                data = self.body(); return self.send(201, simulator.add_device(data["id"], data.get("role", "combined")))
            self.send(404, {"error": "Bulunamadı"})
        def do_PUT(self):
            parts = urlparse(self.path).path.strip("/").split("/")
            if len(parts) == 3 and parts[:2] == ["api", "devices"]:
                return self.send(200, simulator.update(int(parts[2]), self.body()))
            self.send(404, {"error": "Bulunamadı"})
        def do_DELETE(self):
            parts = urlparse(self.path).path.strip("/").split("/")
            if len(parts) == 3 and parts[:2] == ["api", "devices"]:
                simulator.remove_device(int(parts[2])); return self.send(200, {"ok": True})
            self.send(404, {"error": "Bulunamadı"})
        def log_message(self, fmt, *args):
            return
    return Handler


def load_device_layout(database_path):
    """Aktif makinelerdeki slave ID ve rollerini SQLite veritabanından al."""
    path = Path(database_path)
    if not path.is_file():
        return {}
    layout = {}
    try:
        with sqlite3.connect(path) as connection:
            rows = connection.execute(
                "SELECT sensor_ids, timer_id FROM machines WHERE is_active = 1"
            ).fetchall()
        for raw_sensor_ids, timer_id in rows:
            for sensor_id in json.loads(raw_sensor_ids or "[]"):
                layout[int(sensor_id)] = "sensor"
            if timer_id is not None:
                timer_id = int(timer_id)
                layout[timer_id] = "combined" if layout.get(timer_id) == "sensor" else "timer"
    except (sqlite3.Error, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"Makine ayarları okunamadı ({path}): {exc}")
        return {}
    return layout


async def main():
    parser = argparse.ArgumentParser(description="OZDEKAN Modbus cihaz simülatörü")
    parser.add_argument("--modbus-port", type=int, default=1502)
    parser.add_argument("--ui-port", type=int, default=8765)
    parser.add_argument("--db", default=str(Path(__file__).resolve().parent / "logs.db"))
    args = parser.parse_args()
    layout = load_device_layout(args.db)
    simulator = Simulator(layout or None)
    server = ThreadingHTTPServer(("127.0.0.1", args.ui_port), make_handler(simulator))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"Simülatör arayüzü: http://127.0.0.1:{args.ui_port}")
    print(f"Modbus TCP: 127.0.0.1:{args.modbus_port}")
    print("Sanal cihazlar: " + ", ".join(f"{key}={value}" for key, value in sorted((layout or {1: 'sensor', 2: 'timer'}).items())))
    await StartAsyncTcpServer(context=simulator.context, address=("127.0.0.1", args.modbus_port))


if __name__ == "__main__":
    asyncio.run(main())
