"""Read-only RTU probe. Stop the application before opening its serial port.

Reads FC03/FC04 only; does not import the application or modify its database.
"""
import argparse
import json
import time
from pathlib import Path


def crc16(data):
    crc = 0xFFFF
    for value in data:
        crc ^= value
        for _ in range(8):
            crc = (crc >> 1) ^ (0xA001 if crc & 1 else 0)
    return crc.to_bytes(2, "little")


def probe(link, slave, function, count, timeout):
    body = bytes([slave, function, 0, 0, count >> 8, count & 255])
    link.reset_input_buffer()
    started = time.monotonic()
    link.write(body + crc16(body))
    link.flush()
    received = bytearray()
    while time.monotonic() - started < timeout:
        received.extend(link.read(max(1, link.in_waiting)))
        if len(received) >= 3:
            expected = 5 if received[1] & 0x80 else received[2] + 5
            if len(received) >= expected:
                break
    elapsed = time.monotonic() - started
    data = bytes(received)
    crc_ok = len(data) >= 5 and crc16(data[:-2]) == data[-2:]
    ok = (len(data) == count * 2 + 5 and data[:3] == bytes([slave, function, count * 2]) and crc_ok)
    result = {"slave": slave, "function": function, "address": 0, "count": count,
              "seconds": round(elapsed, 3), "bytes": len(data), "crc_ok": crc_ok,
              "ok": ok, "rx_hex": data.hex(" ")}
    if len(data) == 5 and data[1] == function | 0x80 and crc_ok:
        result["exception_code"] = data[2]
    if ok:
        result["first_value"] = int.from_bytes(data[3:5], "big")
    print(json.dumps(result), flush=True)


def main():
    parser = argparse.ArgumentParser(description="Read-only Modbus RTU probe; stop the main application first.")
    parser.add_argument("--slave", type=int, required=True)
    parser.add_argument("--config", default=str(Path(__file__).with_name("config.json")))
    parser.add_argument("--port")
    parser.add_argument("--timeout", type=float, default=3.0)
    args = parser.parse_args()
    if not 1 <= args.slave <= 247 or args.timeout <= 0:
        parser.error("slave must be 1..247; timeout must be positive")
    import serial
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    port = args.port or config.get("modbus_port")
    if not port:
        parser.error("Set --port or modbus_port in config.json")
    print("Main application must be stopped. READ ONLY: no settings or database writes.", flush=True)
    with serial.Serial(port=port, baudrate=int(config.get("modbus_baudrate", 9600)),
                       parity=config.get("modbus_parity", "N"),
                       stopbits=int(config.get("modbus_stopbits", 1)),
                       bytesize=int(config.get("modbus_bytesize", 8)), timeout=0.05,
                       write_timeout=3) as link:
        time.sleep(0.3)
        for function, count in [(4, 1), (3, 1), (3, 11), (3, 13), (3, 30), (3, 52)]:
            probe(link, args.slave, function, count, args.timeout)
            time.sleep(0.3)


if __name__ == "__main__":
    main()
