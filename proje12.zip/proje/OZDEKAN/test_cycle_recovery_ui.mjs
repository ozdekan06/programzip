// Standalone: node test_cycle_recovery_ui.mjs. No npm dependencies or production data.
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source = await readFile(new URL('./static/cycle_recovery.js', import.meta.url), 'utf8');
class Element {
  constructor(tag='div') { this.tagName=tag; this.children=[]; this.dataset={}; this.attributes={}; this.open=false; this.disabled=false; this.hidden=false; this._value=undefined; this.listeners={}; }
  append(...nodes) { for (const n of nodes) { n.remove?.(); n.parent=this; this.children.push(n); } }
  prepend(...nodes) { for(const n of nodes.reverse()) { n.remove?.(); n.parent=this; this.children.unshift(n); } }
  remove() { if(this.parent) { this.parent.children=this.parent.children.filter(n=>n!==this); this.parent=null; } }
  replaceWith(n) { const p=this.parent; if(!p)return; const i=p.children.indexOf(this); p.children[i]=n;n.parent=p;this.parent=null; }
  replaceChildren(...nodes) { this.children.forEach(n=>n.parent=null); this.children=[]; this.append(...nodes);this._text=''; }
  addEventListener(name, fn) { this.listeners[name]=fn; }
  showModal() { this.open=true; }
  close() { this.open=false; }
  scrollIntoView() {}
  get options() { return this.children.filter(n=>n.tagName==='option'); }
  get value() { return this._value ?? (this.tagName==='select' ? this.options[0]?.value || '' : this.attributes.value || ''); }
  set value(v) { this._value=String(v); }
  get textContent() { return this._text || ''; }
  set textContent(v) { this._text=String(v);this.replaceChildren();this._text=String(v); }
  get elements() { const out={};for(const n of this.descendants()) if(n.attributes.name) out[n.attributes.name]=n;return out; }
  *descendants() { for(const n of this.children) { yield n;yield* n.descendants(); } }
  querySelector(selector) { return [...this.descendants()].find(n=>matches(n,selector)) || null; }
  set innerHTML(html) {
    this.replaceChildren(); const stack=[this];
    for(const token of html.match(/<[^>]+>|[^<]+/g)||[]) {
      if(token.startsWith('</')) { stack.pop();continue; }
      if(!token.startsWith('<'))continue;
      const tag=token.match(/^<([\w-]+)/)?.[1]; if(!tag)continue;
      const e=new Element(tag);
      for(const match of token.slice(tag.length+1,-1).matchAll(/([\w-]+)(?:="([^"]*)"|='([^']*)')?/g)) {
        const key=match[1],val=match[2]??match[3]??'';e.attributes[key]=val;
        if(key==='class')e.className=val;
        if(key==='id')e.id=val;
        if(key==='disabled')e.disabled=true;
        if(key==='hidden')e.hidden=true;
        if(key.startsWith('data-'))e.dataset[key.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=val;
      }
      stack.at(-1).append(e); if(!['input','br','hr','img'].includes(tag))stack.push(e);
    }
  }
}
function matches(n, selector) {
  if(selector.startsWith('.'))return (n.className||'').split(' ').includes(selector.slice(1));
  if(selector.startsWith('#'))return n.id===selector.slice(1);
  const m=selector.match(/^(\w+)?\[([^=\]]+)(?:=['"]?([^'"\]]+)['"]?)?\]$/);
  if(m)return (!m[1]||m[1]===n.tagName) && (m[3]===undefined ? m[2] in n.attributes : n.attributes[m[2]]===m[3]);
  return n.tagName===selector;
}
class FormData {
  constructor(form) { this.rows=Object.entries(form.elements).filter(([,e])=>!e.disabled).map(([n,e])=>[n,e.value]); }
  [Symbol.iterator]() {return this.rows[Symbol.iterator]();}
}
const response = rows=>({ok:true,json:async()=>rows});
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
function harness() {
  const sandbox={document:{head:new Element('head'),body:new Element('body'),createElement:t=>new Element(t)},location:{search:''},localStorage:{getItem:()=>null,setItem(){}},URLSearchParams,FormData,Date,Math,crypto:{randomUUID:()=>`request-${++sandbox.ids}`},ids:0,window:{},console:{error(){}},fetch:async()=>response([])};
  vm.createContext(sandbox);
  const exposed=source.replace("  poll(requestedReview); setInterval(() => { if (!busy) poll(); }, 5000);", "  globalThis.audit={poll,submit,render,recoveryForms,historyForms,dialog,badge, seed(p,h=[]){pending=p;history=h;render(true);}, get(){return {pending,history,busy};}};");
  assert.notEqual(exposed,source);
  vm.runInContext(exposed,sandbox);
  sandbox.rows=(p=[],h=[])=>{sandbox.fetch=async url=>response(url==='/cycle-recovery'?p:h);};
  return sandbox;
}
const item=(id=1,revision=1)=>({machine_id:id,machine_name:`Machine ${id}`,revision,reference_at:'2026-01-01T10:00:00',reference_phase:'cooking',live_phase:'cooking',live_at:'2026-01-01T10:00:10',quality:'GOOD',buffered_events:0,cycle:{id:10+id,cycle_start_time:'2026-01-01T09:00:00',cooking_start_time:'2026-01-01T09:00:00',cooking_duration:null}});
const historical=(id=100)=>({id,machine_id:1,machine_name:'Machine 1',cycle_start_time:'2026-01-01T08:00:00',cycle_end_time:'2026-01-01T09:00:00',cooking_start_time:'2026-01-01T08:00:00',cooking_duration:30,active_products:0,linked_tasks:0});
const tests=[];const test=(name,run)=>tests.push({name,run});
test('live polling preserves draft and node identity',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;f.elements.note.value='keep';s.rows([{...item(),live_at:'2026-01-01T10:00:20'}]);await s.audit.poll();assert.equal(s.audit.recoveryForms.get(1).form,f);assert.equal(f.elements.note.value,'keep');assert.equal(f.dataset.stale,undefined);});
test('revision changes disable old form even with automatic alerts off',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;f.elements.note.value='keep old';s.rows([item(1,2)]);await s.audit.poll();assert.equal(f.dataset.stale,'true');assert.equal(f.elements.note.value,'keep old');assert.equal(f.querySelector('button[type=submit]').disabled,true);let posts=0;s.fetch=async()=>{posts++;return response([])};await s.audit.submit(f,'/cycle-recovery/1',{revision:1});assert.equal(posts,0);});
test('explicit refresh replaces only stale card and preserves other drafts',async()=>{const s=harness();s.audit.seed([item(),item(2)]);const f=s.audit.recoveryForms.get(1).form,other=s.audit.recoveryForms.get(2).form;f.elements.note.value='old';other.elements.note.value='other draft';s.rows([item(1,2),item(2)]);await s.audit.poll();await f.children[0].querySelector('button').onclick();assert.notEqual(s.audit.recoveryForms.get(1).form,f);assert.equal(s.audit.recoveryForms.get(1).form.dataset.stale,undefined);assert.equal(other.elements.note.value,'other draft');assert.equal(s.audit.recoveryForms.get(2).form,other);});
test('failed stale refresh preserves old draft',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;f.elements.note.value='keep';s.rows([item(1,2)]);await s.audit.poll();s.fetch=async()=>{throw Error('offline')};await f.children[0].querySelector('button').onclick();assert.equal(s.audit.recoveryForms.get(1).form,f);assert.equal(f.elements.note.value,'keep');});
test('history additions and removals reconcile without erasing unchanged drafts',async()=>{const s=harness();s.audit.seed([],[historical()]);const f=s.audit.historyForms.get(100).form;f.elements.note.value='history draft';s.rows([],[historical(),historical(101)]);await s.audit.poll();assert.equal(s.audit.historyForms.size,2);assert.equal(f.elements.note.value,'history draft');s.rows([],[historical(101)]);await s.audit.poll();assert.equal(s.audit.historyForms.has(100),false);});
test('history changed snapshot is stale rather than silently rebased',async()=>{const s=harness();s.audit.seed([],[historical()]);const f=s.audit.historyForms.get(100).form;f.elements.note.value='keep';s.rows([],[{...historical(),active_products:1}]);await s.audit.poll();assert.equal(f.dataset.stale,'true');assert.equal(f.elements.note.value,'keep');});
test('successful POST removes old form even when subsequent GET fails',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;let posts=0;s.fetch=async(url,opt)=>{if(opt?.method==='POST'){posts++;return response({message:'Confirmed'})}throw Error('offline')};await s.audit.submit(f,'/cycle-recovery/1',{revision:1});assert.equal(s.audit.recoveryForms.has(1),false);assert.equal(f.dataset.submitted,'true');assert.equal(f.querySelector('button[type=submit]').disabled,true);assert.match(s.audit.dialog.querySelector('[data-status]').textContent,/başarıyla kaydedildi/);await s.audit.submit(f,'/cycle-recovery/1',{revision:1});assert.equal(posts,1);});
test('pre-submit GET cannot resurrect confirmed form',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form,d=deferred();let first=0;s.fetch=async(url,opt)=>{if(opt?.method==='POST')return response({message:'Confirmed'});if(first++<2){await d.promise;return response(url==='/cycle-recovery'?[item()]:[])}return response([])};const old=s.audit.poll();await s.audit.submit(f,'/cycle-recovery/1',{revision:1});d.resolve();await old;assert.equal(s.audit.recoveryForms.size,0);assert.equal(s.audit.get().pending.length,0);});
test('out-of-order GET responses retain newest snapshot',async()=>{const s=harness(),d=deferred();let calls=0;s.fetch=async url=>{if(calls++<2){await d.promise;return response(url==='/cycle-recovery'?[item(1,1)]:[])}return response(url==='/cycle-recovery'?[item(1,2)]:[])};const old=s.audit.poll();await s.audit.poll();d.resolve();await old;assert.equal(s.audit.get().pending[0].revision,2);});
test('hidden date controls excluded from payload and finished unavailable during cooking',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;assert.equal(f.elements.cycle_start_time.disabled,true);assert.equal(f.elements.cooking_end_time.disabled,true);assert.equal(f.elements.cycle_end_time.disabled,true);assert.equal(f.elements.action.options.some(o=>o.value==='finished'),false);assert.equal(f.elements.phase.options.find(o=>o.value==='renewal').disabled,true);f.elements.action.value='new';f.elements.action.onchange();assert.equal(f.elements.cycle_start_time.disabled,false);f.elements.cycle_start_time.value='2099-01-01T12:00:00';f.elements.action.value='continue';f.elements.action.onchange();assert.equal(new FormData(f).rows.some(([k])=>k==='cycle_start_time'),false);});
test('renewal/finished show appropriate controls and history invalidate excludes dates/merge ids',async()=>{const s=harness();s.audit.seed([{...item(),reference_phase:'renewal'}],[historical()]);const f=s.audit.recoveryForms.get(1).form;assert.equal(f.elements.phase.value,'renewal');assert.equal(f.elements.cooking_end_time.disabled,false);f.elements.action.value='finished';f.elements.action.onchange();assert.equal(f.elements.phase.disabled,true);assert.equal(f.elements.cycle_end_time.disabled,false);const h=s.audit.historyForms.get(100).form;h.elements.action.value='invalidate';h.elements.action.onchange();assert.equal(h.elements.merge_ids.disabled,true);assert.equal(new FormData(h).rows.some(([k])=>k==='cycle_start_time'),false);});
test('ambiguous POST retry reuses body/request id; changed payload gets new id',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form,bodies=[];s.fetch=async(url,opt)=>{bodies.push(opt.body);throw Error('lost response')};await s.audit.submit(f,'/cycle-recovery/1',{revision:1,note:'same'});await s.audit.submit(f,'/cycle-recovery/1',{revision:1,note:'same'});await s.audit.submit(f,'/cycle-recovery/1',{revision:1,note:'changed'});assert.equal(bodies[0],bodies[1]);assert.notEqual(JSON.parse(bodies[0]).request_id,JSON.parse(bodies[2]).request_id);});
test('successful POST can show next separate recovery without resubmitting prior card',async()=>{const s=harness();s.audit.seed([item()]);const f=s.audit.recoveryForms.get(1).form;s.fetch=async(url,opt)=>opt?.method==='POST'?response({message:'First saved'}):response(url==='/cycle-recovery'?[item(1,2)]:[]);await s.audit.submit(f,'/cycle-recovery/1',{revision:1});assert.equal(s.audit.get().pending[0].revision,2);assert.notEqual(s.audit.recoveryForms.get(1).form,f);assert.match(s.audit.dialog.querySelector('[data-status]').textContent,/ayrı bir doğrulama/);});

let passed=0;
for(const {name,run} of tests) {try{await run();console.log(`PASS ${name}`);passed++;}catch(error){console.error(`FAIL ${name}`);throw error;}}
console.log(`${passed} recovery UI regression tests passed`);
