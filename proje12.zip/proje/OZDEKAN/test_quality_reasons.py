"""Run with: OZDEKAN_DATA_DIR=<temporary directory> python3 -m unittest test_quality_reasons -v"""
import asyncio
import io
import json
import unittest
import zipfile
from datetime import datetime

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from main import app
from database import get_db
from models import Base, Machine, Person, Order, CycleLog, TaskLog, Product
from quality_reasons import migrate_quality_reasons


class QualityReasonTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine('sqlite://', connect_args={'check_same_thread': False}, poolclass=StaticPool)
        Base.metadata.create_all(self.engine)
        self.db = sessionmaker(bind=self.engine)()
        self.db.add_all([Machine(id=1, name='Test', sensor_ids=[], sensor_count=0),
                         Person(id=1, name='Test', surname='Operator'),
                         Order(name='Test', productsize='1', producttype='T', moldnumber='M', ordernumber='TEST', quantity=10),
                         CycleLog(id=1, machine_id=1, cycle_start_time=datetime.now())])
        self.db.commit()
        def override():
            yield self.db
        app.dependency_overrides[get_db] = override

    def tearDown(self):
        app.dependency_overrides.clear()
        self.db.close()
        self.engine.dispose()

    def request(self, method, path, payload=None):
        async def run():
            url, _, query = path.partition('?')
            raw = json.dumps(payload).encode() if payload is not None else b''
            sent = False
            messages = []
            async def receive():
                nonlocal sent
                if not sent:
                    sent = True
                    return {'type': 'http.request', 'body': raw, 'more_body': False}
                await asyncio.Event().wait()
            async def send(message):
                messages.append(message)
            scope = {'type': 'http', 'asgi': {'version':'3.0', 'spec_version':'2.4'},
                     'http_version':'1.1', 'method':method, 'scheme':'http', 'path':url,
                     'raw_path':url.encode(), 'query_string':query.encode(),
                     'headers':[(b'content-type',b'application/json')],
                     'server':('test',80), 'client':('test',123), 'root_path':''}
            await app(scope, receive, send)
            status = next(m['status'] for m in messages if m['type']=='http.response.start')
            body = b''.join(m.get('body',b'') for m in messages if m['type']=='http.response.body')
            return status, body
        status, body = asyncio.run(run())
        try:
            return status, json.loads(body)
        except (ValueError, UnicodeDecodeError):
            return status, body

    def reason(self, status='FAILED', name='Yüzey çatlağı'):
        code, data = self.request('POST','/quality-reasons', {'status':status,'name':name})
        self.assertEqual(code,201, data)
        return data['id']

    def product(self, serial='TEST/1', status='SUCCESS', reason_id=None):
        return {'name':'Test','serialnumber':serial,'productsize':'1','producttype':'T','moldnumber':'M',
                'ordernumber':'TEST','machine_id':1,'person_id':1,'cycle_id':1,
                'status':status,'quality_reason_id':reason_id}

    def test_reason_validation_and_archive(self):
        reason_id = self.reason()
        self.assertEqual(self.request('POST','/quality-reasons',{'status':'FAILED','name':' Yüzey   çatlağı '})[0],409)
        self.assertEqual(self.request('POST','/quality-reasons',{'status':'UNKNOWN','name':'x'})[0],400)
        self.assertEqual(self.request('POST','/quality-reasons',{'status':'FAILED','name':' '})[0],400)
        self.assertEqual(self.request('PATCH',f'/quality-reasons/{reason_id}',{'is_active':False})[0],200)
        self.assertEqual(self.request('GET','/quality-reasons')[1],[])
        self.assertEqual(len(self.request('GET','/quality-reasons?include_inactive=true')[1]),1)
        self.assertEqual(self.request('POST','/products',self.product(status='FAILED',reason_id=reason_id))[0],400)
        self.assertEqual(self.db.query(Product).count(),0)
        self.assertEqual(self.request('PATCH',f'/quality-reasons/{reason_id}',{'is_active':True})[0],200)
        self.assertEqual(self.request('POST','/products',self.product(status='FAILED',reason_id=reason_id))[0],200)

    def test_missing_wrong_and_success_reasons_rejected_before_write(self):
        reason_id=self.reason()
        for status, selected in [('FAILED',None),('CONDITIONAL',reason_id),('FAILED',999),('SUCCESS',reason_id),('FAILED',True),('FAILED',1.5)]:
            self.assertEqual(self.request('POST','/products',self.product(status=status,reason_id=selected))[0],400)
            self.assertEqual(self.db.query(Product).count(),0)
        self.assertEqual(self.request('POST','/products',self.product())[0],200)

    def test_manual_batch_validation_is_atomic(self):
        reason_id=self.reason('CONDITIONAL','Ölçü toleransı')
        first=self.product(serial='MAN/1',status='CONDITIONAL',reason_id=reason_id)
        second=self.product(serial='MAN/2',status='FAILED')
        self.assertEqual(self.request('POST','/products/manual',[first,second])[0],400)
        self.assertEqual(self.db.query(Product).count(),0)
        self.assertEqual(self.request('POST','/products/manual',[first])[0],200)
        task=self.db.query(TaskLog).one()
        self.assertEqual(task.quality_reason_name,'Ölçü toleransı')
        self.assertIsNone(task.cycle_id)

    def test_latest_reason_filter_history_export_and_archive(self):
        failed=self.reason()
        conditional=self.reason('CONDITIONAL','Ölçü toleransı')
        code,data=self.request('POST','/products',self.product(status='FAILED',reason_id=failed))
        self.assertEqual(code,200,data)
        pid=data['id']
        self.assertEqual(self.request('PATCH',f'/products/{pid}/status',{'status':'CONDITIONAL'})[0],400)
        self.assertEqual(self.request('PATCH',f'/products/{pid}/status',{'status':'CONDITIONAL','quality_reason_id':conditional})[0],200)
        self.assertEqual(self.request('GET',f'/product-logs?quality_reason_id={failed}')[1],[])
        self.assertEqual(self.request('GET','/product-logs?status=FAILED')[1],[])
        code,rows=self.request('GET',f'/product-logs?status=CONDITIONAL&quality_reason_id={conditional}')
        self.assertEqual(code,200,rows)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['quality_reason_name'],'Ölçü toleransı')
        self.assertEqual(rows[0]['tasks'][0]['quality_reason_id'],failed)
        self.request('PATCH',f'/quality-reasons/{conditional}',{'is_active':False})
        self.assertEqual(len(self.request('GET',f'/product-logs?quality_reason_id={conditional}')[1]),1)
        code,raw=self.request('POST','/product-logs/export',{'filtered':True,'product_ids':[pid]})
        self.assertEqual(code,200)
        xml=zipfile.ZipFile(io.BytesIO(raw)).read('xl/worksheets/sheet1.xml').decode()
        self.assertIn('Kalite Nedeni',xml)
        self.assertIn('Ölçü toleransı',xml)
        self.assertEqual(self.request('PATCH',f'/products/{pid}/status',{'status':'SUCCESS'})[0],200)
        self.assertEqual(self.request('GET',f'/product-logs?quality_reason_id={conditional}')[1],[])
        self.assertIsNone(self.request('GET','/product-logs')[1][0]['quality_reason_id'])

    def test_legacy_records_and_task_endpoint(self):
        self.request('POST','/products',self.product())
        task=self.db.query(TaskLog).one()
        task.status='FAILED';self.db.commit()
        code,rows=self.request('GET','/product-logs?status=FAILED')
        self.assertEqual(code,200)
        self.assertIsNone(rows[0]['quality_reason_id'])
        self.assertEqual(self.request('POST','/task-logs',{'status':'FAILED'})[0],400)

    def test_multiple_reasons_and_success_minor_errors(self):
        for index, status in enumerate(['SUCCESS', 'FAILED', 'CONDITIONAL'], 1):
            first = self.reason(status, 'İlk hata')
            second = self.reason(status, 'İkinci hata')
            payload = self.product(serial=f'TEST/{index}', status=status)
            payload['quality_reason_ids'] = [first, second, first]
            code, data = self.request('POST', '/products', payload)
            self.assertEqual(code, 200, data)
            pid = data['id']
            for selected in [first, second]:
                code, rows = self.request('GET', f'/product-logs?quality_reason_id={selected}')
                self.assertEqual(code, 200, rows)
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]['quality_reason_ids'], [first, second])
            code, raw = self.request('POST', '/product-logs/export', {'filtered':True,'product_ids':[pid]})
            self.assertEqual(code, 200)
            xml = zipfile.ZipFile(io.BytesIO(raw)).read('xl/worksheets/sheet1.xml').decode()
            self.assertIn('İlk hata, İkinci hata', xml)
            self.assertEqual(self.request('PATCH', f'/products/{pid}/status', {'status':status,'quality_reason_ids':[second]})[0], 200)
            self.assertEqual(self.request('GET', f'/product-logs?quality_reason_id={first}')[1], [])
            wrong = self.reason('FAILED' if status != 'FAILED' else 'SUCCESS', f'Yanlış kategori {status}')
            self.assertEqual(self.request('PATCH', f'/products/{pid}/status', {'status':status,'quality_reason_ids':[second,wrong]})[0],400)
            self.assertEqual(self.request('GET', f'/product-logs?quality_reason_id={second}')[1][0]['quality_reason_ids'],[second])

    def test_migration_preserves_legacy_rows_and_is_repeatable(self):
        engine=create_engine('sqlite://')
        with engine.begin() as conn:
            conn.execute(text('CREATE TABLE task_logs (id INTEGER PRIMARY KEY, status TEXT, product_id INTEGER, timestamp DATETIME)'))
            conn.execute(text("INSERT INTO task_logs (id, status) VALUES (1, 'FAILED')"))
        migrate_quality_reasons(engine)
        migrate_quality_reasons(engine)
        with engine.connect() as conn:
            self.assertEqual(tuple(conn.execute(text('SELECT id,status,quality_reason_id,quality_reason_name FROM task_logs')).one()),(1,'FAILED',None,None))
        engine.dispose()


if __name__ == '__main__':
    unittest.main()
