import unittest
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Machine, CycleEvent, CycleLog, CycleRecovery, CycleAudit
from cycle_service import (new_cycle, process_events, initialize_recovery, observe_timer,
                           resolve_recovery, repair_history, resolve_history, open_cycle)


class CycleRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine('sqlite:///:memory:')
        Base.metadata.create_all(self.engine)
        self.db = sessionmaker(bind=self.engine, autoflush=False)()
        self.machine = Machine(name='test', slave_id=999, sensor_ids=[], sensor_count=0, timer_id=999)
        self.db.add(self.machine); self.db.commit()
        self.at = datetime(2026, 1, 1, 10)

    def tearDown(self):
        self.db.close(); self.engine.dispose()

    def event(self, kind, minute):
        self.db.add(CycleEvent(machine_id=self.machine.id, timestamp=self.at + timedelta(minutes=minute),
                               event_type=kind, details={'t1_min':10, 't2_min':5}))
        self.db.commit()

    def cycle(self):
        c = new_cycle(self.db, self.machine.id, self.at, {'t1_min':10, 't2_min':5})
        self.db.commit()
        return c

    def baseline(self, c=None, value=1):
        initialize_recovery(self.db, self.at + timedelta(minutes=5))
        observe_timer(self.db, self.machine.id, value, self.at + timedelta(minutes=5))
        return self.db.get(CycleRecovery, self.machine.id)

    def decision(self, **kwargs):
        state = self.db.get(CycleRecovery, self.machine.id)
        return dict(revision=state.revision, note='operator verification', **kwargs)

    def test_repeated_start_preserves_real_start(self):
        for kind, minute in [('START',0), ('START',5), ('STOP',10), ('START',15)]: self.event(kind, minute)
        process_events(self.db)
        rows = self.db.query(CycleLog).order_by(CycleLog.id).all()
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0].cycle_start_time, self.at)
        self.assertEqual(rows[0].cooking_duration, 10)
        self.assertEqual(rows[0].cycle_end_time, self.at + timedelta(minutes=15))

    def test_restart_confirmation_replays_edges(self):
        c = self.cycle(); self.baseline(c)
        # Samples are close enough to avoid the intentional communication-gap gate.
        observe_timer(self.db, self.machine.id, 0, self.at + timedelta(minutes=5, seconds=10))
        observe_timer(self.db, self.machine.id, 1, self.at + timedelta(minutes=5, seconds=20))
        process_events(self.db)
        self.assertEqual(self.db.query(CycleLog).count(), 1)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(), 2)
        resolve_recovery(self.db, self.machine.id, self.decision(action='continue', phase='cooking'))
        self.assertEqual(c.cycle_start_time, self.at)
        self.assertAlmostEqual(c.cooking_duration, 5 + 10/60)
        self.assertEqual(c.cycle_end_time, self.at + timedelta(minutes=5, seconds=20))
        self.assertEqual(self.db.query(CycleLog).count(), 2)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(), 0)

    def test_initial_high_requires_manual_start(self):
        state = self.baseline(value=1)
        self.assertTrue(state.pending)
        self.assertEqual(self.db.query(CycleLog).count(), 0)
        resolve_recovery(self.db, self.machine.id, self.decision(action='new', phase='cooking', cycle_start_time=self.at.isoformat()))
        self.assertEqual(open_cycle(self.db,self.machine.id).cycle_start_time, self.at)
        self.assertEqual(open_cycle(self.db,self.machine.id).time_source, 'operator')

    def test_initial_low_does_not_create_cycle(self):
        state = self.baseline(value=0)
        self.assertFalse(state.pending)
        observe_timer(self.db, self.machine.id, 1, self.at+timedelta(minutes=5, seconds=5))
        process_events(self.db)
        self.assertEqual(self.db.query(CycleLog).count(), 1)

    def test_renewal_needs_stop_and_preserves_original_start(self):
        c = self.cycle(); self.baseline(c,value=0)
        with self.assertRaises(ValueError):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue', phase='renewal'))
        self.db.rollback()
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='renewal', cooking_end_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertEqual(c.cooking_duration,4)
        self.assertEqual(c.cycle_start_time,self.at)

    def test_stale_confirmation_rejected(self):
        c=self.cycle();self.baseline(c)
        payload=self.decision(action='continue',phase='cooking')
        resolve_recovery(self.db,self.machine.id,payload)
        with self.assertRaises(ValueError): resolve_recovery(self.db,self.machine.id,payload)

    def test_invalid_new_time_rolls_back_old_cycle(self):
        c=self.cycle();self.baseline(c)
        with self.assertRaises(ValueError):
            resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='renewal',cycle_start_time=self.at.isoformat(),cooking_end_time=(self.at-timedelta(minutes=1)).isoformat()))
        self.db.rollback()
        self.assertTrue(c.is_valid)
        self.assertEqual(self.db.query(CycleLog).count(),1)

    def test_transaction_rollback_retries_without_duplicate_cycles(self):
        self.event('START',0)
        # Simulate failure after applying the event but before commit.
        from cycle_service import apply_event
        ev=self.db.query(CycleEvent).first();apply_event(self.db,ev)
        self.db.rollback()
        process_events(self.db)
        self.assertEqual(self.db.query(CycleLog).count(),1)
        self.assertEqual(self.db.query(CycleEvent).first().processed,1)

    def test_second_restart_keeps_reference_and_replays_before_next_gap(self):
        c=self.cycle(); self.baseline(c)
        payload=self.decision(action='continue',phase='cooking')
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=5))
        initialize_recovery(self.db,self.at+timedelta(minutes=6))
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=6))
        result = resolve_recovery(self.db,self.machine.id,payload)
        self.assertTrue(result['pending'])
        self.assertEqual(self.db.get(CycleRecovery,self.machine.id).reference_at,self.at+timedelta(minutes=6))
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='renewal',cooking_end_time=(self.at+timedelta(minutes=5,seconds=5)).isoformat()))
        self.assertEqual(c.cooking_duration,5+5/60)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(),0)

    def test_communication_gap_requires_reconciliation(self):
        self.baseline(value=0)
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=5))
        process_events(self.db)
        c=open_cycle(self.db,self.machine.id)
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=7))
        process_events(self.db)
        state=self.db.get(CycleRecovery,self.machine.id)
        self.assertTrue(state.pending)
        self.assertEqual(state.cycle_id,c.id)
        self.assertIsNone(c.cooking_duration)

    def test_healthy_slow_scan_does_not_reopen_confirmation(self):
        self.cycle();state=self.baseline()
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        revision=state.revision
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=6),communication_gap=False)
        process_events(self.db)
        self.assertFalse(state.pending)
        self.assertEqual(state.revision,revision)
        self.assertEqual(self.db.query(CycleEvent).count(),0)

    def test_pending_gap_does_not_change_form_and_keeps_recorded_cycles(self):
        old=self.cycle();state=self.baseline()
        payload=self.decision(action='continue',phase='cooking')
        reference,revision=state.reference_at,state.revision
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=6),communication_gap=True)
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=6,seconds=10))
        self.assertEqual((state.reference_at,state.revision),(reference,revision))
        result=resolve_recovery(self.db,self.machine.id,payload)
        self.assertTrue(result['pending'])
        self.assertEqual(state.reference_at,self.at+timedelta(minutes=6))
        self.assertEqual(self.db.query(CycleLog).count(),2)
        self.assertEqual(old.cycle_end_time,self.at+timedelta(minutes=5,seconds=20))
        self.assertAlmostEqual(old.cooking_duration,5+10/60)
        newer=open_cycle(self.db,self.machine.id)
        self.assertIsNone(newer.cooking_duration)
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.assertAlmostEqual(newer.cooking_duration,50/60)
        self.assertFalse(state.pending)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(),0)

    def test_each_real_gap_is_reconciled_in_order(self):
        self.cycle();state=self.baseline()
        first=state.reference_at
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=6),communication_gap=True)
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=7),communication_gap=True)
        self.assertEqual(state.reference_at,first)
        for minute in (6,7):
            result=resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
            self.assertTrue(result['pending'])
            self.assertEqual(state.reference_at,self.at+timedelta(minutes=minute))
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.assertFalse(state.pending)

    def test_gap_without_open_cycle_and_low_needs_no_confirmation(self):
        state=self.baseline(value=0)
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=6),communication_gap=True)
        process_events(self.db)
        self.assertFalse(state.pending)
        self.assertEqual(self.db.query(CycleEvent).filter_by(event_type='GAP',processed=1).count(),1)

    def test_duplicate_and_out_of_order_samples_do_not_change_live_state(self):
        state=self.baseline(value=0)
        at=state.last_seen_at
        self.assertFalse(observe_timer(self.db,self.machine.id,1,at,communication_gap=True))
        self.assertFalse(observe_timer(self.db,self.machine.id,1,at-timedelta(seconds=1)))
        self.assertEqual(state.last_start,0)
        self.assertEqual(state.last_seen_at,at)
        self.assertEqual(self.db.query(CycleEvent).count(),0)

    def test_conflicting_phase_rejected_without_swallowing_start(self):
        c=self.cycle();state=self.baseline(value=0)
        c.cooking_duration=4;self.db.commit()
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=10))
        with self.assertRaisesRegex(ValueError,'timer sinyaliyle uyuşmuyor'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.db.rollback()
        self.assertEqual(c.cooking_duration,4)
        self.assertTrue(state.pending)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(),1)
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='renewal',
                         cooking_end_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_wrong_recovery_target_is_rebound_only_after_explicit_refresh(self):
        c=self.cycle();state=self.baseline()
        state.cycle_id=None;self.db.commit()
        with self.assertRaisesRegex(ValueError,'Doğrulama hedefi'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',cycle_start_time=self.at.isoformat()))
        self.db.rollback()
        self.assertTrue(state.pending)
        self.assertEqual(state.cycle_id,c.id)
        self.assertEqual(self.db.query(CycleAudit).filter_by(action='recovery_target_normalized').count(),1)
        self.assertEqual(self.db.query(CycleLog).count(),1)
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.assertFalse(state.pending)

    def test_pending_reviewed_target_is_detached_on_restart_and_can_create_baseline(self):
        historical=self.cycle();state=self.baseline()
        old_reference=state.reference_at
        historical.review_required=True;self.db.commit()
        initialize_recovery(self.db,self.at+timedelta(minutes=6))
        self.assertTrue(state.pending)
        self.assertIsNone(state.cycle_id)
        self.assertEqual(state.reference_at,old_reference)
        self.assertTrue(historical.is_valid)
        self.assertTrue(historical.review_required)
        resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',
                         cycle_start_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertFalse(state.pending)
        self.assertEqual(self.db.query(CycleLog).count(),2)
        self.assertTrue(historical.is_valid)

    def test_pending_target_reviewed_during_session_needs_one_refresh_only(self):
        historical=self.cycle();state=self.baseline()
        historical.review_required=True;self.db.commit()
        payload=self.decision(action='continue',phase='cooking')
        with self.assertRaisesRegex(ValueError,'Doğrulama hedefi'):
            resolve_recovery(self.db,self.machine.id,payload)
        self.db.rollback()
        self.assertIsNone(state.cycle_id)
        resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',
                         cycle_start_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertFalse(state.pending)
        self.assertTrue(historical.review_required)

    def test_old_reference_never_rebinds_to_unrelated_later_production(self):
        historical=self.cycle();state=self.baseline()
        historical.review_required=True
        later=new_cycle(self.db,self.machine.id,self.at+timedelta(minutes=6),{'t1_min':12,'t2_min':3})
        self.db.commit()
        before=(later.cycle_start_time,later.cooking_duration,later.ideal_total_time)
        with self.assertRaisesRegex(ValueError,'Doğrulama hedefi'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.db.rollback()
        self.assertFalse(state.pending)
        self.assertEqual(state.cycle_id,later.id)
        self.assertEqual((later.cycle_start_time,later.cooking_duration,later.ideal_total_time),before)
        self.assertTrue(historical.review_required)
        entry=self.db.query(CycleAudit).filter_by(action='recovery_target_normalized').one()
        self.assertEqual(entry.details['reason'],'superseded_by_later_cycle')

    def test_obsolete_backlog_cannot_replay_against_later_production(self):
        historical=self.cycle();state=self.baseline()
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=40),communication_gap=True)
        historical.review_required=True
        later=new_cycle(self.db,self.machine.id,self.at+timedelta(minutes=6))
        self.db.add(CycleEvent(machine_id=self.machine.id,timestamp=self.at+timedelta(minutes=6,seconds=10),
                               event_type='STOP',details={}))
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'Doğrulama hedefi'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.db.rollback()
        process_events(self.db)
        self.assertFalse(state.pending)
        self.assertAlmostEqual(later.cooking_duration,10/60)
        self.assertEqual(later.cycle_start_time,self.at+timedelta(minutes=6))
        entry=self.db.query(CycleAudit).filter_by(action='recovery_target_normalized').one()
        self.assertEqual(len(entry.details['quarantined_event_ids']),3)
        self.assertEqual(self.db.query(CycleEvent).count(),4)

    def test_request_retry_is_idempotent_even_with_next_pending_gap(self):
        self.cycle();state=self.baseline()
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=6),communication_gap=True)
        payload=self.decision(action='continue',phase='cooking',request_id='request-one')
        first=resolve_recovery(self.db,self.machine.id,payload)
        revision=state.revision
        second=resolve_recovery(self.db,self.machine.id,{**payload,'timer_details':{'t1_min':99}})
        self.assertEqual(first,second)
        self.assertEqual(state.revision,revision)
        self.assertEqual(self.db.query(CycleAudit).filter_by(action='restart_resolved').count(),1)
        with self.assertRaisesRegex(ValueError,'farklı doğrulama'):
            resolve_recovery(self.db,self.machine.id,{**payload,'note':'different decision'})

    def test_reference_timer_settings_not_current_confirmation_settings(self):
        initialize_recovery(self.db,self.at+timedelta(minutes=5))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5),{'t1_min':10,'t2_min':5})
        resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',
                         cycle_start_time=self.at.isoformat(),timer_details={'t1_min':99,'t2_min':88}))
        c=open_cycle(self.db,self.machine.id)
        self.assertEqual((c.ideal_cooking_time,c.ideal_renewal_time),(10,5))

    def test_unknown_timer_ideals_do_not_become_zero(self):
        state=self.baseline()
        resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',cycle_start_time=self.at.isoformat()))
        c=open_cycle(self.db,self.machine.id)
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        process_events(self.db)
        self.assertIsNone(c.ideal_total_time)
        self.assertIsNone(c.cooking_delay)
        self.assertIsNone(c.total_delay)

    def test_legacy_moved_reference_replays_known_edges_then_requests_refresh(self):
        old=self.cycle();state=self.baseline()
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        state.reference_at=self.at+timedelta(minutes=6);self.db.commit()
        with self.assertRaisesRegex(ValueError,'eski geçişler cycle'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.db.rollback()  # API rollback must not undo the explicit staged repair.
        self.assertEqual(self.db.query(CycleLog).count(),2)
        self.assertAlmostEqual(old.cooking_duration,5+10/60)
        self.assertEqual(state.cycle_id,open_cycle(self.db,self.machine.id).id)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(),0)
        resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.assertFalse(state.pending)

    def test_ambiguous_legacy_prefix_moves_to_explicit_review(self):
        old=self.cycle();state=self.baseline()
        old.time_source='operator';self.db.commit()
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        state.reference_at=self.at+timedelta(minutes=6);self.db.commit()
        with self.assertRaisesRegex(ValueError,'Geçmiş incelemeye ayrıldı'):
            resolve_recovery(self.db,self.machine.id,self.decision(action='continue',phase='cooking'))
        self.db.rollback()
        self.assertTrue(old.is_valid)
        self.assertTrue(old.review_required)
        self.assertIsNone(state.cycle_id)
        self.assertEqual(self.db.query(CycleEvent).count(),2)
        self.assertEqual(self.db.query(CycleAudit).filter_by(action='legacy_reference_quarantined').count(),1)
        resolve_recovery(self.db,self.machine.id,self.decision(action='new',phase='cooking',
                         cycle_start_time=(self.at+timedelta(minutes=5,seconds=20)).isoformat()))
        self.assertFalse(state.pending)
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_gap_replay_failure_rolls_back_confirmation_and_events(self):
        from unittest.mock import patch
        import cycle_service
        self.cycle();state=self.baseline()
        observe_timer(self.db,self.machine.id,0,self.at+timedelta(minutes=5,seconds=10))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=5,seconds=20))
        observe_timer(self.db,self.machine.id,1,self.at+timedelta(minutes=6),communication_gap=True)
        payload=self.decision(action='continue',phase='cooking')
        real=cycle_service._process_event
        def fail_at_gap(db,event,recovery):
            real(db,event,recovery)
            if event.event_type=='GAP':
                raise RuntimeError('simulated transaction failure')
        with patch('cycle_service._process_event',fail_at_gap):
            with self.assertRaises(RuntimeError):
                resolve_recovery(self.db,self.machine.id,payload)
        self.db.rollback()
        self.assertTrue(state.pending)
        self.assertEqual(self.db.query(CycleLog).count(),1)
        self.assertEqual(self.db.query(CycleEvent).filter_by(processed=0).count(),3)
        resolve_recovery(self.db,self.machine.id,payload)
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_historical_repair_is_audited_and_idempotent(self):
        c=self.cycle()
        dup=new_cycle(self.db,self.machine.id,self.at+timedelta(minutes=5));
        dup.cooking_duration=5;dup.cycle_end_time=self.at+timedelta(minutes=15);self.db.commit()
        for kind,minute in [('START',0),('START',5),('STOP',10),('START',15)]:self.event(kind,minute)
        result=repair_history(self.db)
        self.assertEqual(result[0]['action'],'historical_duplicate_repaired')
        self.assertEqual(c.cooking_duration,10)
        self.assertEqual(c.cycle_end_time,self.at+timedelta(minutes=15))
        self.assertFalse(dup.is_valid)
        self.assertTrue(c.review_required)
        self.assertEqual(repair_history(self.db),[])
        self.assertEqual(self.db.query(CycleAudit).count(),1)

    def test_history_can_be_verified(self):
        c=self.cycle();c.review_required=True;self.db.commit()
        resolve_history(self.db,c.id,dict(action='correct',note='verified',cycle_start_time=self.at.isoformat(),
                    cooking_end_time=(self.at+timedelta(minutes=10)).isoformat(),cycle_end_time=(self.at+timedelta(minutes=15)).isoformat()))
        self.assertFalse(c.review_required)
        self.assertEqual(c.total_duration,15)

    def test_history_request_retry_is_idempotent(self):
        c=self.cycle();c.review_required=True;self.db.commit()
        payload=dict(action='correct',note='verified',request_id='history-one',
                     cycle_start_time=self.at.isoformat(),
                     cooking_end_time=(self.at+timedelta(minutes=10)).isoformat(),
                     cycle_end_time=(self.at+timedelta(minutes=15)).isoformat())
        first=resolve_history(self.db,c.id,payload)
        second=resolve_history(self.db,c.id,payload)
        self.assertEqual(first,second)
        self.assertEqual(self.db.query(CycleAudit).filter_by(action='historical_resolved').count(),1)
        with self.assertRaisesRegex(ValueError,'farklı doğrulama'):
            resolve_history(self.db,c.id,{**payload,'note':'changed'})




class CycleRecoveryApiTests(unittest.TestCase):
    # Reuse the project's dependency-free ASGI request helper.
    from test_quality_reasons import QualityReasonTests
    request = QualityReasonTests.request

    def setUp(self):
        from sqlalchemy.pool import StaticPool
        from main import app
        from database import get_db
        from models import Person, Product, TaskLog
        self.app, self.get_db = app, get_db
        self.engine = create_engine('sqlite://', connect_args={'check_same_thread':False}, poolclass=StaticPool)
        Base.metadata.create_all(self.engine)
        self.db = sessionmaker(bind=self.engine, autoflush=False)()
        self.at = datetime(2026,1,1,10)
        self.db.add_all([Machine(id=1,name='M',slave_id=7,timer_id=7,sensor_ids=[],sensor_count=0),
                         Person(id=1,name='A',surname='B'), Product(id=1,name='P',serialnumber='1',productsize='x',producttype='x',moldnumber='1')])
        self.db.commit()
        self.cycle = new_cycle(self.db,1,self.at)
        self.db.commit()
        initialize_recovery(self.db,self.at+timedelta(minutes=5))
        observe_timer(self.db,1,0,self.at+timedelta(minutes=5))
        def override(): yield self.db
        app.dependency_overrides[get_db]=override

    def tearDown(self):
        self.app.dependency_overrides.clear()
        self.db.close();self.engine.dispose()

    def test_snapshot_and_confirmation_api(self):
        code,rows=self.request('GET','/cycle-recovery')
        self.assertEqual(code,200)
        self.assertEqual(rows[0]['cycle']['cycle_start_time'],self.at.isoformat())
        self.assertEqual(rows[0]['reference_phase'],'renewal')
        code,data=self.request('POST','/cycle-recovery/1',dict(revision=rows[0]['revision'],action='continue',phase='renewal',
                     cooking_end_time=(self.at+timedelta(minutes=4)).isoformat(),note='verified'))
        self.assertEqual(code,200,data)
        self.assertEqual(self.request('GET','/cycle-recovery')[1],[])
        self.assertEqual(self.cycle.cooking_duration,4)
        self.assertEqual(self.request('GET','/cycle-audit')[1][0]['action'],'restart_resolved')

    def test_product_and_shift_actions_block_unconfirmed_cycle(self):
        code,_=self.request('POST','/products',dict(cycle_id=self.cycle.id,name='P',serialnumber='2'))
        self.assertEqual(code,409)
        self.assertEqual(self.request('POST',f'/cycle-logs/{self.cycle.id}/close-shift')[0],409)
        self.assertEqual(self.request('POST',f'/cycle-logs/{self.cycle.id}/invalidate',dict(reason='x'))[0],409)

    def test_invalid_confirmation_does_not_invalidate_old_cycle(self):
        state=self.db.get(CycleRecovery,1)
        code,_=self.request('POST','/cycle-recovery/1',dict(revision=state.revision,action='new',phase='renewal',
                    cycle_start_time=self.at.isoformat(),cooking_end_time=(self.at-timedelta(minutes=1)).isoformat(),note='x'))
        self.assertEqual(code,409)
        self.assertTrue(self.cycle.is_valid)
        self.assertEqual(self.db.query(CycleLog).count(),1)

    def test_linked_history_needs_operator_and_merge_preserves_products(self):
        from models import TaskLog
        # Clear restart gate; the historical rows are a separate fixture.
        self.db.get(CycleRecovery,1).pending=False
        a=self.cycle
        b=new_cycle(self.db,1,self.at+timedelta(minutes=5))
        b.cooking_duration=5;b.cycle_end_time=self.at+timedelta(minutes=15)
        self.db.add_all([TaskLog(machine_id=1,person_id=1,product_id=1,cycle_id=a.id,task_name='a',status='SUCCESS'),
                         TaskLog(machine_id=1,person_id=1,product_id=1,cycle_id=b.id,task_name='b',status='SUCCESS')])
        self.db.commit()
        for kind,minute in [('START',0),('START',5),('STOP',10)]:
            self.db.add(CycleEvent(machine_id=1,event_type=kind,timestamp=self.at+timedelta(minutes=minute),processed=1))
        self.db.commit()
        repair_history(self.db)
        self.assertTrue(a.review_required);self.assertTrue(b.is_valid)
        self.assertEqual(len(self.request('GET','/cycle-history-review')[1]),2)
        code,data=self.request('POST',f'/cycle-history-review/{a.id}',dict(action='correct',merge_ids=[b.id],note='same physical batch confirmed',
                  cycle_start_time=self.at.isoformat(),cooking_end_time=(self.at+timedelta(minutes=10)).isoformat(),cycle_end_time=(self.at+timedelta(minutes=15)).isoformat()))
        self.assertEqual(code,200,data)
        self.assertEqual({t.cycle_id for t in self.db.query(TaskLog)}, {a.id})
        self.assertFalse(b.is_valid)
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_finished_cycle_replays_later_start(self):
        observe_timer(self.db,1,1,self.at+timedelta(minutes=5,seconds=10))
        state=self.db.get(CycleRecovery,1)
        code,data=self.request('POST','/cycle-recovery/1',dict(revision=state.revision,action='finished',note='ended during outage',
                    cooking_end_time=(self.at+timedelta(minutes=3)).isoformat(),cycle_end_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertEqual(code,200,data)
        self.assertEqual(self.cycle.total_duration,4)
        self.assertEqual(self.db.query(CycleLog).count(),2)

    def test_finished_reference_high_requires_active_cycle_decision(self):
        state=self.db.get(CycleRecovery,1);state.reference_start=1;self.db.commit()
        code,_=self.request('POST','/cycle-recovery/1',dict(revision=state.revision,action='finished',note='x',
                cooking_end_time=(self.at+timedelta(minutes=3)).isoformat(),cycle_end_time=(self.at+timedelta(minutes=4)).isoformat()))
        self.assertEqual(code,409)
        self.assertTrue(state.pending)


if __name__ == '__main__': unittest.main()
