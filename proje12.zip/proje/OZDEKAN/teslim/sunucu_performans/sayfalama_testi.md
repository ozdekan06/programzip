# Son 10 cycle doğrulaması

- Backend: 500 cycle / 2000 ürün; tüm testler test_sonuclari.json içinde.
- Safari: #500–#491 ilk 10 kayıt; Daha fazla yükle ile #490–#481 eklenerek 20 kayıt.
- Vardiya filtresi: fixture dışındaki gün için 0 sonuç; Temizle ile yeniden #500–#491.
- İlk yükleme ölçümü: 413 ms (300 ms sessizlik kontrolü dahil), 10 kart ve 414 DOM öğesi.
- İzole ortam, cihaz görevleri kapalı. Gerçek üretim bilgisayarında süre değişebilir.
