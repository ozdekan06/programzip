"""python3 teslim/sunucu_performans/dogrula.py (proje kökünden). Donanım başlatmaz."""
import ast
import json
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from time import perf_counter
from sqlalchemy import create_engine, event, text, func, and_
from sqlalchemy.orm import Session, sessionmaker, joinedload
from fastapi import Depends, HTTPException
from models import Base, Machine, Person, Order, Product, TaskLog, CycleLog

ROOT = Path(__file__).resolve().parent
ORIGINAL = Path('/Users/halilacikgoz/.codex/attachments/92ffd9e9-2526-4335-8de8-1355cca4f87b/Pasted text.txt')


def functions(path):
    tree = ast.parse(path.read_text())
    selected = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in {
            '_order_counts', '_order_counts_many', 'get_orders', 'get_order_status', 'get_cycle_logs', '_cycle_log_rows', 'get_product_entry_cycles'
        }:
            node.decorator_list = []
            selected.append(node)
    namespace = dict(Session=Session, Depends=Depends, get_db=lambda: None,
                     Machine=Machine, Person=Person, Order=Order, Product=Product,
                     TaskLog=TaskLog, CycleLog=CycleLog, func=func, and_=and_, joinedload=joinedload, datetime=datetime, Optional=__import__("typing").Optional, json=json, HTTPException=HTTPException, or_=__import__("sqlalchemy").or_)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


def run():
    old, new = functions(ORIGINAL), functions(ROOT / 'main.py')
    with tempfile.TemporaryDirectory() as directory:
        engine = create_engine('sqlite:///' + directory + '/test.db')
        Base.metadata.create_all(engine)
        with engine.begin() as conn:
            for statement in [
                'CREATE INDEX IF NOT EXISTS ix_perf_tasks_product_latest ON task_logs (product_id, timestamp, id)',
                'CREATE INDEX IF NOT EXISTS ix_perf_tasks_cycle_product ON task_logs (cycle_id, product_id)',
                'CREATE INDEX IF NOT EXISTS ix_perf_product_order_reverted ON product (ordernumber, is_reverted)',
                'CREATE INDEX IF NOT EXISTS ix_perf_cycles_time ON cycle_logs (is_valid, coalesce(cycle_start_time, timestamp), id)',
                'CREATE INDEX IF NOT EXISTS ix_perf_cycles_machine_time ON cycle_logs (machine_id, is_valid, coalesce(cycle_start_time, timestamp), id)'
            ]:
                conn.execute(text(statement))
                conn.execute(text(statement))
        factory = sessionmaker(bind=engine)
        at = datetime(2026, 1, 1)
        with factory() as db:
            db.add_all([Machine(id=1, name='TEST', sensor_ids=[], sensor_count=0), Person(id=1, name='Test', surname='Operator')])
            for i in range(10):
                db.add(Order(ordernumber=f'O{i}', name='P', productsize='1', producttype='T', moldnumber='M', quantity=1000, person_id=1))
            db.add(Order(ordernumber='EMPTY', name='P', productsize='1', producttype='T', moldnumber='M', quantity=10))
            for i in range(1, 501):
                db.add(CycleLog(id=i, machine_id=1, cycle_start_time=at+timedelta(minutes=15*i),
                    cycle_end_time=at+timedelta(minutes=15*(i+1)), is_valid=i != 500))
            db.flush()
            for i in range(1, 2001):
                db.add(Product(id=i, name='P', serialnumber=f'O{i%10}/{i}', ordernumber=f'O{i%10}',
                    productsize='1', producttype='T', moldnumber='M', is_reverted=i%17==0))
            db.flush()
            for i in range(1, 2001):
                if i%23==0: continue  # no task: contributes to produced, not accepted
                cycle = (i%250)+1
                db.add(TaskLog(machine_id=1, person_id=1, product_id=i, cycle_id=cycle, timestamp=at,
                    task_name='first', status='SUCCESS'))
                db.add(TaskLog(machine_id=1, person_id=1, product_id=i, cycle_id=cycle, timestamp=at,
                    task_name='latest', status=['SUCCESS','FAILED','CONDITIONAL','REVERTED'][i%4]))
                # Higher ID but older timestamp must not override latest.
                db.add(TaskLog(machine_id=1, person_id=1, product_id=i, cycle_id=cycle,
                    timestamp=at-timedelta(days=1), task_name='older', status='FAILED'))
            db.commit()
        count = [0]
        def sql_count(*args): count[0] += 1
        event.listen(engine, 'before_cursor_execute', sql_count)
        results = {}
        for name in ['get_orders','get_order_status']:
            outputs = []
            for label, module in [('before',old),('after',new)]:
                with factory() as db:
                    count[0] = 0
                    start = perf_counter()
                    output = module[name](db=db, **({'ordernumber':'O1'} if name=='get_order_status' else {}))
                    results[name+'_'+label] = {'ms':round((perf_counter()-start)*1000,2), 'sql':count[0]}
                    outputs.append(output)
            assert outputs[0] == outputs[1], name
        with factory() as db:
            for order in ['O0','O1','EMPTY','MISSING']:
                assert old['_order_counts'](db,order) == new['_order_counts'](db,order)
        with factory() as db:
            original_cycles = old['get_cycle_logs'](db=db)
        with factory() as db:
            count[0] = 0
            assert new['get_cycle_logs'](db=db) == original_cycles
            results['cycle_logs_after_sql'] = count[0]
        with factory() as db:
            linked = {row[0] for row in db.query(TaskLog.cycle_id).join(Product, TaskLog.product_id==Product.id).filter(Product.is_reverted.is_(False)).all()}
            expected = {c['id'] for c in original_cycles} - linked
            count[0] = 0
            pending = new['get_cycle_logs'](db=db,pending_only=True)
            assert {c['id'] for c in pending} == expected
            results['pending_cycles'] = {'count':len(pending), 'sql':count[0]}
            # Reverted-only cycle becomes available; an invalid cycle remains hidden.
            db.add(Product(id=2001,name='R',serialnumber='R/1',productsize='1',producttype='T',moldnumber='M',is_reverted=True))
            db.flush()
            db.add(TaskLog(machine_id=1,person_id=1,product_id=2001,cycle_id=499,task_name='reverted',status='REVERTED'))
            db.commit()
            assert 499 in {c['id'] for c in new['get_cycle_logs'](db=db,pending_only=True)}
            assert 500 not in {c['id'] for c in new['get_cycle_logs'](db=db,pending_only=True)}
        with factory() as db:
            get_page = new['get_product_entry_cycles']
            page = get_page(db=db)
            assert len(page['items']) == 10 and page['has_more']
            assert [c['id'] for c in page['items']] == list(range(499, 489, -1))
            cursor = page['next_cursor']
            # Consuming an earlier row must not skip the next page's first row.
            db.add(Product(id=2002,name='N',serialnumber='N/1',productsize='1',producttype='T',moldnumber='M'))
            db.flush()
            db.add(TaskLog(machine_id=1,person_id=1,product_id=2002,cycle_id=499,task_name='new',status='SUCCESS'))
            db.commit()
            second = get_page(db=db,cursor=cursor)
            assert [c['id'] for c in second['items']] == list(range(489,479,-1))
            # Filter across the full database, beyond the initial latest page.
            filtered = get_page(db=db,start=(at+timedelta(minutes=15*300)).isoformat(),end=(at+timedelta(minutes=15*320)).isoformat())
            assert [c['id'] for c in filtered['items']] == list(range(320,310,-1))
            ascending = get_page(db=db,direction='asc')
            assert [c['id'] for c in ascending['items']] == list(range(251,261))
            all_ids = []; cursor = None
            while True:
                page = get_page(db=db,cursor=cursor)
                assert len(page['items']) <= 10
                all_ids.extend(c['id'] for c in page['items'])
                if not page['has_more']: break
                cursor = page['next_cursor']
            assert len(all_ids) == len(set(all_ids)) == 248
            db.add(Machine(id=2,name='TEST',sensor_ids=[99],sensor_count=1))
            db.add_all([CycleLog(id=501,machine_id=2,cycle_start_time=at,timestamp=at),
                        CycleLog(id=502,machine_id=2,cycle_start_time=at,timestamp=at),
                        CycleLog(id=503,machine_id=2,cycle_start_time=None,timestamp=at)])
            db.commit()
            assert [c['id'] for c in get_page(db=db,machine_id=2)['items']] == [503,502,501]
            assert get_page(db=db,machine_id=2,show_running=False)['items'] == []
            assert get_page(db=db,machine_id=999)['items'] == []
            for kwargs in [dict(direction='bad'),dict(cursor='bad'),dict(start='bad'),dict(start='2026-02-01',end='2026-01-01')]:
                try: get_page(db=db,**kwargs)
                except HTTPException as exc: assert exc.status_code == 400
                else: raise AssertionError(kwargs)
            results['pagination'] = 'PASS: newest 10, ascending, next page after conversion, all pages without skips/duplicates, full-history date filter, machine IDs with identical names, running cycles, equal/null times, bad input'
        # Only the intended existing functions/imports/startup index block changed.
        before_tree, after_tree = ast.parse(ORIGINAL.read_text()), ast.parse((ROOT/'main.py').read_text())
        changed = {'_order_counts','get_orders','get_cycle_logs','startup_event'}
        added = {'_order_counts_many', '_cycle_log_rows', 'get_product_entry_cycles'}
        def unchanged(tree):
            return [ast.dump(n) for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))
                    and not (isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in changed|added)]
        assert unchanged(before_tree) == unchanged(after_tree)
        results['checks'] = 'PASS: exact order/status parity, latest timestamp + ID, reverted/no-task/empty orders, pending cycles, default response parity, idempotent indexes, unrelated functions unchanged'
        (ROOT/'test_sonuclari.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(results,indent=2))
        engine.dispose()

if __name__ == '__main__': run()
