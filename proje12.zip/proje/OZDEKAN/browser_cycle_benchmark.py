"""Real-browser test server with disposable SQLite and timing-only instrumentation."""
import benchmark_cycle_conversion as fixture
import json
from datetime import datetime, timedelta
from pathlib import Path
from fastapi import Request
from fastapi.responses import HTMLResponse, RedirectResponse
from database import SessionLocal
from models import Machine, Person, Order, CycleLog, TimerLog, Product, TaskLog
from main import app

REPORT = Path('performance_results/browser_cycle_500_after.jsonl')
db = SessionLocal()
db.add_all([Machine(id=1, name='TEST MAKINESI', sensor_ids=[], sensor_count=0),
            Person(id=1, name='Test', surname='Operator'),
            Order(name='Test urunu', productsize='1', producttype='T', moldnumber='M',
                  ordernumber='BENCH', quantity=10000, serial_start=1)])
for i in range(500):
    start = datetime(2026, 1, 1)+timedelta(minutes=15*i)
    db.add(CycleLog(id=i+1, machine_id=1, cycle_start_time=start,
                   cycle_end_time=start+timedelta(minutes=15), order_number='BENCH',
                   person_id=1, mold_count=1, total_duration=15, ideal_total_time=15))
    for minute in range(15):
        db.add(TimerLog(machine_id=1, sensor_id=1, timestamp=start+timedelta(minutes=minute),
                        value_T1=10, value_T2=5))
db.commit()
db.close()

INSTRUMENT = r'''<script>
(() => {
 const originalFetch=window.fetch.bind(window);
 let active=null, serial=0, pending=0, timer;
 function finish(){
   if(!active || pending) return;
   const r={...active, elapsed_ms:Math.round(performance.now()-active.start),
     cards:document.querySelectorAll('.cycle-card').length,
     nodes:document.querySelectorAll('*').length};
   delete r.start; active=null;
   document.getElementById('bench-result').textContent=JSON.stringify(r);
   originalFetch('/bench/report',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(r)});
 }
 window.fetch=async (...args)=>{
   const url=String(args[0]), watched=active && !url.includes('cycle-recovery') && !url.includes('cycle-history');
   const run=active;
   if(watched) {pending++;run.requests++;}
   const start=performance.now();
   try {const res=await originalFetch(...args); if(watched) await res.clone().arrayBuffer(); return res;}
   finally {if(watched){pending--;run.request_ms+=performance.now()-start;
      if(url.includes('order-status')) run.order_status_requests++;
      clearTimeout(timer);if(!pending) timer=setTimeout(finish,300);}}
 };
 window.addEventListener('error', e=>originalFetch('/bench/report',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({error:e.message})}));
 document.addEventListener('DOMContentLoaded',()=>{
   const box=document.createElement('pre');box.id='bench-result';box.style='position:fixed;bottom:0;left:0;right:0;z-index:99999;background:#fff4b8;white-space:pre-wrap;font-size:12px;padding:8px;max-height:90px;overflow:auto';document.body.append(box);
 });
 const original=window.fetchCycles;
 const originalSave=window.saveAllProducts;
 const originalAlert=window.alert.bind(window);
 window.alert=(...args)=>{const start=performance.now();try{return originalAlert(...args);}finally{if(active)active.start+=performance.now()-start;}};
 window.saveAllProducts=async function(){
   active={id:++serial,kind:'save',start:performance.now(),requests:0,request_ms:0,order_status_requests:0};
   return originalSave.apply(this,arguments);
 };
 window.fetchCycles=async function(){
   active={id:++serial,kind:serial===1?'initial_load':'refresh',start:performance.now(),requests:0,request_ms:0,order_status_requests:0};
   return original.apply(this,arguments);
 };
})();
</script>'''

@app.get('/bench/urun')
def page():
    source=Path('static/urun.html').read_text()
    return HTMLResponse(source.replace('</body>', INSTRUMENT+'</body>'))

@app.post('/bench/report')
async def report(request: Request):
    record=await request.json()
    with REPORT.open('a') as stream: stream.write(json.dumps(record)+'\n')
    print('BROWSER',json.dumps(record),flush=True)
    return {'ok':True}

@app.get('/bench/scenario/{converted}')
def scenario(converted: int):
    assert converted in (0,250,499)
    db=SessionLocal()
    db.query(TaskLog).delete();db.query(Product).delete()
    for i in range(1,converted+1):
        p=Product(name='Test urunu',serialnumber=f'BENCH/{i}',productsize='1',producttype='T',moldnumber='M',ordernumber='BENCH')
        db.add(p);db.flush()
        db.add(TaskLog(machine_id=1,person_id=1,product_id=p.id,cycle_id=i,task_name='Test',status='SUCCESS'))
    db.commit();db.close()
    return RedirectResponse('/bench/urun')

if __name__=='__main__':
    import uvicorn
    # No startup hooks: no serial ports, polling, or production migrations.
    uvicorn.run(app,host='127.0.0.1',port=8765,lifespan='off',access_log=False)
