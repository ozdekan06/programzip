from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, JSON, ForeignKey, Float, Boolean, UniqueConstraint, Index
from datetime import datetime
from sqlalchemy.orm import relationship

Base = declarative_base()


class UARTLog(Base):
    __tablename__ = "uart_logs"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.now)
    direction = Column(String)
    data = Column(String)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)


class Person(Base):
    __tablename__ = "person"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    surname = Column(String, nullable=False)
    age = Column(Integer, nullable=True)
    

class Product(Base):
    __tablename__ = "product"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    serialnumber = Column(String, nullable=False, unique=True)
    productsize = Column(String, nullable=False)
    producttype = Column(String, nullable=False)
    moldnumber = Column(String, nullable=False)
    lot_number = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.now)

    # Son kalite durumu değişikliğinin izlenebilir özeti.
    status_change = Column(String, nullable=True)
    status_change_reason = Column(String, nullable=True)
    status_changed_at = Column(DateTime, nullable=True)
    is_reverted = Column(Boolean, default=False, nullable=False)
    reverted_at = Column(DateTime, nullable=True)
    revert_reason = Column(String, nullable=True)
    
    ordernumber = Column(String, ForeignKey("orders.ordernumber"), nullable=True)


class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False)
    productsize = Column(String, nullable=False)
    producttype = Column(String, nullable=False)
    moldnumber = Column(String, nullable=False)
    ordernumber = Column(String, nullable=False, unique=True)
    quantity = Column(Integer, nullable=False)
    unit = Column(String, nullable=True)
    volume_per_piece = Column(Float, nullable=True)
    is_manually_completed = Column(Boolean, default=False, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    completion_note = Column(String, nullable=True)
    
    # Yeni alanlar
    serial_start = Column(Integer, nullable=True)  # Tam seri numarasındaki son sıra değeri
    lot_number = Column(String, nullable=True)     # Lot değeri
    person_id = Column(Integer, ForeignKey("person.id"), nullable=True)  # Personel
    
    timestamp = Column(DateTime, default=datetime.now)

    product = relationship("Product")
    person = relationship("Person")


class Machine(Base):
    __tablename__ = "machines"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    slave_id = Column(Integer, unique=True)
    sensor_ids = Column(JSON, nullable=False, unique=True)
    # Sensör ID'si -> kullanıcı açıklaması (örn. {"12": "Fırın girişi"})
    sensor_descriptions = Column(JSON, nullable=False, default=dict)
    sensor_layout = Column(JSON, nullable=True)  # None: use the default upper/lower layout
    sensor_count = Column(Integer, nullable=False)
    image = Column(String, default="C/....image.png")
    timer_id = Column(Integer, unique=True)
    # Whether this machine is active and should be polled by background tasks
    is_active = Column(Boolean, default=True, nullable=False)
    sensor_timeout_minutes = Column(Integer, default=5, nullable=False)
    sensor_retry_wait_minutes = Column(Integer, default=5, nullable=False)
    sensor_retry_window_minutes = Column(Integer, default=1, nullable=False)
    sensor_suspended = Column(JSON, default=dict, nullable=False)
    active_order_number = Column(String, nullable=True)
    active_person_id = Column(Integer, ForeignKey("person.id"), nullable=True)
    active_mold_count = Column(Integer, nullable=True)
    active_lot_number = Column(String, nullable=True)



class SensorLog(Base):
    __tablename__ = "sensor_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=False)  # Hangi sensör
    timestamp = Column(DateTime, default=datetime.now)
    value = Column(Integer, nullable=False)  # Ölçülen sıcaklık (veya diğer parametre)
    value_set = Column(Integer, nullable=False)  # Set değeri
    value_histerezis = Column(Integer, nullable=False)  # Histerezis değeri
    
    machine = relationship("Machine")


class TimerLog(Base):
    __tablename__ = "timer_logs"
    __table_args__ = (Index("ix_timer_logs_machine_time", "machine_id", "timestamp"),)
    id = Column(Integer,primary_key=True,index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=False)  # Hangi sensör
    timestamp = Column(DateTime, default=datetime.now)

    value_T1 = Column(Float, nullable=True)
    value_T1A = Column(Float, nullable=True)
    value_T2 =  Column(Float, nullable=True) 
    value_T2A =  Column(Float, nullable=True) 

    value_out = Column(Integer, nullable=True)  
    value_state = Column(String, nullable=True)

    machine = relationship("Machine")



class AlarmLog(Base):
    __tablename__ = "alarm_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=True)  # İlgili sensör
    alarm_type = Column(String, nullable=False)  # 'HIGH_TEMP', 'LOW_TEMP' gibi
    start_time = Column(DateTime, default=datetime.now,nullable=False)  # Alarm başladığında doldurulur
    end_time = Column(DateTime,nullable=True)  # Alarm bitince doldurulur
    details = Column(String, nullable=True)  # Açıklama (örn. "Sıcaklık 250°C üzerine çıktı")

    machine = relationship("Machine")



class CycleLog(Base):
    __tablename__ = "cycle_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.now, nullable=False)  # Kayıt zamanı
    
    # Cycle zamanları
    cycle_start_time = Column(DateTime, nullable=True)  # Cycle başlangıç (ilk Start 1)
    cycle_end_time = Column(DateTime, nullable=True)    # Cycle bitiş (tekrar Start 1)
    cooking_start_time = Column(DateTime, nullable=True) # Pişirme başlangıç zamanını persist etmek için
    
    # Gerçek süreler (dakika)
    cooking_duration = Column(Float, nullable=True)     # Gerçek pişirme süresi
    renewal_duration = Column(Float, nullable=True)     # Gerçek yenileme süresi
    total_duration = Column(Float, nullable=True)       # Toplam cycle süresi
    
    # İdeal süreler (dakika)
    ideal_cooking_time = Column(Float, nullable=True)   # T1 - İdeal pişirme
    ideal_renewal_time = Column(Float, nullable=True)   # T2 - İdeal yenileme
    ideal_total_time = Column(Float, nullable=True)     # T1 + T2
    
    # Gecikmeler (dakika, + gecikme / - erken)
    cooking_delay = Column(Float, nullable=True)        # Pişirme gecikmesi
    renewal_delay = Column(Float, nullable=True)        # Yenileme gecikmesi
    total_delay = Column(Float, nullable=True)          # Toplam gecikme
    is_valid = Column(Boolean, default=True, nullable=False)
    invalid_reason = Column(String, nullable=True)
    invalidated_at = Column(DateTime, nullable=True)
    closure_type = Column(String, default="automatic", nullable=False)
    time_source = Column(String, default="observed", nullable=False)
    review_required = Column(Boolean, default=False, nullable=False)
    recovery_note = Column(String, nullable=True)
    order_number = Column(String, nullable=True)
    person_id = Column(Integer, nullable=True)
    mold_count = Column(Integer, nullable=True)
    lot_number = Column(String, nullable=True)

    machine = relationship("Machine")


class QualityReason(Base):
    __tablename__ = "quality_reasons"
    __table_args__ = (UniqueConstraint("status", "name", name="uq_quality_reason_status_name"),)
    id = Column(Integer, primary_key=True)
    status = Column(String, nullable=False)  # SUCCESS / FAILED / CONDITIONAL
    name = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)


class TaskLog(Base):
    __tablename__ = "task_logs"
    __table_args__ = (Index("ix_task_logs_product_latest", "product_id", "timestamp", "id"),)
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    person_id = Column(Integer, ForeignKey("person.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("product.id"), nullable=False)
    cycle_id = Column(Integer, ForeignKey("cycle_logs.id"), nullable=True)  # İlgili döngü
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    task_name = Column(String, nullable=False)
    status = Column(String, nullable=False)  # 'SUCCESS', 'FAILED', 'CANCELLED' gibi
    
    quality_reason_id = Column(Integer, ForeignKey("quality_reasons.id"), nullable=True, index=True)
    quality_reasons = Column(JSON, nullable=True)  # Neden kimlikleri ve kayıt anındaki adları
    quality_reason_name = Column(String, nullable=True)  # Kayıt anındaki neden adı
    details = Column(String, nullable=True)  # Açıklama veya hata mesajı

    machine = relationship("Machine")   


class CycleEvent(Base):
    __tablename__ = "cycle_events"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    event_type = Column(String, nullable=False)  # 'START', 'STOP', or durable 'GAP' boundary
    details = Column(JSON, nullable=True)
    processed = Column(Integer, default=0, nullable=False)  # 0 = unprocessed, 1 = processed

    machine = relationship("Machine")


class CycleRecovery(Base):
    __tablename__ = "cycle_recoveries"
    machine_id = Column(Integer, ForeignKey("machines.id"), primary_key=True)
    cycle_id = Column(Integer, ForeignKey("cycle_logs.id"), nullable=True)
    pending = Column(Boolean, default=False, nullable=False)
    opened_at = Column(DateTime, nullable=False)
    reference_at = Column(DateTime, nullable=True)
    reference_start = Column(Integer, nullable=True)
    last_start = Column(Integer, nullable=True)
    last_seen_at = Column(DateTime, nullable=True)
    last_event_at = Column(DateTime, nullable=True)
    clean_shutdown = Column(Boolean, default=False, nullable=False)
    revision = Column(Integer, default=1, nullable=False)
    decision = Column(JSON, nullable=True)


class CycleAudit(Base):
    __tablename__ = "cycle_audits"
    id = Column(Integer, primary_key=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    action = Column(String, nullable=False)
    details = Column(JSON, nullable=False)
