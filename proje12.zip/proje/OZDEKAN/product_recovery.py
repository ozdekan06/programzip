"""Active product links and non-destructive product reversal."""
from datetime import datetime
from models import Product, TaskLog, Order, CycleAudit


def active_cycle_products(db, cycle_id):
    # Historical tasks are retained. Only the product's current active flag blocks.
    return db.query(Product).join(TaskLog, TaskLog.product_id == Product.id).filter(
        TaskLog.cycle_id == cycle_id, Product.is_reverted.is_(False)
    ).distinct().order_by(Product.id).all()


class ProductReversalRequired(ValueError):
    def __init__(self, cycle_id, products):
        url = f"/static/raporsayfasi.html?cycle_id={cycle_id}&return_cycle_id={cycle_id}"
        serials = ', '.join(str(p.serialnumber) for p in products[:5])
        extra = '…' if len(products) > 5 else ''
        message = (f"Cycle #{cycle_id}, {len(products)} aktif ürüne bağlı ({serials}{extra}). "
                   "Bu cycle hatalıysa önce ‘Bağlı ürünleri göster’ düğmesinden ürünleri açıp "
                   "‘Ürünü cycle’a geri al’ işlemini yapın. Sonra cycle’ı geçersizleştirmeyi tekrar deneyin. "
                   "Yalnızca tarih yanlışsa ürünleri geri almadan zamanları düzeltin; "
                   "kayıtlar aynı üretimse cycle’ları birleştirin.")
        super().__init__(message)
        self.detail = {"code": "ACTIVE_CYCLE_PRODUCTS", "message": message, "cycle_id": cycle_id,
                       "products_url": url,
                       "products": [{"id": p.id, "serial_number": p.serialnumber} for p in products]}


def require_no_active_cycle_products(db, cycle_id):
    products = active_cycle_products(db, cycle_id)
    if products:
        raise ProductReversalRequired(cycle_id, products)


def reverse_product(db, product, reason):
    """Change active state, retain task history, and reopen completed orders."""
    if product.is_reverted:
        return None
    latest = db.query(TaskLog).filter(TaskLog.product_id == product.id).order_by(TaskLog.timestamp.desc(), TaskLog.id.desc()).first()
    linked = db.query(TaskLog).filter(TaskLog.product_id == product.id, TaskLog.cycle_id.isnot(None)).order_by(TaskLog.timestamp.desc(), TaskLog.id.desc()).first()
    cycle_id = linked.cycle_id if linked else None
    product.is_reverted, product.reverted_at, product.revert_reason = True, datetime.now(), reason
    if latest:
        db.add(TaskLog(machine_id=latest.machine_id, person_id=latest.person_id, product_id=product.id,
                       cycle_id=cycle_id, timestamp=datetime.now(), task_name="Ürün kaydını geri alma",
                       status="REVERTED", details=reason))
    order = db.query(Order).filter(Order.ordernumber == product.ordernumber).first() if product.ordernumber else None
    if order and order.is_manually_completed:
        order.is_manually_completed, order.completed_at = False, None
        order.completion_note = "Ürün geri alındığı için sipariş yeniden açıldı."
    if linked:
        db.add(CycleAudit(machine_id=linked.machine_id, action="product_reverted",
                          details={"product_id": product.id, "serial_number": product.serialnumber,
                                   "cycle_id": cycle_id, "reason": reason}))
    return cycle_id
