"""RS-485/Modbus RTU hattının tek sahibi.

Uygulamanın hiçbir bölümü istemciyi doğrudan kullanmamalı; bütün Modbus
işlemleri ``execute`` üzerinden seri hale getirilir. RS-485 aynı anda yalnızca
bir isteği taşıyabildiği için bu hem veri doğruluğunu hem de zamanlamayı korur.
"""

import asyncio
import json
import logging
import os
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any

from pymodbus import FramerType
from pymodbus.client import AsyncModbusSerialClient, AsyncModbusTcpClient


logger = logging.getLogger(__name__)


def _load_config() -> dict:
    """Bağlantı ayarlarını başlatma yönteminden bağımsız olarak yükle.

    launcher.py ortam değişkenlerini ayarlar; uvicorn main:app veya doğrudan
    import edildiğinde ise aynı config.json dosyasını burada okuruz. Ortam
    değişkenleri her zaman dosyadaki ayarlardan önceliklidir.
    """
    explicit_path = os.getenv("OZDEKAN_CONFIG")
    if explicit_path:
        candidates = [Path(explicit_path)]
    else:
        app_dir = (
            Path(sys.executable).resolve().parent
            if getattr(sys, "frozen", False)
            else Path(__file__).resolve().parent
        )
        candidates = [app_dir / "config.json"]

    for path in candidates:
        try:
            if path.is_file():
                data = json.loads(path.read_text(encoding="utf-8"))
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError) as exc:
            logger.warning("Config dosyası okunamadı: %s (%s)", path, exc)
    return {}


_CONFIG = _load_config()


def _setting(env_name: str, config_name: str, default):
    return os.getenv(env_name, _CONFIG.get(config_name, default))

modbus_client = None
connection_lock = asyncio.Lock()
bus_lock = asyncio.Lock()

# Port ayarları deployment sırasında ortam değişkenleriyle değiştirilebilir.
SERIAL_PORT = str(_setting("MODBUS_PORT", "modbus_port", "COM3"))
MODBUS_MODE = str(_setting("MODBUS_MODE", "modbus_mode", "serial")).strip().lower()
SIMULATOR_HOST = str(_setting("MODBUS_SIMULATOR_HOST", "modbus_simulator_host", "127.0.0.1"))
SIMULATOR_PORT = int(_setting("MODBUS_SIMULATOR_PORT", "modbus_simulator_port", 1502))
BAUDRATE = int(_setting("MODBUS_BAUDRATE", "modbus_baudrate", 9600))
PARITY = str(_setting("MODBUS_PARITY", "modbus_parity", "N"))
STOPBITS = int(_setting("MODBUS_STOPBITS", "modbus_stopbits", 1))
BYTESIZE = int(_setting("MODBUS_BYTESIZE", "modbus_bytesize", 8))
TIMEOUT = float(_setting("MODBUS_TIMEOUT", "modbus_timeout", 1.0))
RETRIES = int(_setting("MODBUS_RETRIES", "modbus_retries", 1))

metrics = Counter()


async def connection() -> bool:
    """Seri portu idempotent biçimde aç."""
    global modbus_client
    async with connection_lock:
        if modbus_client and modbus_client.connected:
            return True

        if modbus_client:
            modbus_client.close()

        if MODBUS_MODE in {"simulator", "tcp"}:
            modbus_client = AsyncModbusTcpClient(
                SIMULATOR_HOST,
                port=SIMULATOR_PORT,
                timeout=TIMEOUT,
                retries=RETRIES,
                reconnect_delay=0.5,
                reconnect_delay_max=5,
            )
        else:
            modbus_client = AsyncModbusSerialClient(
                port=SERIAL_PORT,
                baudrate=BAUDRATE,
                parity=PARITY,
                stopbits=STOPBITS,
                timeout=TIMEOUT,
                retries=RETRIES,
                reconnect_delay=0.5,
                reconnect_delay_max=5,
                bytesize=BYTESIZE,
                framer=FramerType.RTU,
            )
        connected = await modbus_client.connect()
        metrics["connect_ok" if connected else "connect_error"] += 1
        endpoint = f"{SIMULATOR_HOST}:{SIMULATOR_PORT}" if MODBUS_MODE in {"simulator", "tcp"} else SERIAL_PORT
        logger.info("Modbus bağlantısı", extra={"connected": bool(connected), "mode": MODBUS_MODE, "port": endpoint})
        return bool(connected)


async def ensure_connection() -> bool:
    if modbus_client and modbus_client.connected:
        return True
    return await connection()


async def execute(method_name: str, *, slave_id: int, **kwargs: Any):
    """Bir Modbus işlemini hat üzerinde atomik olarak çalıştır.

    Bağlantı kontrolü de bus kilidinin içindedir; böylece başka bir coroutine
    devam eden istek sırasında istemciyi kapatıp yeniden oluşturamaz.
    """
    async with bus_lock:
        if not await ensure_connection():
            endpoint = f"{SIMULATOR_HOST}:{SIMULATOR_PORT}" if MODBUS_MODE in {"simulator", "tcp"} else SERIAL_PORT
            raise ConnectionError(f"Modbus bağlantısı açılamadı: {endpoint}")

        started = time.monotonic()
        try:
            method = getattr(modbus_client, method_name)
            result = await method(device_id=slave_id, **kwargs)
            elapsed_ms = (time.monotonic() - started) * 1000
            metrics["requests"] += 1
            metrics["latency_ms_total"] += int(elapsed_ms)
            metric_prefix = f"slave_{slave_id}.{method_name}"
            metrics[f"{metric_prefix}.requests"] += 1
            metrics[f"{metric_prefix}.latency_ms_total"] += int(elapsed_ms)
            metrics[f"{metric_prefix}.last_latency_ms"] = int(elapsed_ms)
            metrics[f"{metric_prefix}.max_latency_ms"] = max(
                metrics[f"{metric_prefix}.max_latency_ms"], int(elapsed_ms)
            )
            if elapsed_ms >= TIMEOUT * 1000:
                metrics[f"{metric_prefix}.retried_or_slow"] += 1
            if result.isError():
                metrics["protocol_errors"] += 1
                metrics[f"{metric_prefix}.errors"] += 1
            else:
                metrics["success"] += 1
            return result, elapsed_ms
        except Exception:
            metrics["transport_errors"] += 1
            # Bir slave'in timeout/bozuk cevabı sağlam seri portun kapanmasını
            # gerektirmez. Yalnızca transport gerçekten düşmüşse kapat; aksi
            # halde bütün cihazlar gereksiz reconnect cezası öder.
            if modbus_client and not modbus_client.connected:
                modbus_client.close()
            raise


async def close() -> None:
    """Devam eden Modbus işlemi bittikten sonra portu güvenle kapat."""
    global modbus_client
    async with bus_lock:
        if modbus_client:
            modbus_client.close()
            modbus_client = None


def get_metrics() -> dict:
    snapshot = dict(metrics)
    requests = snapshot.get("requests", 0)
    snapshot["average_latency_ms"] = (
        round(snapshot.get("latency_ms_total", 0) / requests, 2) if requests else 0.0
    )
    snapshot["connected"] = bool(modbus_client and modbus_client.connected)
    snapshot["mode"] = MODBUS_MODE
    snapshot["port"] = f"{SIMULATOR_HOST}:{SIMULATOR_PORT}" if MODBUS_MODE in {"simulator", "tcp"} else SERIAL_PORT
    return snapshot


def get_request_metrics() -> dict:
    """İstek türü ve slave bazında okunabilir performans özeti."""
    result = {}
    prefixes = {
        key.rsplit(".", 1)[0]
        for key in metrics
        if key.startswith("slave_") and "." in key
    }
    for prefix in sorted(prefixes):
        count = metrics[f"{prefix}.requests"]
        result[prefix] = {
            "requests": count,
            "average_latency_ms": round(
                metrics[f"{prefix}.latency_ms_total"] / count, 2
            ) if count else 0.0,
            "last_latency_ms": metrics[f"{prefix}.last_latency_ms"],
            "max_latency_ms": metrics[f"{prefix}.max_latency_ms"],
            "retried_or_slow": metrics[f"{prefix}.retried_or_slow"],
            "errors": metrics[f"{prefix}.errors"],
        }
    return result
