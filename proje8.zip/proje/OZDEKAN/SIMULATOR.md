# OZDEKAN cihaz simülatörü

Simülatör, gerçek RS485 cihazlarının register yapılarını ayrı bir Modbus TCP
süreci olarak taklit eder. Sıcaklık, set değeri, alarm/histerezis değerleri ile
timer süreleri arayüzden değiştirilebilir; timer başlatılabilir, durdurulabilir
ve sıfırlanabilir.

## Çalıştırma

1. Simülatörü başlatın:

   ```bash
   python3 modbus_simulator.py
   ```

2. Tarayıcıda `http://127.0.0.1:8765` adresini açın.

3. Ana uygulamanın `config.json` dosyasında aşağıdaki alanları ayarlayın:

   ```json
   {
     "modbus_mode": "simulator",
     "modbus_simulator_host": "127.0.0.1",
     "modbus_simulator_port": 1502
   }
   ```

4. Ana uygulamayı normal şekilde başlatın. Makine ayarlarındaki sensör ve timer
   ID'leri, simülatör arayüzündeki slave ID'leriyle aynı olmalıdır.

Gerçek cihazlara geri dönmek için yalnızca `modbus_mode` değerini `serial`
yapın. Seri port ayarları değişmeden korunur.

Simülatör başlangıçta `logs.db` içindeki aktif makineleri okuyarak gereken
sensör ve timer slave'lerini otomatik oluşturur. Veritabanında makine yoksa
slave 1 sıcaklık kontrolcüsü ve slave 2 timer olarak açılır. Arayüzden 1–247
arasında yeni slave cihazları da eklenebilir veya silinebilir.

Farklı portlarla çalıştırmak için:

```bash
python3 modbus_simulator.py --modbus-port 15020 --ui-port 18765
```
