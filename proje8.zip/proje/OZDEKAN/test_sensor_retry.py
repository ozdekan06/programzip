from datetime import datetime

from backgraound import _valid_recovery_read


def fresh_sensor_data(value=150, quality="GOOD"):
    timestamp = datetime.now().astimezone().isoformat()
    return {
        "quality": quality,
        "input_registers": [value],
        "holding_registers": [160],
        "input_read_at": timestamp,
        "holding_read_at": timestamp,
    }


def test_recovery_accepts_fresh_plausible_temperature():
    assert _valid_recovery_read(fresh_sensor_data()) is True


def test_recovery_rejects_device_error_temperature():
    assert _valid_recovery_read(fresh_sensor_data(32767)) is False


def test_recovery_rejects_incomplete_response():
    data = fresh_sensor_data()
    data["holding_registers"] = []
    assert _valid_recovery_read(data) is False
