from datetime import datetime

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from main import create_orders_bulk, invalidate_cycle, reopen_order, revert_product_to_cycle
from models import Base, CycleLog, Machine, Order, Person, Product, TaskLog


def session():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_cycle_is_invalidated_instead_of_deleted():
    db = session()
    machine = Machine(name="M1", sensor_ids=[], sensor_count=0)
    db.add(machine); db.flush()
    cycle = CycleLog(machine_id=machine.id, timestamp=datetime.now(), cycle_start_time=datetime.now())
    db.add(cycle); db.commit()
    invalidate_cycle(cycle.id, {"reason": "Yanlış tetik"}, db)
    db.refresh(cycle)
    assert cycle.is_valid is False
    assert cycle.invalid_reason == "Yanlış tetik"
    assert db.query(CycleLog).filter_by(id=cycle.id).count() == 1


def test_product_revert_preserves_audit_records():
    db = session()
    machine = Machine(name="M1", sensor_ids=[], sensor_count=0)
    person = Person(name="A", surname="B")
    db.add_all([machine, person]); db.flush()
    cycle = CycleLog(machine_id=machine.id, timestamp=datetime.now(), cycle_start_time=datetime.now())
    product = Product(name="P", serialnumber="1/1", productsize="x", producttype="x", moldnumber="1")
    db.add_all([cycle, product]); db.flush()
    db.add(TaskLog(machine_id=machine.id, person_id=person.id, product_id=product.id,
        cycle_id=cycle.id, task_name="Üretim", status="SUCCESS"))
    db.commit()
    result = revert_product_to_cycle(product.id, {"reason": "Yanlış seçim"}, db)
    db.refresh(product)
    assert result["cycle_id"] == cycle.id
    assert product.is_reverted is True
    assert db.query(Product).filter_by(id=product.id).count() == 1
    assert db.query(TaskLog).filter_by(product_id=product.id, status="REVERTED").count() == 1


def test_existing_order_accepts_next_line_items():
    db = session()
    db.add_all([
        Order(name="A", productsize="x", producttype="x", moldnumber="1", ordernumber="5171-1", quantity=1, volume_per_piece=1),
        Order(name="B", productsize="x", producttype="x", moldnumber="1", ordernumber="5171-2", quantity=1, volume_per_piece=1),
        Order(name="C", productsize="x", producttype="x", moldnumber="1", ordernumber="5171-3", quantity=1, volume_per_piece=1),
    ])
    db.commit()
    result = create_orders_bulk([{"name":"D", "productsize":"x", "producttype":"x", "moldnumber":"1",
        "ordernumber":"5171-4", "quantity":2, "volume_per_piece":1, "serial_start":1}], db)
    assert result["ids"]
    assert db.query(Order).filter_by(ordernumber="5171-4").count() == 1


def test_completed_order_can_be_reopened_for_additional_products():
    db = session()
    order = Order(
        name="A",
        productsize="x",
        producttype="x",
        moldnumber="1",
        ordernumber="6001-1",
        quantity=1,
        volume_per_piece=1,
        is_manually_completed=True,
        completed_at=datetime.now(),
        completion_note="Tamamlandı",
    )
    db.add(order)
    db.commit()

    result = reopen_order(order.ordernumber, {"reason": "Ek üretim"}, db)

    db.refresh(order)
    assert result["reopened"] is True
    assert order.is_manually_completed is False
    assert order.completed_at is None
    assert order.completion_note == "Ek üretim"
