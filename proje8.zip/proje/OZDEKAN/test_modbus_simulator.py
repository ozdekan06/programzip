from modbus_simulator import Simulator, int_to_bcd, load_device_layout


def test_bcd_conversion():
    assert int_to_bcd(10) == 0x10
    assert int_to_bcd(1234) == 0x1234


def test_state_updates_registers():
    simulator = Simulator()
    simulator.add_device(7, "timer")
    state = simulator.update(7, {"timer1": 25, "temperature": 190, "action": "start"})
    assert state["running"] is True
    assert simulator.context[7].getValues(3, 0, 3)[0] == 0x25
    assert simulator.context[7].getValues(2, 0, 7)[6] is True


def test_stop_and_reset():
    simulator = Simulator()
    simulator.update(1, {"timer1": 20, "remaining1": 2, "action": "reset"})
    state = simulator.snapshot(1)
    assert state["remaining1"] == 20
    assert state["phase"] == "renewal"


def test_loads_machine_device_layout(tmp_path):
    import json
    import sqlite3
    database = tmp_path / "test.db"
    with sqlite3.connect(database) as connection:
        connection.execute("CREATE TABLE machines (sensor_ids TEXT, timer_id INTEGER, is_active INTEGER)")
        connection.execute("INSERT INTO machines VALUES (?, ?, 1)", (json.dumps([2, 3, 4]), 1))
    assert load_device_layout(database) == {1: "timer", 2: "sensor", 3: "sensor", 4: "sensor"}
