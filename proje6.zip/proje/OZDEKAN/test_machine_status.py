from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import main


def machine(active=True, timer_id=7, timeout=5):
    return SimpleNamespace(
        is_active=active,
        timer_id=timer_id,
        sensor_timeout_minutes=timeout,
    )


def timer_data(bits, read_at=None, quality="GOOD"):
    return {
        "discrete_inputs": bits,
        "discrete_read_at": read_at or datetime.now(timezone.utc).isoformat(),
        "quality": quality,
    }


def setup_function():
    main.cache.clear()


def test_only_inactive_machine_is_idle():
    assert main._live_machine_status(machine(active=False)) == "idle"
    assert main._live_machine_status(machine(timer_id=None)) == "renewal"


def test_start_zero_is_renewal():
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 0])
    assert main._live_machine_status(machine()) == "renewal"


def test_start_one_is_cooking_regardless_of_output():
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 1])
    assert main._live_machine_status(machine()) == "cooking"


def test_active_machine_without_timer_data_is_renewal():
    main.cache.clear()
    assert main._live_machine_status(machine()) == "renewal"


def test_reset_gate_and_quality_do_not_make_active_machine_idle():
    main.cache[7] = timer_data([1, 0, 0, 0, 1, 0, 1])
    assert main._live_machine_status(machine()) == "cooking"
    main.cache[7] = timer_data([1, 0, 0, 0, 0, 1, 1])
    assert main._live_machine_status(machine()) == "cooking"
    main.cache[7] = timer_data([1, 0, 0, 0, 0, 0, 1], quality="OFFLINE")
    assert main._live_machine_status(machine()) == "cooking"
    stale = (datetime.now(timezone.utc) - timedelta(minutes=6)).isoformat()
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 0], read_at=stale)
    assert main._live_machine_status(machine()) == "renewal"


def test_inactive_machine_does_not_report_sensor_warning():
    inactive = SimpleNamespace(
        id=1,
        name="Pasif makine",
        slave_id=1,
        sensor_ids=[2],
        sensor_suspended={"2": True},
        sensor_timeout_minutes=5,
        is_active=False,
        timer_id=7,
    )
    main.cache[2] = {
        "input_registers": [500],
        "holding_registers": [100, 0, 0, 0, 0, 5],
    }

    class Query:
        def order_by(self, *_args):
            return self

        def all(self):
            return [inactive]

    class Db:
        def query(self, *_args):
            return Query()

        def add(self, *_args):
            raise AssertionError("Pasif makine sensörü değiştirilmemeli")

        def commit(self):
            raise AssertionError("Pasif makine için commit yapılmamalı")

    status = main.get_machines_status(Db())[0]
    assert status["status"] == "idle"
    assert status["sensor_alarm"] is False
    assert status["sensor_timeout"] is False
    assert inactive.sensor_suspended == {"2": True}


def test_temperature_alarm_uses_alarm1set_instead_of_hysteresis():
    holding = [0] * 13
    holding[0] = 200
    holding[5] = 5
    holding[12] = 15

    lower, upper = main.temperature_alarm_limits(holding)
    assert (lower, upper) == (185, 215)
    assert lower <= 210 <= upper  # Histerezis disi, alarm araligi ici.
    assert 216 > upper
    assert 184 < lower
