"""RS-485 hattinda osiloskop ile yansima incelemek icin test deseni uretir.

Bu program Modbus paketi gondermez. USB/RS-485 donusturucunun TX ucunda
tekrarlanabilir kenarlar olusturur. Test boyunca normal Modbus uygulamasini
kapali tutun; seri portu yalnizca bu program kullanmalidir.
"""

from __future__ import annotations

import argparse
import sys
import time

import serial


PATTERNS = {
    # Her veri bitinde gecis: tetikleme ve ringing incelemesi icin en kullanisli.
    "55": bytes([0x55]),
    # Ters faz; alici ve verici polaritesini kontrol etmek icin.
    "aa": bytes([0xAA]),
    # Uzun ayni seviye aralarinda kenarlar; overshoot'u daha rahat ayirabilir.
    "edges": bytes([0x00, 0xFF]),
}


def positive_int(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("deger sifirdan buyuk olmali")
    return number


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RS-485 osiloskop/yansima test sinyali uretir."
    )
    parser.add_argument("--port", required=True, help="Ornek: COM6 veya /dev/ttyUSB0",default="/dev/tty.usbmodem58B60281011")
    parser.add_argument("--baud", type=positive_int, default=9600)
    parser.add_argument("--pattern", choices=PATTERNS, default="55")
    parser.add_argument(
        "--mode",
        choices=("continuous", "burst"),
        default="burst",
        help="continuous: kesintisiz; burst: desenler arasinda bosluk",
    )
    parser.add_argument(
        "--burst-bytes",
        type=positive_int,
        default=32,
        help="Her burstte gonderilecek yaklasik byte sayisi",
    )
    parser.add_argument(
        "--gap-ms", type=float, default=20.0, help="Burstler arasi bekleme (ms)"
    )
    return parser


def make_payload(pattern: bytes, requested_size: int) -> bytes:
    repeats = (requested_size + len(pattern) - 1) // len(pattern)
    return (pattern * repeats)[:requested_size]


def main() -> int:
    args = build_parser().parse_args()
    if args.gap_ms < 0:
        print("Hata: --gap-ms negatif olamaz.", file=sys.stderr)
        return 2

    pattern = PATTERNS[args.pattern]
    payload = make_payload(pattern, args.burst_bytes)

    try:
        with serial.Serial(
            port=args.port,
            baudrate=args.baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=1,
            write_timeout=2,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False,
        ) as link:
            link.reset_input_buffer()
            link.reset_output_buffer()
            print(
                f"Test aktif: {args.port}, {args.baud} baud, 8N1, "
                f"desen={args.pattern}, mod={args.mode}"
            )
            print("Durdurmak icin Ctrl+C.")

            if args.mode == "continuous":
                # Buyuk bloklar USB zamanlama bosluklarini azaltir.
                block = make_payload(pattern, 4096)
                while True:
                    link.write(block)
            else:
                gap_seconds = args.gap_ms / 1000.0
                while True:
                    link.write(payload)
                    link.flush()  # Burst hatta tamamen cikmadan beklemeyi baslatma.
                    time.sleep(gap_seconds)
    except KeyboardInterrupt:
        print("\nTest durduruldu.")
        return 0
    except serial.SerialException as exc:
        print(f"Seri port hatasi: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
