from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, JSON, ForeignKey, Float, Boolean
from datetime import datetime
from sqlalchemy.orm import relationship

Base = declarative_base()


class UARTLog(Base):
    __tablename__ = "uart_logs"
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.now)
    direction = Column(String)
    data = Column(String)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)


class Person(Base):
    __tablename__ = "person"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    surname = Column(String, nullable=False)
    age = Column(Integer, nullable=True)
    

class Product(Base):
    __tablename__ = "product"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    serialnumber = Column(String, nullable=False, unique=True)
    productsize = Column(String, nullable=False)
    producttype = Column(String, nullable=False)
    moldnumber = Column(String, nullable=False)
    lot_number = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.now)

    # Son kalite durumu değişikliğinin izlenebilir özeti.
    status_change = Column(String, nullable=True)
    status_change_reason = Column(String, nullable=True)
    status_changed_at = Column(DateTime, nullable=True)
    
    ordernumber = Column(String, ForeignKey("orders.ordernumber"), nullable=True)


class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False)
    productsize = Column(String, nullable=False)
    producttype = Column(String, nullable=False)
    moldnumber = Column(String, nullable=False)
    ordernumber = Column(String, nullable=False, unique=True)
    quantity = Column(Integer, nullable=False)
    unit = Column(String, nullable=True)
    volume_per_piece = Column(Float, nullable=True)
    is_manually_completed = Column(Boolean, default=False, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    completion_note = Column(String, nullable=True)
    
    # Yeni alanlar
    serial_start = Column(Integer, nullable=True)  # Tam seri numarasındaki son sıra değeri
    lot_number = Column(String, nullable=True)     # Lot değeri
    person_id = Column(Integer, ForeignKey("person.id"), nullable=True)  # Personel
    
    timestamp = Column(DateTime, default=datetime.now)

    product = relationship("Product")
    person = relationship("Person")


class Machine(Base):
    __tablename__ = "machines"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    slave_id = Column(Integer, unique=True)
    sensor_ids = Column(JSON, nullable=False, unique=True)
    # Sensör ID'si -> kullanıcı açıklaması (örn. {"12": "Fırın girişi"})
    sensor_descriptions = Column(JSON, nullable=False, default=dict)
    sensor_count = Column(Integer, nullable=False)
    image = Column(String, default="C/....image.png")
    timer_id = Column(Integer, unique=True)
    # Whether this machine is active and should be polled by background tasks
    is_active = Column(Boolean, default=True, nullable=False)
    sensor_timeout_minutes = Column(Integer, default=5, nullable=False)
    sensor_suspended = Column(JSON, default=dict, nullable=False)



class SensorLog(Base):
    __tablename__ = "sensor_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=False)  # Hangi sensör
    timestamp = Column(DateTime, default=datetime.now)
    value = Column(Integer, nullable=False)  # Ölçülen sıcaklık (veya diğer parametre)
    value_set = Column(Integer, nullable=False)  # Set değeri
    value_histerezis = Column(Integer, nullable=False)  # Histerezis değeri
    
    machine = relationship("Machine")


class TimerLog(Base):
    __tablename__ = "timer_logs"
    id = Column(Integer,primary_key=True,index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=False)  # Hangi sensör
    timestamp = Column(DateTime, default=datetime.now)

    value_T1 = Column(Float, nullable=True)
    value_T1A = Column(Float, nullable=True)
    value_T2 =  Column(Float, nullable=True) 
    value_T2A =  Column(Float, nullable=True) 

    value_out = Column(Integer, nullable=True)  
    value_state = Column(String, nullable=True)

    machine = relationship("Machine")



class AlarmLog(Base):
    __tablename__ = "alarm_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    sensor_id = Column(Integer, nullable=True)  # İlgili sensör
    alarm_type = Column(String, nullable=False)  # 'HIGH_TEMP', 'LOW_TEMP' gibi
    start_time = Column(DateTime, default=datetime.now,nullable=False)  # Alarm başladığında doldurulur
    end_time = Column(DateTime,nullable=True)  # Alarm bitince doldurulur
    details = Column(String, nullable=True)  # Açıklama (örn. "Sıcaklık 250°C üzerine çıktı")

    machine = relationship("Machine")



class CycleLog(Base):
    __tablename__ = "cycle_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.now, nullable=False)  # Kayıt zamanı
    
    # Cycle zamanları
    cycle_start_time = Column(DateTime, nullable=True)  # Cycle başlangıç (ilk Start 1)
    cycle_end_time = Column(DateTime, nullable=True)    # Cycle bitiş (tekrar Start 1)
    cooking_start_time = Column(DateTime, nullable=True) # Pişirme başlangıç zamanını persist etmek için
    
    # Gerçek süreler (dakika)
    cooking_duration = Column(Float, nullable=True)     # Gerçek pişirme süresi
    renewal_duration = Column(Float, nullable=True)     # Gerçek yenileme süresi
    total_duration = Column(Float, nullable=True)       # Toplam cycle süresi
    
    # İdeal süreler (dakika)
    ideal_cooking_time = Column(Float, nullable=True)   # T1 - İdeal pişirme
    ideal_renewal_time = Column(Float, nullable=True)   # T2 - İdeal yenileme
    ideal_total_time = Column(Float, nullable=True)     # T1 + T2
    
    # Gecikmeler (dakika, + gecikme / - erken)
    cooking_delay = Column(Float, nullable=True)        # Pişirme gecikmesi
    renewal_delay = Column(Float, nullable=True)        # Yenileme gecikmesi
    total_delay = Column(Float, nullable=True)          # Toplam gecikme

    machine = relationship("Machine")


class TaskLog(Base):
    __tablename__ = "task_logs"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    person_id = Column(Integer, ForeignKey("person.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("product.id"), nullable=False)
    cycle_id = Column(Integer, ForeignKey("cycle_logs.id"), nullable=True)  # İlgili döngü
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    task_name = Column(String, nullable=False)
    status = Column(String, nullable=False)  # 'SUCCESS', 'FAILED', 'CANCELLED' gibi
    
    details = Column(String, nullable=True)  # Açıklama veya hata mesajı

    machine = relationship("Machine")   


class CycleEvent(Base):
    __tablename__ = "cycle_events"
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.now, nullable=False)
    event_type = Column(String, nullable=False)  # 'START' or 'STOP'
    details = Column(JSON, nullable=True)
    processed = Column(Integer, default=0, nullable=False)  # 0 = unprocessed, 1 = processed

    machine = relationship("Machine")
