"""Durable cycle collection, restart reconciliation and audited historical repairs."""
from datetime import datetime
from pathlib import Path
import sqlite3

from sqlalchemy import text
from models import Base, CycleLog, CycleEvent, CycleRecovery, CycleAudit, Machine, Order, TaskLog
from product_recovery import require_no_active_cycle_products


def open_cycle(db, machine_id):
    return db.query(CycleLog).filter(
        CycleLog.machine_id == machine_id, CycleLog.is_valid.is_(True),
        CycleLog.review_required.is_(False), CycleLog.cycle_end_time.is_(None)
    ).order_by(CycleLog.cycle_start_time.desc(), CycleLog.id.desc()).first()


def snapshot(c):
    return {col.name: (getattr(c, col.name).isoformat() if isinstance(getattr(c, col.name), datetime)
                       else getattr(c, col.name)) for col in c.__table__.columns}


def audit(db, machine_id, action, details):
    db.add(CycleAudit(machine_id=machine_id, action=action, details=details))


def recalculate(c):
    if c.cycle_start_time and c.cycle_end_time:
        c.total_duration = (c.cycle_end_time - c.cycle_start_time).total_seconds() / 60
    else:
        c.total_duration = None
    c.renewal_duration = (c.total_duration - c.cooking_duration
                          if c.total_duration is not None and c.cooking_duration is not None else None)
    c.ideal_total_time = (c.ideal_cooking_time or 0) + (c.ideal_renewal_time or 0)
    c.cooking_delay = (c.cooking_duration - c.ideal_cooking_time
                       if c.cooking_duration is not None and c.ideal_cooking_time is not None else None)
    c.renewal_delay = (c.renewal_duration - c.ideal_renewal_time
                       if c.renewal_duration is not None and c.ideal_renewal_time is not None else None)
    c.total_delay = c.total_duration - c.ideal_total_time if c.total_duration is not None else None


def new_cycle(db, machine_id, at, details=None, source="observed"):
    details = details or {}
    machine = db.get(Machine, machine_id)
    order = db.query(Order).filter(Order.ordernumber == machine.active_order_number).first() if machine and machine.active_order_number else None
    c = CycleLog(machine_id=machine_id, timestamp=at, cycle_start_time=at,
                 cooking_start_time=at, ideal_cooking_time=details.get("t1_min"),
                 ideal_renewal_time=details.get("t2_min"), time_source=source,
                 order_number=getattr(machine, "active_order_number", None),
                 person_id=getattr(machine, "active_person_id", None),
                 mold_count=getattr(machine, "active_mold_count", None),
                 lot_number=getattr(machine, "active_lot_number", None) or getattr(order, "lot_number", None))
    recalculate(c)
    db.add(c)
    db.flush()
    return c


def apply_event(db, ev):
    db.flush()
    c = open_cycle(db, ev.machine_id)
    if ev.event_type == "START":
        if c and c.cooking_duration is None:
            # A repeated high is not a new physical edge; never orphan a cycle.
            audit(db, ev.machine_id, "duplicate_start_ignored", {"event_id": ev.id, "cycle_id": c.id})
        else:
            if c:
                c.cycle_end_time = ev.timestamp
                recalculate(c)
            new_cycle(db, ev.machine_id, ev.timestamp, ev.details)
    elif ev.event_type == "STOP":
        if c and c.cooking_duration is None and c.cooking_start_time and ev.timestamp >= c.cooking_start_time:
            c.cooking_duration = (ev.timestamp - c.cooking_start_time).total_seconds() / 60
            recalculate(c)
        elif not c:
            audit(db, ev.machine_id, "unmatched_stop", {"event_id": ev.id})
    ev.processed = 1
    db.flush()


def process_events(db):
    events = db.query(CycleEvent).filter(CycleEvent.processed == 0).order_by(CycleEvent.timestamp, CycleEvent.id).all()
    for ev in events:
        state = db.get(CycleRecovery, ev.machine_id)
        if state and state.pending:
            continue  # Collection continues; aggregation waits for the operator.
        apply_event(db, ev)
    db.commit()  # Cycle changes and processed flags succeed or fail together.


def initialize_recovery(db, now=None):
    now = now or datetime.now()
    # Finish durable events from the preceding run before taking the snapshot.
    process_events(db)
    for machine in db.query(Machine).all():
        state = db.get(CycleRecovery, machine.id)
        c = open_cycle(db, machine.id)
        if state is None:
            state = CycleRecovery(machine_id=machine.id, opened_at=now, revision=0)
            db.add(state)
        previously_pending = bool(state.pending)
        audit(db, machine.id, "session_started", {
            "previous_clean_shutdown": bool(state.clean_shutdown),
            "last_seen_at": state.last_seen_at.isoformat() if state.last_seen_at else None,
            "previously_pending": previously_pending, "open_cycle_id": c.id if c else None,
        })
        state.pending = previously_pending or c is not None
        state.cycle_id = c.id if c else None
        state.opened_at = now
        state.reference_at = None
        state.reference_start = None
        state.last_start = None  # First fresh read establishes a baseline, never a START.
        state.clean_shutdown = False
        state.revision = (state.revision or 0) + 1
    db.commit()


def observe_timer(db, machine_id, value, at, details=None):
    state = db.get(CycleRecovery, machine_id)
    if state is None:
        state = CycleRecovery(machine_id=machine_id, opened_at=at, revision=1)
        db.add(state)
    if state.last_seen_at and (at - state.last_seen_at).total_seconds() > 30:
        current_cycle = open_cycle(db, machine_id)
        state.pending = state.pending or current_cycle is not None or value == 1
        state.cycle_id = current_cycle.id if current_cycle else None
        state.last_start = None
        state.revision += 1
    if state.last_start is None:
        state.reference_at, state.reference_start = at, value
        if value == 1 and not open_cycle(db, machine_id):
            state.pending = True  # Running at first observation: actual start is unknown.
            state.revision += 1
        if state.pending:
            state.revision += 1  # Forms fetched before the first read must refresh.
    elif value != state.last_start:
        db.add(CycleEvent(machine_id=machine_id, timestamp=at,
                          event_type="START" if value else "STOP", details=details or {}))
        state.last_event_at = at
    state.last_start, state.last_seen_at = value, at
    db.commit()


def parse_time(value, name, required=True):
    if not value and not required:
        return None
    try:
        result = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name}: geçerli tarih ve saat girin")
    if result.tzinfo is not None:
        raise ValueError(f"{name}: yerel tarih ve saat girin")
    if result > datetime.now():
        raise ValueError(f"{name}: gelecekte olamaz")
    return result


def set_cooking_stop(c, at):
    if not c.cooking_start_time or at < c.cooking_start_time:
        raise ValueError("Pişirme bitişi başlangıçtan önce olamaz")
    c.cooking_duration = (at - c.cooking_start_time).total_seconds() / 60
    recalculate(c)


def resolve_recovery(db, machine_id, payload):
    state = db.get(CycleRecovery, machine_id)
    if not state or not state.pending or state.revision != payload.get("revision"):
        raise ValueError("Bu doğrulama değişti veya zaten tamamlandı; listeyi yenileyin")
    if state.reference_at is None:
        raise ValueError("Timer'dan ilk güncel okuma bekleniyor")
    action, phase = payload.get("action"), payload.get("phase")
    if action not in ("continue", "finished", "new"):
        raise ValueError("Geçerli bir işlem seçin")
    if action in ("continue", "new") and phase not in ("cooking", "renewal"):
        raise ValueError("Referans anındaki aşamayı seçin")
    c = open_cycle(db, machine_id)
    before = snapshot(c) if c else None
    reference = state.reference_at
    note = str(payload.get("note") or "").strip()
    if not note:
        raise ValueError("Doğrulama açıklaması zorunludur")
    if action == "continue" and not c:
        raise ValueError("Devam edilecek açık cycle yok; yeni cycle oluşturun")
    stop = parse_time(payload.get("cooking_end_time"), "Pişirme bitişi", required=False)
    if stop and stop > reference:
        raise ValueError("Pişirme bitişi referans anından sonra olamaz")
    if action == "finished":
        if not c:
            raise ValueError("Tamamlanacak açık cycle yok")
        if state.reference_start == 1:
            raise ValueError("Referans anında timer pişirme gösteriyor; aynı cycle'ı devam ettirin veya yeni cycle oluşturun")
        end = parse_time(payload.get("cycle_end_time"), "Cycle bitişi")
        if not c.cycle_start_time or end < c.cycle_start_time or end > reference:
            raise ValueError("Cycle bitişi başlangıç ile referans anı arasında olmalı")
        if stop:
            if stop > end:
                raise ValueError("Pişirme bitişi cycle bitişinden sonra olamaz")
            set_cooking_stop(c, stop)
        if c.cooking_duration is None:
            raise ValueError("Pişirme bitişi gereklidir")
        if c.cooking_start_time and c.cooking_start_time.timestamp() + c.cooking_duration * 60 > end.timestamp():
            raise ValueError("Cycle bitişi pişirme bitişinden önce olamaz")
        c.cycle_end_time, c.closure_type = end, "operator_restart"
        recalculate(c)
    else:
        if action == "new":
            start = parse_time(payload.get("cycle_start_time"), "Yeni cycle başlangıcı")
            if start > reference:
                raise ValueError("Başlangıç referans anından sonra olamaz")
            overlap = db.query(CycleLog).filter(
                CycleLog.machine_id == machine_id, CycleLog.is_valid.is_(True),
                CycleLog.review_required.is_(False), CycleLog.id != (c.id if c else -1),
                CycleLog.cycle_start_time < reference,
                (CycleLog.cycle_end_time > start) | CycleLog.cycle_end_time.is_(None)
            ).first()
            if overlap:
                raise ValueError(f"Yeni başlangıç cycle #{overlap.id} ile çakışıyor")
            if c:
                require_no_active_cycle_products(db, c.id)
                c.is_valid, c.invalidated_at = False, datetime.now()
                c.invalid_reason, c.closure_type = note, "replaced_on_restart"
            details = payload.get("timer_details") or {}
            # Prefer already recorded timer settings, not caller-provided values.
            if before and not details:
                details = {"t1_min": before["ideal_cooking_time"], "t2_min": before["ideal_renewal_time"]}
            c = new_cycle(db, machine_id, start, details, "operator")
        if phase == "cooking":
            c.cooking_duration = None
            recalculate(c)
        else:
            if not stop:
                raise ValueError("Yenileme için pişirme bitiş zamanı gereklidir")
            set_cooking_stop(c, stop)
    if c:
        c.time_source, c.recovery_note = "operator", note
    db.flush()
    # The operator describes state at the first read. Replay every later edge.
    # Events from an earlier unresolved run are covered by that explicit decision.
    for ev in db.query(CycleEvent).filter(CycleEvent.machine_id == machine_id, CycleEvent.processed == 0).order_by(CycleEvent.timestamp, CycleEvent.id):
        if ev.timestamp <= reference:
            ev.processed = 1
        else:
            apply_event(db, ev)
    state.pending = False
    state.revision += 1
    state.decision = {"action": action, "phase": phase, "reference_at": reference.isoformat(), "note": note}
    audit(db, machine_id, "restart_resolved", {"before": before, "after": snapshot(c) if c else None,
                                               "decision": state.decision, "payload": payload})
    db.commit()


def repair_history(db):
    """Only merge same-day orphan chains with no product links. Flag others."""
    changed = []
    for machine in db.query(Machine).all():
        events = db.query(CycleEvent).filter(CycleEvent.machine_id == machine.id).order_by(CycleEvent.timestamp, CycleEvent.id).all()
        chain = []
        groups = []
        for ev in events:
            if ev.event_type == "START":
                chain.append(ev)
            else:
                if len(chain) > 1:
                    groups.append(chain)
                chain = []
        if len(chain) > 1:
            groups.append(chain)
        for group in groups:
            starts = [ev.timestamp for ev in group]
            rows = db.query(CycleLog).filter(CycleLog.machine_id == machine.id, CycleLog.cycle_start_time.in_(starts), CycleLog.is_valid.is_(True)).order_by(CycleLog.cycle_start_time, CycleLog.id).all()
            if len(rows) < 2 or not any(c.cycle_end_time is None for c in rows[:-1]):
                continue
            if all(c.review_required for c in rows):
                continue
            linked = db.query(TaskLog.id).filter(TaskLog.cycle_id.in_([c.id for c in rows])).first()
            safe = (not linked and starts[0].date() == starts[-1].date()
                    and all(c.cycle_end_time is None and c.cooking_duration is None for c in rows[:-1]))
            before = [snapshot(c) for c in rows]
            if safe:
                target, last = rows[0], rows[-1]
                target.cycle_end_time = last.cycle_end_time
                if last.cooking_duration is not None and last.cooking_start_time:
                    from datetime import timedelta
                    stop = last.cooking_start_time + timedelta(minutes=last.cooking_duration)
                    set_cooking_stop(target, stop)
                target.time_source = "inferred_repair"
                target.recovery_note = "Art arda START kayıtlarından eski başlangıç korundu; kapanış sırasında geçiş kaçmış olabilir."
                target.review_required = True
                recalculate(target)
                for duplicate in rows[1:]:
                    duplicate.is_valid = False
                    duplicate.invalidated_at = datetime.now()
                    duplicate.invalid_reason = f"Tekrarlanan START; cycle #{target.id} içinde korundu"
                    duplicate.closure_type = "duplicate_repair"
                action = "historical_duplicate_repaired"
            else:
                for c in rows:
                    c.review_required = True
                    c.recovery_note = "Kayıp STOP veya yeniden açılış: başlangıç ve ürün bağlantıları kullanıcı tarafından doğrulanmalı."
                action = "historical_review_required"
            ids = [c.id for c in rows]
            audit(db, machine.id, action, {"cycle_ids": ids, "before": before})
            changed.append({"action": action, "cycle_ids": ids})
    db.commit()
    return changed


def resolve_history(db, cycle_id, payload):
    c = db.get(CycleLog, cycle_id)
    if not c or not c.is_valid or not c.review_required:
        raise ValueError("İncelenecek geçerli cycle bulunamadı")
    ids = payload.get("merge_ids") or []
    if not isinstance(ids, list) or any(type(i) is not int for i in ids):
        raise ValueError("Birleştirme kimlikleri sayı listesi olmalı")
    rows = [c]
    for id_ in set(ids) - {c.id}:
        duplicate = db.get(CycleLog, id_)
        if not duplicate or duplicate.machine_id != c.machine_id or not duplicate.is_valid or not duplicate.review_required:
            raise ValueError("Yalnız aynı makinenin inceleme bekleyen kayıtları birleştirilebilir")
        rows.append(duplicate)
    before = [snapshot(row) for row in rows]
    note = str(payload.get("note") or "").strip()
    if not note:
        raise ValueError("Düzeltme açıklaması gereklidir")
    if payload.get("action") == "invalidate":
        if len(rows) != 1:
            raise ValueError("Geçersizleştirme için tek cycle seçin; birleştirmek için zamanları düzeltme işlemini seçin")
        require_no_active_cycle_products(db, c.id)
        c.is_valid, c.invalid_reason, c.invalidated_at = False, note, datetime.now()
    elif payload.get("action") == "correct":
        start = parse_time(payload.get("cycle_start_time"), "Başlangıç")
        stop = parse_time(payload.get("cooking_end_time"), "Pişirme bitişi")
        end = parse_time(payload.get("cycle_end_time"), "Cycle bitişi")
        if not start <= stop <= end:
            raise ValueError("Başlangıç ≤ pişirme bitişi ≤ cycle bitişi olmalı")
        overlap = db.query(CycleLog).filter(CycleLog.machine_id == c.machine_id, CycleLog.is_valid.is_(True),
                    CycleLog.id.notin_([r.id for r in rows]), CycleLog.cycle_start_time < end,
                    (CycleLog.cycle_end_time > start) | CycleLog.cycle_end_time.is_(None)).first()
        if overlap:
            raise ValueError(f"Zaman aralığı cycle #{overlap.id} ile çakışıyor; aynı üretimse birleştirme listesine ekleyin")
        c.cycle_start_time = c.cooking_start_time = start
        c.cycle_end_time = end
        set_cooking_stop(c, stop)
        for duplicate in rows[1:]:
            db.query(TaskLog).filter(TaskLog.cycle_id == duplicate.id).update({TaskLog.cycle_id: c.id}, synchronize_session=False)
            duplicate.is_valid, duplicate.invalidated_at = False, datetime.now()
            duplicate.invalid_reason = f"Kullanıcı onayıyla cycle #{c.id} ile birleştirildi: {note}"
            duplicate.closure_type = "operator_merge"
    else:
        raise ValueError("Geçerli işlem seçin")
    c.review_required, c.time_source, c.recovery_note = False, "operator", note
    c.closure_type = "operator_history"
    audit(db, c.machine_id, "historical_resolved", {"before": before, "after": snapshot(c), "payload": payload})
    db.commit()


def migrate_cycles(engine):
    columns = {"time_source": "TEXT DEFAULT 'observed' NOT NULL",
               "review_required": "INTEGER DEFAULT 0 NOT NULL", "recovery_note": "TEXT"}
    with engine.connect() as conn:
        existing = {r[1] for r in conn.execute(text("PRAGMA table_info(cycle_logs)"))}
    missing = set(columns) - existing
    backup = None
    if missing and engine.url.database and engine.url.database != ":memory:":
        path = Path(engine.url.database)
        if path.exists():
            backup = str(path.with_name(path.name + ".before-cycle-recovery-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".bak"))
            with sqlite3.connect(str(path)) as src, sqlite3.connect(backup) as dst:
                src.backup(dst)
    with engine.begin() as conn:
        for name in missing:
            conn.execute(text(f"ALTER TABLE cycle_logs ADD COLUMN {name} {columns[name]}"))
    Base.metadata.create_all(engine)
    return backup
