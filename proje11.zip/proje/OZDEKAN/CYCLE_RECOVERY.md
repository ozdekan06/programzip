# Cycle yeniden açılış doğrulaması

Program açıldığında geçerli açık cycle varsa, otomatik yeni START üretmek yerine
kullanıcı doğrulaması beklenir. İlk güncel timer okuması sabit bir referans anı
oluşturur. Açık cycle olmadan ilk okuma pişirme gösteriyorsa gerçek başlangıç
bilinmediği için yine kullanıcıdan başlangıç zamanı istenir.

Ana uygulama sayfalarında “Cycle doğrulaması” penceresi varsayılan olarak otomatik
açılmaz. Sağ alttaki düğmeden elle açılır. Pencerenin içindeki “Cycle doğrulaması
gerektiğinde otomatik uyar” anahtarı açılırsa önceki otomatik açılış davranışı
etkinleşir. Tercih bu tarayıcıda saklanır; varsayılan kapalıdır. “Kapat / Sonra
incele” ile o sayfa oturumu için ertelenebilir. Erteleme sinyal kaydını durdurmaz.
Onaylanmamış cycle yeni ürüne bağlanamaz ve eski kapatma düğmelerinden kapatılamaz.

- **Aynı cycle devam ediyor:** Eski başlangıç korunur. Referans anında yenilemedeyse
  pişirme bitiş zamanı girilir. Pişirmedeyse eski başlangıçtan devam edilir.
- **Bu cycle bitti:** Gerçek pişirme bitişi ve cycle bitişiyle kapatılır. Referans
  anında timer pişirme gösteriyorsa aynı cycle veya yeni cycle seçilmelidir.
- **Yeni cycle oluştur:** Eski cycle gerekçesiyle geçersiz olarak korunur. Yeni
  başlangıç tarih/saatini kullanıcı girer; yenilemedeyse pişirme bitişini de girer.

Karar referans anını anlatır. Bu andan sonraki START/STOP olayları kalıcı kuyrukta
bekler; onayda zaman sırasıyla işlenir. Onay beklerken program tekrar kapanırsa,
yeni açılışta yeni referans anı istenir. Önceki bekleyen olaylar korunur; yeni
referans anından önceki olaylar kullanıcı kararı kapsamında işlenmiş sayılır.

Cycle güncellemeleri ve olayın işlendi işareti aynı transaction içindedir.
Tekrarlanan START pişirmesi devam eden cycle'ı değiştirmez. Tekrarlanan STOP da
önceden ölçülen pişirme süresini değiştirmez. Geçersiz ve inceleme bekleyen eski
cycle'lar canlı olayların hedefi olmaz.

30 saniyeden uzun timer okuma boşluğu sonrası da açık cycle veya pişirme sinyali
varsa doğrulama istenir. Yeni okuma yokken eski cache değerleri olay üretmez.
Program kapalıyken cihazda gerçekleşen geçişler cihazın olay geçmişi olmadan
kesin olarak hesaplanamaz. Kullanıcının verdiği zamanlar `operator`, olaylardan
çıkarılan geçmiş düzeltmeler `inferred_repair`, normal ölçümler `observed` olarak
saklanır; rapor ekranı ve dışa aktarma bu ayrımı gösterir.

## Geçmiş veri düzeltmesi

Değişiklik öncesi SQLite yedeği:
`logs.db.before-cycle-recovery-20261008-210230-045672.bak`

- Cycle **30** eski başlangıcıyla korundu; cycle **31**'in STOP ve kapanış bilgileri
  kullanılarak tamamlandı. 31 silinmeden tekrar kayıt olarak geçersiz işaretlendi.
  Bu çıkarım 30 üzerinde inceleme onayı bekliyor.
- **7, 8, 9** ürün bağlantıları bulunduğu için otomatik birleştirilmedi.
- **22, 23, 24, 25, 26** uzun kesinti içerdiği için otomatik birleştirilmedi.
- Bu dokuz geçerli kayıt “Geçmiş inceleme” ekranında gerçek zamanlarla düzeltilebilir.
  Aynı fiziksel üretime ait oldukları biliniyorsa ilgili kimlikler birlikte
  birleştirilebilir. Ürün/görev bağlantıları seçilen cycle'a taşınır; kaynak kayıtlar
  geçersiz olarak saklanır. Ürüne bağlı bir kayıt tek başına geçersizleştirilecekse
  önce mevcut ürün geri alma akışı kullanılmalıdır.

`cycle_repair_report.json` düzeltme özetini içerir. `cycle_audits` tablosu bütün
önceki değerleri ve kullanıcı kararlarını saklar; `/cycle-audit` bunları listeler.
Mevcut 29 ürün, 29 görev ve 75 olay kaydı yedekle karşılaştırıldı; değişmedi.
41 cycle kaydının tamamı korundu. SQLite bütünlük kontrolü başarılı.

## Doğrulama

Yeni çekirdek ve API testleri `test_cycle_recovery.py` içindedir. Geçici veri dizini
ile çalıştırın; mevcut `test_cycle_events.py` gerçek veritabanına test olayları
eklediği için bu kontrolün parçası değildir.

```sh
OZDEKAN_DATA_DIR=/tmp/ozdekan-cycle-tests python3 -m unittest test_cycle_recovery test_quality_reasons -v
```

Tarayıcı testi gerçek veritabanından ayrı, geçici test verileriyle yapıldı.
Canlı seri cihaz üzerinde kesinti testi yapılmadı.

## Ürün geri alma ve cycle bağlantısı

Cycle geçersizleştirme kontrolü, geçmişteki `SUCCESS` görevlerinin varlığına değil,
cycle'a bağlı ürünlerin `is_reverted` durumuna bakar. Bütün bağlı aktif ürünler
geri alındıktan sonra eski görevler korunur ve geçersizleştirmeye engel olmaz.
Aynı kontrol normal geçersizleştirme, geçmiş inceleme ve açılışta eski cycle'ı
yeni cycle ile değiştirme işlemlerinde uygulanır.

Aktif ürün varsa uyarı seri numaralarını ve **Bağlı ürünleri göster ve geri al**
bağlantısını sunar. Bağlantı Rapor Sayfası / Ürün Logları ekranını cycle kimliğiyle
filtrelenmiş olarak açar. Ürün kartında **Ürünü cycle’a geri al** düğmesi vardır.
Neden ve onay alındıktan sonra yalnız seçilen ürün geri alınır. İşlem sonrası
kalan aktif ürün sayısı ve **Cycle ekranına dön** bağlantısı gösterilir.

Toplu işlem **Gösterilen ürünleri geri al** olarak adlandırıldı; `/products/revert`
üzerinden nedenle çalışır. Önceki `/product-logs/delete` yolu eski istemciler için
korunur; kayıt silmez. Tekli ve toplu geri alma ürün/görev geçmişini korur ve
manuel tamamlanmış siparişi yeniden açar.

Yalnızca cycle zamanı hatalıysa ürünleri geri almaya gerek yoktur; geçmiş inceleme
üzerinden zamanlar düzeltilir. Aynı fiziksel üretime ait tekrar cycle kayıtları,
ürünleri geri almadan kullanıcı onayıyla birleştirilebilir.

`test_product_recovery.py` aktif bağlantı uyarısı, tekli/toplu geri alma,
geçmiş kayıt korunması, kalan bağlantılar, açılışta değiştirme ve geçersizleştirme
senaryolarını kapsar. 33 çekirdek/API/kalite testi ile 4 mevcut otomasyon testi
başarılıdır; yönlendirme ve tek ürün geri alma akışı geçici verilerle Safari'de
test edildi. Bu değişiklikte mevcut üretim verileri geri alınmadı.
