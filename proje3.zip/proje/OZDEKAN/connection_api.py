"""RS-485/Modbus RTU hattının tek sahibi.

Uygulamanın hiçbir bölümü istemciyi doğrudan kullanmamalı; bütün Modbus
işlemleri ``execute`` üzerinden seri hale getirilir. RS-485 aynı anda yalnızca
bir isteği taşıyabildiği için bu hem veri doğruluğunu hem de zamanlamayı korur.
"""

import asyncio
import logging
import os
import time
from collections import Counter
from typing import Any

from pymodbus import FramerType
from pymodbus.client import AsyncModbusSerialClient


logger = logging.getLogger(__name__)

modbus_client = None
connection_lock = asyncio.Lock()
bus_lock = asyncio.Lock()

# Port ayarları deployment sırasında ortam değişkenleriyle değiştirilebilir.
SERIAL_PORT = os.getenv("MODBUS_PORT", "/dev/tty.usbmodem58B60281011")
BAUDRATE = int(os.getenv("MODBUS_BAUDRATE", "9600"))
PARITY = os.getenv("MODBUS_PARITY", "N")
STOPBITS = int(os.getenv("MODBUS_STOPBITS", "1"))
BYTESIZE = int(os.getenv("MODBUS_BYTESIZE", "8"))
TIMEOUT = float(os.getenv("MODBUS_TIMEOUT", "1.0"))
RETRIES = int(os.getenv("MODBUS_RETRIES", "1"))

metrics = Counter()


async def connection() -> bool:
    """Seri portu idempotent biçimde aç."""
    global modbus_client
    async with connection_lock:
        if modbus_client and modbus_client.connected:
            return True

        if modbus_client:
            modbus_client.close()

        modbus_client = AsyncModbusSerialClient(
            port=SERIAL_PORT,
            baudrate=BAUDRATE,
            parity=PARITY,
            stopbits=STOPBITS,
            timeout=TIMEOUT,
            retries=RETRIES,
            reconnect_delay=0.5,
            reconnect_delay_max=5,
            bytesize=BYTESIZE,
            framer=FramerType.RTU,
        )
        connected = await modbus_client.connect()
        metrics["connect_ok" if connected else "connect_error"] += 1
        logger.info("Modbus bağlantısı", extra={"connected": bool(connected), "port": SERIAL_PORT})
        return bool(connected)


async def ensure_connection() -> bool:
    if modbus_client and modbus_client.connected:
        return True
    return await connection()


async def execute(method_name: str, *, slave_id: int, **kwargs: Any):
    """Bir Modbus işlemini hat üzerinde atomik olarak çalıştır.

    Bağlantı kontrolü de bus kilidinin içindedir; böylece başka bir coroutine
    devam eden istek sırasında istemciyi kapatıp yeniden oluşturamaz.
    """
    async with bus_lock:
        if not await ensure_connection():
            raise ConnectionError(f"Modbus seri portu açılamadı: {SERIAL_PORT}")

        started = time.monotonic()
        try:
            method = getattr(modbus_client, method_name)
            result = await method(device_id=slave_id, **kwargs)
            elapsed_ms = (time.monotonic() - started) * 1000
            metrics["requests"] += 1
            metrics["latency_ms_total"] += int(elapsed_ms)
            metric_prefix = f"slave_{slave_id}.{method_name}"
            metrics[f"{metric_prefix}.requests"] += 1
            metrics[f"{metric_prefix}.latency_ms_total"] += int(elapsed_ms)
            metrics[f"{metric_prefix}.last_latency_ms"] = int(elapsed_ms)
            metrics[f"{metric_prefix}.max_latency_ms"] = max(
                metrics[f"{metric_prefix}.max_latency_ms"], int(elapsed_ms)
            )
            if elapsed_ms >= TIMEOUT * 1000:
                metrics[f"{metric_prefix}.retried_or_slow"] += 1
            if result.isError():
                metrics["protocol_errors"] += 1
                metrics[f"{metric_prefix}.errors"] += 1
            else:
                metrics["success"] += 1
            return result, elapsed_ms
        except Exception:
            metrics["transport_errors"] += 1
            # Bir slave'in timeout/bozuk cevabı sağlam seri portun kapanmasını
            # gerektirmez. Yalnızca transport gerçekten düşmüşse kapat; aksi
            # halde bütün cihazlar gereksiz reconnect cezası öder.
            if modbus_client and not modbus_client.connected:
                modbus_client.close()
            raise


async def close() -> None:
    """Devam eden Modbus işlemi bittikten sonra portu güvenle kapat."""
    global modbus_client
    async with bus_lock:
        if modbus_client:
            modbus_client.close()
            modbus_client = None


def get_metrics() -> dict:
    snapshot = dict(metrics)
    requests = snapshot.get("requests", 0)
    snapshot["average_latency_ms"] = (
        round(snapshot.get("latency_ms_total", 0) / requests, 2) if requests else 0.0
    )
    snapshot["connected"] = bool(modbus_client and modbus_client.connected)
    snapshot["port"] = SERIAL_PORT
    return snapshot


def get_request_metrics() -> dict:
    """İstek türü ve slave bazında okunabilir performans özeti."""
    result = {}
    prefixes = {
        key.rsplit(".", 1)[0]
        for key in metrics
        if key.startswith("slave_") and "." in key
    }
    for prefix in sorted(prefixes):
        count = metrics[f"{prefix}.requests"]
        result[prefix] = {
            "requests": count,
            "average_latency_ms": round(
                metrics[f"{prefix}.latency_ms_total"] / count, 2
            ) if count else 0.0,
            "last_latency_ms": metrics[f"{prefix}.last_latency_ms"],
            "max_latency_ms": metrics[f"{prefix}.max_latency_ms"],
            "retried_or_slow": metrics[f"{prefix}.retried_or_slow"],
            "errors": metrics[f"{prefix}.errors"],
        }
    return result
