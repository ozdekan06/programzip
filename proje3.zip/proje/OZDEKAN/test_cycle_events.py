import asyncio
from datetime import datetime
from database import SessionLocal, engine
from models import Base, Machine, CycleEvent, CycleLog
import backgraound as bg

# Ensure tables exist
Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Ensure a machine exists to associate events with
machine = db.query(Machine).first()
if not machine:
    machine = Machine(name="test_machine_for_events", slave_id=9999, sensor_ids=[], sensor_count=0, timer_id=9999)
    db.add(machine)
    db.commit()
    db.refresh(machine)

print(f"Using machine id: {machine.id}")

async def run_test():
    # Start the processor
    task = asyncio.create_task(bg.process_cycle_events())
    await asyncio.sleep(0.2)  # let processor start

    now = datetime.now()
    ev1 = CycleEvent(machine_id=machine.id, timestamp=now, event_type="START", details={"t1_min": 1.0, "t2_min": 0.5})
    db.add(ev1)
    db.commit()
    print("Inserted START at", now)

    await asyncio.sleep(1)

    now2 = datetime.now()
    ev2 = CycleEvent(machine_id=machine.id, timestamp=now2, event_type="STOP", details={})
    db.add(ev2)
    db.commit()
    print("Inserted STOP at", now2)

    await asyncio.sleep(1)

    now3 = datetime.now()
    ev3 = CycleEvent(machine_id=machine.id, timestamp=now3, event_type="START", details={"t1_min": 1.0, "t2_min": 0.5})
    db.add(ev3)
    db.commit()
    print("Inserted START at", now3)

    # Wait for processor to handle events
    await asyncio.sleep(2)

    cycles = db.query(CycleLog).filter(CycleLog.machine_id == machine.id).order_by(CycleLog.id.asc()).all()
    print("\nCycleLogs:")
    for c in cycles:
        print(f"id={c.id} start={c.cycle_start_time} cooking_start={c.cooking_start_time} cooking_duration={c.cooking_duration} end={c.cycle_end_time} total={c.total_duration}")

    # Stop background processor
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

if __name__ == '__main__':
    asyncio.run(run_test())
