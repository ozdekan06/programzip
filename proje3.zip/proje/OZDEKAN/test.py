import logging
from pymodbus.client import ModbusSerialClient
from pymodbus.exceptions import ModbusIOException

# ==========================================================
# LOG AYARLARI (TÜM DEBUG BİLGİLERİ BURADAN GELECEK)
# ==========================================================
def setup_logging(log_to_file: bool = False, filename: str = "modbus_debug.log"):
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    if log_to_file:
        logging.basicConfig(filename=filename, level=logging.DEBUG, format=fmt)
    else:
        logging.basicConfig(level=logging.DEBUG, format=fmt)

    # pymodbus logger'ı debug seviyesine çek
    logging.getLogger("pymodbus").setLevel(logging.DEBUG)


# ==========================================================
# ORTAK YARDIMCI FONKSİYONLAR
# ==========================================================
def print_registers_decimal_and_hex(values):
    if not values:
        print("  (boş)")
        return
    dec_str = " ".join(f"{v:d}" for v in values)
    hex_str = " ".join(f"0x{v:04X}" for v in values)
    print("  DEC:", dec_str)
    print("  HEX:", hex_str)


def print_bits(values):
    if not values:
        print("  (boş)")
        return
    bit_str = " ".join("1" if b else "0" for b in values)
    print("  BITS:", bit_str)


def debug_response(prefix: str, rr, slave_id: int):
    """
    Her okuma sonrası detaylı debug çıktısı.
    CRC hatalı olsaydı pymodbus zaten hata atardı; buraya gelmesi CRC OK demek.
    """
    if rr is None:
        print(f"{prefix} → ❌ Yanıt yok (None döndü)")
        return

    if isinstance(rr, ModbusIOException):
        print(f"{prefix} → ❌ ModbusIOException:", rr)
        return

    if rr.isError():
        # Exception response
        print(f"{prefix} → ❌ Hata cevabı:", rr)
        try:
            print(f"  Function code: {rr.function_code}")
        except Exception:
            pass
        return

    # Buraya gelmişse CRC + çerçeve OK demektir
    print(f"{prefix} → ✔ OK (CRC pymodbus tarafından doğrulandı)")
    try:
        print(f"  Slave ID (unit): {slave_id}")
        print(f"  Function code  : {rr.function_code}")
    except Exception:
        pass

    # PDU seviyesini görmek istersen:
    try:
        pdu = rr.encode()
        print("  PDU (hex)      :", pdu.hex(" "))
    except Exception:
        pass


# ==========================================================
# ASIL TEST FONKSİYONU
# ==========================================================
def read_device_debug(
    port: str,
    baudrate: int,
    slave_id: int,
    holding_count: int = 0,
    input_count: int = 0,
    coil_count: int = 0,
    discrete_count: int = 0,
    timeout: float = 3,
):
    client = ModbusSerialClient(
        port=port,
        baudrate=baudrate,
        bytesize=8,
        parity="N",
        stopbits=1,
        timeout=timeout,
    )

    print("\n==============================================")
    print(f"  Modbus Test Başlıyor → Port={port}, Baud={baudrate}, Slave={slave_id}")
    print("==============================================")

    if not client.connect():
        print("❌ Bağlantı kurulamadı! (Port meşgul mü / yanlış mı?)")
        return

    # ------------------------------
    # HOLDING REGISTERS
    # ------------------------------
    if holding_count > 0:
        print(f"\n📘 Holding Registers (0 → {holding_count - 1})")
        try:
            # NOT: pymodbus 3.x için parametre 'slave', 2.x için 'unit'
            rr = client.read_holding_registers(
                address=0,
                count=holding_count,
                device_id=slave_id,   # Eski sürüm kullanıyorsan: unit=slave_id
            )
            debug_response("Holding", rr, slave_id)
            if not rr.isError():
                print_registers_decimal_and_hex(rr.registers)
        except Exception as e:
            print("❌ Holding exception:", e)

    # ------------------------------
    # INPUT REGISTERS
    # ------------------------------
    if input_count > 0:
        print(f"\n📗 Input Registers (0 → {input_count - 1})")
        try:
            rr = client.read_input_registers(
                address=0,
                count=input_count,
                device_id=slave_id,
            )
            debug_response("Input", rr, slave_id)
            if not rr.isError():
                print_registers_decimal_and_hex(rr.registers)
        except Exception as e:
            print("❌ Input exception:", e)

    # ------------------------------
    # COILS
    # ------------------------------
    if coil_count > 0:
        print(f"\n📒 Coils (0 → {coil_count - 1})")
        try:
            rr = client.read_coils(
                address=0,
                count=coil_count,
                device_id=slave_id,
            )
            debug_response("Coils", rr, slave_id)
            if not rr.isError():
                print_bits(rr.bits)
        except Exception as e:
            print("❌ Coils exception:", e)

    # ------------------------------
    # DISCRETE INPUTS
    # ------------------------------
    if discrete_count > 0:
        print(f"\n📕 Discrete Inputs (0 → {discrete_count - 1})")
        try:
            rr = client.read_discrete_inputs(
                address=0,
                count=discrete_count,
                device_id=slave_id,
            )
            debug_response("Discrete", rr, slave_id)
            if not rr.isError():
                print_bits(rr.bits)
        except Exception as e:
            print("❌ Discrete exception:", e)

    client.close()
    print("\n=== Test Bitti ===\n")


# ==========================================================
# OTOMATİK TEST (sadece slave ID gir → her şeyi dene)
# ==========================================================
def auto_test_slave(slave_id: int):
    """
    Sadece slave_id girmen yeterli olsun diye:
    Burada cihaz tipine göre farklı sayıda register/coil okuma senaryoları koşuyoruz.

    Senin yorum satırındaki değerleri iki profil olarak aldım:
      PROFIL_A: holding=30, input=4, coils=4, discrete=7
      PROFIL_B: holding=52, input=7, coils=10, discrete=4

    İstersen bunları cihaz tipine göre değiştirirsin.
    """
    # PORT ve BAUD'u buradan değiştir:
    PORT = "COM6"
    BAUDRATE = 9600

    print("\n\n########## SLAVE TESTİ BAŞLIYOR ##########")
    print(f"Slave ID: {slave_id}")

    # 1) PROFIL A
    print("\n---- PROFIL A (30/4/4/7) ----")
    read_device_debug(
        port=PORT,
        baudrate=BAUDRATE,
        slave_id=slave_id,
        holding_count=30,
        input_count=4,
        coil_count=4,
        discrete_count=7,
    )

    # 2) PROFIL B
    print("\n---- PROFIL B (52/7/10/4) ----")
    read_device_debug(
        port=PORT,
        baudrate=BAUDRATE,
        slave_id=slave_id,
        holding_count=52,
        input_count=7,
        coil_count=10,
        discrete_count=4,
    )


# ==========================================================
# MAIN
# ==========================================================
if __name__ == "__main__":
    # Konsola DEBUG log'u bas (istersen log dosyasına da alabilirsin)
    setup_logging(log_to_file=False)

    try:
        slave_text = input("Test edilecek Slave ID: ")
        slave_id = int(slave_text.strip())
    except Exception:
        print("Geçersiz slave ID!")
        exit(1)

    auto_test_slave(slave_id)