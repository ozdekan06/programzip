# Copilot Instructions for OZDEKAN Codebase

## Overview
- This is a FastAPI-based backend for industrial machine monitoring and control, communicating with devices via RS485 (Modbus) and serving a web frontend.
- The backend reads sensor/machine data periodically and exposes it via REST endpoints (e.g., `/read-device`, `/read-all`, `/logs`).
- The frontend (HTML/JS in `static/`) polls these endpoints to display live data.

## Key Components
- `main.py`: FastAPI app, all main endpoints, startup/shutdown hooks, and core logic for device data flow.
- `backgraound.py`: Handles periodic sensor reading, device data caching, and Modbus communication helpers.
- `models.py`, `schemas.py`: SQLAlchemy models and Pydantic schemas for DB and API.
- `database.py`: SQLAlchemy engine/session setup, DB helpers.
- `auth.py`: User authentication logic.
- `static/`: HTML templates and JS for the web UI (e.g., `makine.html` for live machine data).

## Data Flow
- On startup, FastAPI connects to Modbus devices and starts periodic sensor polling (see `periodic_sensor_read`).
- Device data is cached (see `cache` in `backgraound.py`) for fast API responses.
- Frontend fetches data via REST endpoints (e.g., `/read-device?m=m1`) and updates the UI.

## Developer Workflows
- **Run server:** `uvicorn main:app --reload` (ensure dependencies installed)
- **DB reset:** Call `/reset-db` endpoint (POST) to drop and recreate tables.
- **Debugging:** Use print statements or inspect cache/state in `backgraound.py`.
- **No test suite detected.**

## Project Conventions
- Machine/device IDs are passed as strings like `m1`, `m2` (see `/read-device`).
- Data is always returned as JSON with keys: `slave_id`, `holding`, `input`.
- Use `cache` for fast device data access; avoid direct Modbus reads in endpoints unless necessary.
- All static files are served from `/static`.

## Integration Points
- RS485/Modbus handled via `pymodbus` in `backgraound.py`.
- SQLAlchemy for DB, SQLite as default (see `logs.db`).
- Frontend communicates only via HTTP (no WebSocket push by default, but endpoint exists).

## Examples
- To fetch device 1 data: `GET /read-device?m=m1`
- To fetch all devices: `GET /read-all`
- To view logs: `GET /logs`

## Key Files
- `main.py`, `backgraound.py`, `static/makine.html`, `models.py`, `schemas.py`, `database.py`

---

For questions about unclear flows or missing documentation, ask the user for clarification or examples from their workflow.
