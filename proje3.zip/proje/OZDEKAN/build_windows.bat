@echo off
setlocal
cd /d "%~dp0"
title OZDEKAN Windows Paketleme
echo OZDEKAN paketleme baslatiliyor...
if not exist "static" echo HATA: Paketi ZIP'ten tamamen cikartin. && goto :error
if not exist "launcher.py" echo HATA: launcher.py bulunamadi. && goto :error
if not exist ".venv-build\Scripts\python.exe" py -3 -m venv .venv-build
if errorlevel 1 goto :error
call .venv-build\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install fastapi "uvicorn[standard]" sqlalchemy databases pydantic psycopg2-binary "pymodbus[serial]" pyserial pyserial-asyncio "passlib[bcrypt]" python-multipart pandas xlsxwriter pyinstaller
if errorlevel 1 goto :error
python -m PyInstaller --noconfirm --clean OZDEKAN.spec
if errorlevel 1 goto :error
echo EXE hazir: %CD%\dist\OZDEKAN.exe
pause
exit /b 0
:error
echo Paketleme basarisiz. Yukaridaki hatayi kontrol edin.
pause
exit /b 1
