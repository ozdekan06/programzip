import asyncio


async def from_bcd(byte: int) -> int:
    """BCD (binary coded decimal) -> integer (0–99)."""
    return ((byte >> 4) * 10) + (byte & 0x0F)


async def to_seconds(time_base: int, raw: int, mmss_hhmm_16bit: bool = True) -> int:
    """
    RS485 timer cihazından okunan değeri saniyeye çevirir ve int olarak döner.

    :param time_base: H2 register'dan okunan 0–8 arası kod
    :param raw: Holding register değeri (int, BCD olabilir)
    :param mmss_hhmm_16bit: True ise MM:SS veya HH:MM tek word (16 bit BCD) olarak gelir
    :return: saniye cinsinden int
    """
    if time_base == 0:   # 99.99s (0.01s çözünürlük, BCD olabileceği varsayımıyla)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int(val / 100)
    elif time_base == 1: # 999.9s (0.1s çözünürlük)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int(val / 10)
    elif time_base == 2: # 9999s (1s çözünürlük)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int(val)
    elif time_base == 3: # 99m59s (MM:SS BCD)
        if mmss_hhmm_16bit:
            mm = await from_bcd((raw >> 8) & 0xFF)
            ss = await from_bcd(raw & 0xFF)
            return int(mm * 60 + ss)
    elif time_base == 4: # 999.9m (0.1 dakika)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int((val / 10) * 60)
    elif time_base == 5: # 9999m (1 dakika)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int(val * 60)
    elif time_base == 6: # 99h59m (HH:MM BCD)
        if mmss_hhmm_16bit:
            hh = await from_bcd((raw >> 8) & 0xFF)
            mm = await from_bcd(raw & 0xFF)
            return int(hh * 3600 + mm * 60)
    elif time_base == 7: # 999.9h (0.1 saat)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int((val / 10) * 3600)
    elif time_base == 8: # 9999h (1 saat)
        val = await from_bcd(raw) if mmss_hhmm_16bit else raw
        return int(val * 3600)

    return 0


async def to_hms(seconds: int) -> str:
    """Saniyeyi 'HH:MM:SS' formatına çevirir."""
    if seconds != seconds:  # NaN kontrolü
        return "NaN"
    seconds = int(round(seconds))
    hh, rem = divmod(seconds, 3600)
    mm, ss = divmod(rem, 60)
    print(f"{hh:02d}:{mm:02d}:{ss:02d}")
    return f"{hh:02d}:{mm:02d}:{ss:02d}"


async def to_minutes(seconds: int) -> int:
    """Saniyeyi dakikaya çevirir (int)."""
    if seconds != seconds:  # NaN kontrolü
        return 0
    print(int(seconds / 60))
    return int(seconds / 60)


# Test örneği
asyncio.run(to_seconds(3, 328, True))  # Örnek kullanım, 1 saat 1 dakika 1 saniye
