import asyncio
from pymodbus.client import AsyncModbusSerialClient
from pymodbus.exceptions import ModbusException

from timer_conf import to_seconds, to_hms, to_minutes

# Modbus RTU bağlantı ayarları
SERIAL_PORT = "/dev/tty.usbmodem58B60281011"  # Kendi portunuza göre değiştirin
BAUDRATE = 9600
SLAVE_ID = 1

data = {}


def bcd_to_int(bcd):
    """16 bitlik bir değeri BCD'den integer'a çevirir."""
    return ((bcd >> 12) & 0xF) * 1000 + ((bcd >> 8) & 0xF) * 100 + ((bcd >> 4) & 0xF) * 10 + (bcd & 0xF)

async def read_device_data():
    try:
        client = AsyncModbusSerialClient(
            framer="rtu",
            port=SERIAL_PORT,
            baudrate=BAUDRATE,
            stopbits=1,
            bytesize=8,
            parity='N',
            timeout=1,
        )
        await client.connect()

        # Holding register (örnek adresler: 0-9)
        holding = await client.read_holding_registers(address=0, count=10, device_id=SLAVE_ID)
        # Input register (örnek adresler: 0-9)
        input_ = await client.read_input_registers(address=0, count=4, device_id=SLAVE_ID)

        data["holding_registers"] = holding.registers 
        data["input_registers"] = input_.registers 

        # Sonuçları düzenli şekilde yazdır
        print(f"Slave ID: {SLAVE_ID}")
        print("Holding Registers:")
        for i, val in enumerate(holding.registers):
            bcd_val = bcd_to_int(val) 
            print(f"  [{i}] = {val} (BCD) -> {bcd_val} (int)")
        print("Input Registers (BCD):")
        for i, val in enumerate(input_.registers):
            bcd_val = bcd_to_int(val)
            print(f"  [{i}] = {val} (BCD) -> {bcd_val} (int)")

    except ModbusException as e:
        print(f"Modbus hatası: {e}")
    except Exception as e:
        print(f"Genel hata: {e}")

asyncio.run(read_device_data())

second =asyncio.run(to_seconds(data["holding_registers"][2], data["input_registers"][0], True)) 

print(f"Saniye cinsinden: {second}")
