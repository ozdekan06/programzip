import json, os, shutil, sys
from pathlib import Path

def main():
    app_dir = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    bundle = Path(getattr(sys, "_MEIPASS", app_dir))
    data_dir, static_dir = app_dir / "data", app_dir / "static"
    data_dir.mkdir(exist_ok=True)
    shutil.copytree(bundle / "static", static_dir, dirs_exist_ok=True)
    config_path = app_dir / "config.json"
    if not config_path.exists(): shutil.copy2(bundle / "config.example.json", config_path)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    keys = {"modbus_port":"MODBUS_PORT","modbus_baudrate":"MODBUS_BAUDRATE","modbus_parity":"MODBUS_PARITY","modbus_stopbits":"MODBUS_STOPBITS","modbus_timeout":"MODBUS_TIMEOUT","modbus_retries":"MODBUS_RETRIES","inter_request_delay":"MODBUS_INTER_REQUEST_DELAY","inter_device_delay":"MODBUS_INTER_DEVICE_DELAY"}
    for key, env in keys.items():
        if key in config: os.environ[env] = str(config[key])
    os.environ["OZDEKAN_DATA_DIR"], os.environ["OZDEKAN_STATIC_DIR"] = str(data_dir), str(static_dir)
    os.chdir(app_dir)
    import uvicorn
    from main import app
    uvicorn.run(app, host=config.get("host", "127.0.0.1"), port=int(config.get("port", 8000)), reload=False)

if __name__ == "__main__": main()
