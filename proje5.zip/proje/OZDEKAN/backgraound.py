import asyncio
from database import SessionLocal
from models import AlarmLog, Machine, SensorLog, TimerLog, CycleLog, CycleEvent, Product
import connection_api 
import time
import math
import os


# BCD'den int'e çeviren fonksiyon
def bcd_to_int(bcd):
    result = 0
    multiplier = 1
    while bcd > 0:
        digit = bcd & 0xF
        result += digit * multiplier
        bcd >>= 4
        multiplier *= 10
    return result


# BCD'den float'a çeviren fonksiyon (son n hane ondalık)
def bcd_to_float(bcd, decimal_digits=2):
    s = str(bcd_to_int(bcd)).zfill(decimal_digits+2)
    if len(s) > decimal_digits:
        return float(s[:-decimal_digits] + '.' + s[-decimal_digits:])
    else:
        return float('0.' + s[-decimal_digits:])

# Timer value + time base -> dakika
def timer_value_to_minutes(bcd_value, time_base):
    """Convert timer raw BCD value to minutes based on time_base.

    Mappings (examples with raw 0x1234 → decimal 1234 via BCD):
    - 0: 99.99s  → 12.34 s  → 0.2057 min
    - 1: 999.9s  → 123.4 s  → 2.0566 min
    - 2: 9999s   → 1234 s   → 20.5666 min
    - 3: 99m59s  → 12m34s   → 12 + 34/60 min
    - 4: 999.9m  → 123.4 m  → 123.4 min
    - 5: 9999m   → 1234 m   → 1234 min
    - 6: 99h59m  → 12h34m   → 12*60 + 34 min
    - 7: 999.9h  → 123.4 h  → 7404 min
    - 8: 9999h   → 1234 h   → 74040 min
    """
    if time_base == 0:  # 99.99s (0.01s resolution)
        seconds = bcd_to_float(bcd_value, 2)
        return seconds / 60.0
    elif time_base == 1:  # 999.9s (0.1s resolution)
        seconds = bcd_to_float(bcd_value, 1)
        return seconds / 60.0
    elif time_base == 2:  # 9999s (1s resolution)
        seconds = bcd_to_int(bcd_value)
        return seconds / 60.0
    elif time_base == 3:  # 99m59s (MM:SS in BCD)
        mmss = bcd_to_int(bcd_value)
        mm = mmss // 100
        ss = mmss % 100
        # Clamp seconds to 0..59 just in case
        ss = max(0, min(59, ss))
        return mm + (ss / 60.0)
    elif time_base == 4:  # 999.9m (0.1 minute)
        minutes = bcd_to_float(bcd_value, 1)
        return minutes
    elif time_base == 5:  # 9999m (1 minute)
        minutes = bcd_to_int(bcd_value)
        return float(minutes)
    elif time_base == 6:  # 99h59m (HH:MM in BCD)
        hhmm = bcd_to_int(bcd_value)
        hh = hhmm // 100
        mm = hhmm % 100
        # Clamp minutes to 0..59 just in case
        mm = max(0, min(59, mm))
        return hh * 60.0 + mm
    elif time_base == 7:  # 999.9h (0.1 hour)
        hours = bcd_to_float(bcd_value, 1)
        return hours * 60.0
    elif time_base == 8:  # 9999h (1 hour)
        hours = bcd_to_int(bcd_value)
        return hours * 60.0
    else:
        # Fallback: treat as minutes already
        return float(bcd_to_int(bcd_value))
import datetime


db = SessionLocal()
machines = []  # Arka plan görevlerinin kullanacağı aktif makine listesi
device_profiles = {}  # slave_id -> "sensor", "timer" veya "combined"
sensor_missing_since = {}  # (machine_id, sensor_id) -> ilk eksik okuma zamanı
suspended_device_ids = set()  # Merkezi Modbus okuma engeli

def load_machines():
    """Arka plan görevleri için yalnızca aktif makineleri yeniden yükle."""
    global machines, device_profiles, suspended_device_ids
    session = SessionLocal()
    try:
        # Yeni bir session kullanmak, API'nin başka bir session ile yaptığı
        # is_active değişikliğinin eski ORM nesneleri yüzünden gizlenmesini önler.
        active_machines = session.query(Machine).filter(Machine.is_active.is_(True)).all()
        now = datetime.datetime.now(datetime.timezone.utc)
        changed = False
        for machine in active_machines:
            suspended = dict(getattr(machine, 'sensor_suspended', {}) or {})
            timeout_seconds = max(1, int(getattr(machine, 'sensor_timeout_minutes', 5) or 5)) * 60
            for sensor_id in machine.sensor_ids or []:
                if suspended.get(str(sensor_id)):
                    sensor_missing_since.pop((machine.id, int(sensor_id)), None)
                    continue
                data = cache.get(int(sensor_id)) or {}
                read_at = data.get("input_read_at")
                if not read_at:
                    missing_key = (machine.id, int(sensor_id))
                    first_missing = sensor_missing_since.setdefault(missing_key, now)
                    if (now - first_missing).total_seconds() > timeout_seconds:
                        suspended[str(sensor_id)] = True
                        changed = True
                    continue
                sensor_missing_since.pop((machine.id, int(sensor_id)), None)
                try:
                    stale = (now - datetime.datetime.fromisoformat(read_at)).total_seconds() > timeout_seconds
                except (TypeError, ValueError):
                    stale = False
                if stale:
                    suspended[str(sensor_id)] = True
                    changed = True
            if suspended != (getattr(machine, 'sensor_suspended', {}) or {}):
                machine.sensor_suspended = suspended
        if changed:
            session.commit()
        session.expunge_all()
        machines = active_machines
        profiles = {}
        for machine in active_machines:
            for sensor_id in machine.sensor_ids or []:
                if (getattr(machine, 'sensor_suspended', {}) or {}).get(str(sensor_id)):
                    continue
                profiles[int(sensor_id)] = "sensor"
            if machine.timer_id is not None and not (getattr(machine, 'sensor_suspended', {}) or {}).get(str(machine.timer_id)):
                timer_id = int(machine.timer_id)
                profiles[timer_id] = "combined" if profiles.get(timer_id) == "sensor" else "timer"
        device_profiles = profiles
        configured_sensor_ids = {int(sensor_id) for machine in active_machines for sensor_id in (machine.sensor_ids or [])}
        suspended_device_ids = configured_sensor_ids - set(profiles)
        print(f"Aktif makine sayısı: {len(machines)}, Modbus cihazı: {len(device_profiles)}")
    finally:
        session.close()


cache = {}  # slave_id -> son okunan veri
active_alarms = {}  # (machine_id, sensor_id, alarm_type) -> AlarmLog nesnesi
last_timer_values = {}  # (machine_id, sensor_id) -> {T1, T1A, out, state}
out_of_range_states = {}  # (machine_id, sensor_id) -> {count, direction}
last_processed_sensor_reads = {}  # (machine_id, sensor_id) -> (input_read_at, holding_read_at)

# Eski importları bozmamak için alias; hattın gerçek kilidi connection_api'dedir.
client_lock = connection_api.bus_lock
INTER_DEVICE_DELAY = float(os.getenv("MODBUS_INTER_DEVICE_DELAY", "0.05"))
INTER_REQUEST_DELAY = float(os.getenv("MODBUS_INTER_REQUEST_DELAY", "0.03"))


async def read_device_data(slave_id: int):
    """
    Modbus cihazından veri okur.

    İstek timeout'u connection_api içindeki pymodbus istemcisi tarafından
    yönetilir. Burada ayrıca asyncio.wait_for kullanılmaz; aksi halde devam
    eden pymodbus isteği dışarıdan iptal edilerek "Request cancelled outside
    pymodbus" hatasına neden olur.
    
    Args:
        slave_id: Cihaz ID
    Returns:
        dict veya None
    """
    if int(slave_id) in suspended_device_ids:
        return None
    start_time = time.time()

    role = device_profiles.get(int(slave_id), "sensor")
    # Alarm ve log kodunun gerçekten tükettiği fonksiyon kodları. Aynı slave
    # iki roldeyse holding bloğu bir kez ve geniş uzunlukla okunur.
    holding_count = 52 if role in ("sensor", "combined") else 30
    requests = [
        ("holding_registers", "holding_read_at", "Holding register", "read_holding_registers", holding_count, "registers")
    ]
    if role in ("sensor", "combined"):
        requests.append(
            ("input_registers", "input_read_at", "Input register", "read_input_registers", 7, "registers")
        )
    elif role == "timer":
        # Timer ekranındaki kalan pişirme/yenileme süreleri input[0] ve
        # input[1]'den gelir. Dört register cihazın timer haritasını kapsar.
        requests.append(
            ("input_registers", "input_read_at", "Input register", "read_input_registers", 4, "registers")
        )
    if role in ("timer", "combined"):
        requests.append(
            ("discrete_inputs", "discrete_read_at", "Discrete input", "read_discrete_inputs", 7, "bits")
        )

    updated = {}
    latencies = []
    errors = []
    for request_index, (data_key, time_key, label, method_name, count, value_attr) in enumerate(requests):
        try:
            result, latency_ms = await connection_api.execute(
                method_name, slave_id=slave_id, address=0, count=count
            )
            latencies.append(latency_ms)
            if result.isError():
                errors.append(f"{label}: {result}")
                continue

            # Tek timestamp hem değer hem kalite bilgisinin aynı örneğe ait
            # olduğunu garanti eder.
            updated[data_key] = list(getattr(result, value_attr))
            updated[time_key] = datetime.datetime.now().astimezone().isoformat()
        except Exception as exc:
            errors.append(f"{label}: {exc}")
        finally:
            # Özellikle 9600 baud cihazlarda cevap işlendikten hemen sonra gelen
            # ikinci fonksiyon kodu kaçabiliyor. Son sorgudan sonra cihazlar-arası
            # bekleme zaten periodic_sensor_read içinde uygulanıyor.
            if request_index < len(requests) - 1:
                await asyncio.sleep(INTER_REQUEST_DELAY)

    if updated:
        # Başarısız grupların önceki değerlerini ve tarihlerini koru.
        device_cache = cache.setdefault(slave_id, {})
        device_cache.update(updated)
        successful_times = [value for key, value in updated.items() if key.endswith("_read_at")]
        device_cache["read_at"] = max(successful_times)
        device_cache["quality"] = "GOOD" if not errors else "PARTIAL"
        device_cache["last_error"] = "; ".join(errors) if errors else None
        device_cache["latency_ms"] = round(sum(latencies), 2)
        device_cache["sequence"] = device_cache.get("sequence", 0) + 1
        device_cache["consecutive_errors"] = (
            device_cache.get("consecutive_errors", 0) + 1 if errors else 0
        )
    else:
        device_cache = cache.setdefault(slave_id, {})
        device_cache["quality"] = "OFFLINE"
        device_cache["last_error"] = "; ".join(errors) or "Cihazdan veri alınamadı"
        device_cache["consecutive_errors"] = device_cache.get("consecutive_errors", 0) + 1

    for error in errors:
        print(f"❌ Modbus okuma hatası: slave {slave_id}: {error}")

    elapsed = time.time() - start_time
    if elapsed > 1.0:
        print(f"⚠️  Yavaş okuma: slave {slave_id} → {elapsed:.2f}s")

    return cache.get(slave_id) if updated else None




async def write_device_data(slave_id: int, address: int, value: int) -> bool:
    if not 0 <= address <= 0xFFFF or not 0 <= value <= 0xFFFF:
        return False
    try:
        result, _ = await connection_api.execute(
            "write_register", slave_id=slave_id, address=address, value=value
        )
        return not result.isError()
    except Exception as e:
        print(f"Slave {slave_id} yazma hatası: {e}")
        return False






async def periodic_sensor_read():
    next_machine_refresh = 0.0
    while True:
        # DB sorgusunu her hızlı polling turunda değil, seyrek yap.
        now = time.monotonic()
        if now >= next_machine_refresh:
            load_machines()
            next_machine_refresh = now + 5.0

        if not machines:
            print("Aktif makine bulunamadı!")
            await asyncio.sleep(5)
            continue
        
        # machine.sensor_ids’nin tipi ve yapısına göre aşağıdaki kısmı uylaman gerek
        # Örnek: sensor_ids JSON ya da string listesi olabilir. Diyelim JSON listesi:

        # Profil sözlüğü zaten bütün aktif makinelerdeki ID'leri tekilleştirir.
        # Aynı cihaz birden fazla makineye atanmış olsa bile turda yalnızca bir kez okunur.
        for slave_id in device_profiles:
            try:
                data = await read_device_data(slave_id)
                if data is None:
                    print(f"⚠️  Slave {slave_id} veri döndürmedi")
            except Exception as e:
                print(f"❌ Slave {slave_id} okuma hatası: {e}")
                continue
            finally:
                # Bazı RTU cihazları bir sonraki slave isteği hemen geldiğinde
                # ilk frame'i kaçırıyor. Kısa bus-idle süresi 1 sn retry'dan hızlıdır.
                await asyncio.sleep(INTER_DEVICE_DELAY)

        # Tur biter bitmez yeniden başla; küçük yield diğer coroutine'leri aç bırakmaz.
        await asyncio.sleep(0.01)

async def periodic_sensor_log():
    while True:
        try:
            for machine in machines:
                # Skip inactive machines
                if not getattr(machine, 'is_active', True):
                    continue
                for sensor_id in (machine.sensor_ids or []):
                    if (getattr(machine, 'sensor_suspended', {}) or {}).get(str(sensor_id)):
                        continue
                    print(sensor_id)
                    #print(machine.name, machine.sensor_ids)
                    slave_id = int(sensor_id)
                    data = cache.get(slave_id)
                    if not data:
                        continue
                    
                    # Sıcaklık değerleri
                    input_registers = data.get("input_registers", [])
                    holding_registers = data.get("holding_registers", [])
                    value_temp = input_registers[0] if input_registers else None
                    value_temp_set = holding_registers[0] if holding_registers else None
                    value_temp_histerezis = holding_registers[5] if len(holding_registers) > 5 else None

                    # Haberleşme yenilenmediyse aynı eski örneği yeni bir periyot sayma.
                    sensor_key = (machine.id, slave_id)
                    read_signature = (data.get("input_read_at"), data.get("holding_read_at"))
                    if not all(read_signature) or last_processed_sensor_reads.get(sensor_key) == read_signature:
                        continue
                    last_processed_sensor_reads[sensor_key] = read_signature

                    now = datetime.datetime.now()

                    # --- SensorLog (yalnızca set ± histerezis dışında) ---
                    if (
                        value_temp is not None
                        and value_temp_set is not None
                        and value_temp_histerezis is not None
                        and slave_id != machine.timer_id
                    ):
                        lower_limit = value_temp_set - value_temp_histerezis
                        upper_limit = value_temp_set + value_temp_histerezis
                        is_out_of_range = value_temp < lower_limit or value_temp > upper_limit

                        # İlk uygunsuz değeri hemen, uygunsuzluk devam ediyorsa
                        # sonraki her 5 kontrol periyodunda bir kaydet.
                        should_log = False
                        if not is_out_of_range:
                            out_of_range_states.pop(sensor_key, None)
                        else:
                            direction = "YÜKSEK" if value_temp > upper_limit else "DÜŞÜK"
                            state = out_of_range_states.get(sensor_key)

                            # Yön değişirse bunu yeni bir uygunsuzluk olarak ele al.
                            if state is None or state["direction"] != direction:
                                state = {"count": 1, "direction": direction}
                            else:
                                state["count"] += 1

                            out_of_range_states[sensor_key] = state
                            should_log = state["count"] == 1 or (state["count"] - 1) % 5 == 0

                        if should_log:
                            log = SensorLog(
                                machine_id=machine.id,
                                sensor_id=slave_id,
                                value=value_temp,
                                value_set=value_temp_set,
                                value_histerezis=value_temp_histerezis,
                                timestamp=now
                            )
                            db.add(log)
                            print(
                                f"SensorLog kaydedildi: {sensor_key} → "
                                f"temp={value_temp}, set={value_temp_set}, histerezis={value_temp_histerezis} "
                                f"({direction}, uygunsuz periyot={state['count']}, "
                                f"normal aralık: {lower_limit}-{upper_limit})"
                            )

                        # --- AlarmLog (tek satır mantığı) ---
                        high_key = (machine.id, slave_id, "HIGH_TEMP")
                        low_key  = (machine.id, slave_id, "LOW_TEMP")

                        if value_temp > (value_temp_set + value_temp_histerezis):
                            if high_key not in active_alarms:
                                log_alarm = AlarmLog(
                                    machine_id=machine.id,
                                    sensor_id=slave_id,
                                    alarm_type="HIGH_TEMP",
                                    start_time=now,
                                    end_time=None
                                )
                                db.add(log_alarm)
                                active_alarms[high_key] = log_alarm
                                print(f"ALARM BAŞLADI: HIGH_TEMP {high_key}")
                        else:
                            if high_key in active_alarms:
                                active_alarms[high_key].end_time = now
                                db.add(active_alarms[high_key])
                                print(f"ALARM BİTTİ: HIGH_TEMP {high_key}")
                                del active_alarms[high_key]

                        if value_temp < (value_temp_set - value_temp_histerezis):
                            if low_key not in active_alarms:
                                log_alarm = AlarmLog(
                                    machine_id=machine.id,
                                    sensor_id=slave_id,
                                    alarm_type="LOW_TEMP",
                                    start_time=now,
                                    end_time=None
                                )
                                db.add(log_alarm)
                                active_alarms[low_key] = log_alarm
                                print(f"ALARM BAŞLADI: LOW_TEMP {low_key}")
                        else:
                            if low_key in active_alarms:
                                active_alarms[low_key].end_time = now
                                db.add(active_alarms[low_key])
                                print(f"ALARM BİTTİ: LOW_TEMP {low_key}")
                                del active_alarms[low_key]
    
                # --- TimerLog (sensör listesinden bağımsız) ---
                timer_id = int(machine.timer_id) if machine.timer_id is not None else None
                data_timer = cache.get(timer_id) if timer_id is not None else None
                if data_timer:
                    holding = data_timer.get("holding_registers", [])
                    discrete = data_timer.get("discrete_inputs", [])

                    if len(holding) > 10 and len(discrete) > 6:
                        value_timer_T1_min = timer_value_to_minutes(holding[0], holding[2])
                        value_timer_T2_min = timer_value_to_minutes(holding[8], holding[10])
                        value_timer_out = discrete[0]
                        value_start = discrete[6]
                        value_reset = discrete[4]
                        value_gate = discrete[5]
                        value_state = "start" if value_start and not value_reset and not value_gate else "stop"
                        timer_key = (machine.id, timer_id)
                        new_timer_values = {
                            "T1": value_timer_T1_min,
                            "T2": value_timer_T2_min,
                            "out": value_timer_out,
                            "state": value_state,
                        }

                        if last_timer_values.get(timer_key) != new_timer_values:
                            log_timer = TimerLog(
                                machine_id=machine.id,
                                sensor_id=timer_id,
                                value_T1=value_timer_T1_min,
                                value_T2=value_timer_T2_min,
                                value_out=value_timer_out,
                                value_state=value_state,
                                timestamp=datetime.datetime.now(),
                            )
                            db.add(log_timer)
                            last_timer_values[timer_key] = new_timer_values
                            print(f"TimerLog kaydedildi: {timer_key} → {new_timer_values}")

            db.commit()

        except Exception as e:
            print(f"periodic_sensor_log hata: {e}")

        await asyncio.sleep(10)

async def periodic_cycle_log():
    """
    Start sinyalini izler:
    - Start 1 → 0: Pişirme süresi (cooking_duration)
    - Start 0 → 1: Yenileme süresi (renewal_duration)
    - İki start 1 arasındaki toplam süre bir cycle olarak kaydedilir
    """
    cycle_states = {}  # (machine_id, timer_id) -> {"cycle_start": time, "cooking_start": time, "cooking_duration": minutes, "last_start": 0/1}

    while True:
        for machine in machines:
            # Skip inactive machines for cycle detection as well
            if not getattr(machine, 'is_active', True):
                continue
            timer_id = machine.timer_id
            if not timer_id:
                continue
            data_timer = cache.get(timer_id)
            if not data_timer:
                continue

            holding = data_timer.get("holding_registers", [])
            discrete = data_timer.get("discrete_inputs", [])
            if len(holding) <= 10 or len(discrete) <= 6:
                continue

            value_start = discrete[6]

            value_T1 = holding[0]
            value_T2 = holding[8]
            # time base registers (match reads used in periodic_sensor_log)
            tb_T1 = holding[2]
            tb_T2 = holding[10]

            # Convert ideal cycle time to minutes consistently
            try:
                t1_min = timer_value_to_minutes(value_T1 or 0, tb_T1)
            except Exception:
                t1_min = 0
            try:
                t2_min = timer_value_to_minutes(value_T2 or 0, tb_T2)
            except Exception:
                t2_min = 0
            ideal_cycle_time = (t1_min or 0) + (t2_min or 0)

            key = (machine.id, timer_id)
            now = datetime.datetime.now()

            # State'i başlat
            if key not in cycle_states:
                cycle_states[key] = {
                    "cycle_start": None,
                    "cooking_start": None,
                    "cooking_duration": None,
                    "last_start": None
                }

            state = cycle_states[key]
            last_start = state["last_start"]

            # Detect transitions and write append-only CycleEvent records.
            # 0 -> 1 : START
            if last_start == 0 and value_start == 1:
                # write a START event to DB
                ev = CycleEvent(
                    machine_id=machine.id,
                    timestamp=now,
                    event_type="START",
                    details={"t1_min": t1_min, "t2_min": t2_min}
                )
                db.add(ev)
                db.commit()
                print(f"CycleEvent START kaydedildi: machine={machine.id} @ {now}")

            # 1 -> 0 : STOP
            elif last_start == 1 and value_start == 0:
                ev = CycleEvent(
                    machine_id=machine.id,
                    timestamp=now,
                    event_type="STOP",
                    details={}
                )
                db.add(ev)
                db.commit()
                print(f"CycleEvent STOP kaydedildi: machine={machine.id} @ {now}")

            # İlk start detection when last_start is None and current is 1 -> also emit START
            elif last_start is None and value_start == 1:
                ev = CycleEvent(
                    machine_id=machine.id,
                    timestamp=now,
                    event_type="START",
                    details={"t1_min": t1_min, "t2_min": t2_min}
                )
                db.add(ev)
                db.commit()
                print(f"CycleEvent START (initial) kaydedildi: machine={machine.id} @ {now}")

            # update in-memory last state
            state["last_start"] = value_start

        await asyncio.sleep(0.5)

def run_cycle_log():
    asyncio.run(periodic_cycle_log())


async def process_cycle_events():
    """
    Background task that consumes append-only CycleEvent rows and aggregates them
    into CycleLog entries. This makes start/stop durable across crashes.
    """
    while True:
        try:
            # Get unprocessed events ordered by timestamp
            events = db.query(CycleEvent).filter(CycleEvent.processed == 0).order_by(CycleEvent.timestamp.asc()).all()
            if not events:
                await asyncio.sleep(1.0)
                continue

            # Process events sequentially
            for ev in events:
                machine_id = ev.machine_id
                ev_time = ev.timestamp
                ev_type = ev.event_type

                # Find open CycleLog (cycle_end_time IS NULL) for this machine
                open_cycle = db.query(CycleLog).filter(CycleLog.machine_id == machine_id, CycleLog.cycle_end_time == None).order_by(CycleLog.cycle_start_time.desc()).first()

                if ev_type == "START":
                    t1_min = ev.details.get("t1_min") if ev.details else None
                    t2_min = ev.details.get("t2_min") if ev.details else None

                    if open_cycle is None:
                        # create new open cycle
                        new_cycle = CycleLog(
                            machine_id=machine_id,
                            timestamp=ev_time,
                            cycle_start_time=ev_time,
                            cooking_start_time=ev_time,
                            ideal_cooking_time=t1_min,
                            ideal_renewal_time=t2_min,
                            ideal_total_time=(t1_min or 0) + (t2_min or 0)
                        )
                        db.add(new_cycle)
                        db.commit()
                        print(f"CycleLog (open) oluşturuldu: machine={machine_id} start={ev_time}")
                    else:
                        # There is an open cycle: if it already has cooking_duration, finalize it using this START as cycle_end
                        if open_cycle.cooking_duration is not None:
                            cycle_end = ev_time
                            total_duration = (cycle_end - open_cycle.cycle_start_time).total_seconds() / 60.0 if open_cycle.cycle_start_time else None
                            renewal_duration = (total_duration - open_cycle.cooking_duration) if (total_duration is not None and open_cycle.cooking_duration is not None) else None
                            open_cycle.cycle_end_time = cycle_end
                            open_cycle.total_duration = total_duration
                            open_cycle.renewal_duration = renewal_duration
                            open_cycle.ideal_cooking_time = open_cycle.ideal_cooking_time or t1_min
                            open_cycle.ideal_renewal_time = open_cycle.ideal_renewal_time or t2_min
                            open_cycle.ideal_total_time = (open_cycle.ideal_cooking_time or 0) + (open_cycle.ideal_renewal_time or 0)
                            # delays
                            if open_cycle.ideal_cooking_time is not None and open_cycle.cooking_duration is not None:
                                open_cycle.cooking_delay = open_cycle.cooking_duration - open_cycle.ideal_cooking_time
                            if open_cycle.ideal_renewal_time is not None and open_cycle.renewal_duration is not None:
                                open_cycle.renewal_delay = open_cycle.renewal_duration - open_cycle.ideal_renewal_time
                            if open_cycle.total_duration is not None and open_cycle.ideal_total_time is not None:
                                open_cycle.total_delay = open_cycle.total_duration - open_cycle.ideal_total_time
                            db.add(open_cycle)
                            db.commit()
                            print(f"CycleLog tamamlandı via START: machine={machine_id} end={cycle_end}")
                            try:
                                # Otomatik ürün kaydı: basit bir yaklaşım olarak en yüksek serialnumber'a 1 ekliyoruz
                                last_prod = db.query(Product).order_by(Product.serialnumber.desc()).first()
                                next_serial = (last_prod.serialnumber + 1) if last_prod and last_prod.serialnumber is not None else 1000
                                prod = Product(
                                    name=f"AutoProduct_m{machine_id}_c{open_cycle.id}",
                                    serialnumber=next_serial,
                                    productsize="",
                                    producttype="",
                                    moldnumber=0,
                                    timestamp=datetime.datetime.now()
                                )
                                db.add(prod)
                                db.commit()
                                print(f"Otomatik Product oluşturuldu: id={prod.id} serial={prod.serialnumber}")
                            except Exception as e:
                                print(f"Otomatik Product oluşturulurken hata: {e}")

                        # Start new open cycle
                        new_cycle = CycleLog(
                            machine_id=machine_id,
                            timestamp=ev_time,
                            cycle_start_time=ev_time,
                            cooking_start_time=ev_time,
                            ideal_cooking_time=t1_min,
                            ideal_renewal_time=t2_min,
                            ideal_total_time=(t1_min or 0) + (t2_min or 0)
                        )
                        db.add(new_cycle)
                        db.commit()
                        print(f"Yeni CycleLog (open) oluşturuldu after finalize: machine={machine_id} start={ev_time}")

                elif ev_type == "STOP":
                    # On STOP, set cooking_duration on the open cycle if exists
                    if open_cycle is not None:
                        # compute cooking_duration as stop_time - cooking_start_time
                        if open_cycle.cooking_start_time is not None:
                            cooking_duration = (ev_time - open_cycle.cooking_start_time).total_seconds() / 60.0
                            open_cycle.cooking_duration = cooking_duration
                            db.add(open_cycle)
                            db.commit()
                            print(f"CycleLog updated with cooking_duration: machine={machine_id} duration={cooking_duration:.2f}dk")
                        else:
                            # If cooking_start_time missing, set it to cycle_start_time
                            if open_cycle.cycle_start_time is not None:
                                cooking_duration = (ev_time - open_cycle.cycle_start_time).total_seconds() / 60.0
                                open_cycle.cooking_duration = cooking_duration
                                db.add(open_cycle)
                                db.commit()
                                print(f"CycleLog updated (fallback) cooking_duration set: machine={machine_id} duration={cooking_duration:.2f}dk")
                    else:
                        # No open cycle: create a partial cycle with cooking_duration only
                        partial = CycleLog(
                            machine_id=machine_id,
                            timestamp=ev_time,
                            cycle_start_time=None,
                            cooking_start_time=None,
                            cooking_duration=None
                        )
                        # We can't compute cooking_duration without start; leave partial and log
                        db.add(partial)
                        db.commit()
                        print(f"STOP received but no open CycleLog found — partial record created for machine={machine_id} @ {ev_time}")

                # mark event processed
                ev.processed = 1
                db.add(ev)
                db.commit()

        except Exception as e:
            print(f"process_cycle_events hata: {e}")

        await asyncio.sleep(0.5)
