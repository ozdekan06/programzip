from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import main


def machine(active=True, timer_id=7, timeout=5):
    return SimpleNamespace(
        is_active=active,
        timer_id=timer_id,
        sensor_timeout_minutes=timeout,
    )


def timer_data(bits, read_at=None, quality="GOOD"):
    return {
        "discrete_inputs": bits,
        "discrete_read_at": read_at or datetime.now(timezone.utc).isoformat(),
        "quality": quality,
    }


def setup_function():
    main.cache.clear()


def test_only_inactive_machine_is_idle():
    assert main._live_machine_status(machine(active=False)) == "idle"
    assert main._live_machine_status(machine(timer_id=None)) == "renewal"


def test_start_zero_is_renewal():
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 0])
    assert main._live_machine_status(machine()) == "renewal"


def test_start_one_is_cooking_regardless_of_output():
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 1])
    assert main._live_machine_status(machine()) == "cooking"


def test_active_machine_without_timer_data_is_renewal():
    main.cache.clear()
    assert main._live_machine_status(machine()) == "renewal"


def test_reset_gate_and_quality_do_not_make_active_machine_idle():
    main.cache[7] = timer_data([1, 0, 0, 0, 1, 0, 1])
    assert main._live_machine_status(machine()) == "cooking"
    main.cache[7] = timer_data([1, 0, 0, 0, 0, 1, 1])
    assert main._live_machine_status(machine()) == "cooking"
    main.cache[7] = timer_data([1, 0, 0, 0, 0, 0, 1], quality="OFFLINE")
    assert main._live_machine_status(machine()) == "cooking"
    stale = (datetime.now(timezone.utc) - timedelta(minutes=6)).isoformat()
    main.cache[7] = timer_data([0, 0, 0, 0, 0, 0, 0], read_at=stale)
    assert main._live_machine_status(machine()) == "renewal"
